import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faBan,
  faDollarSign,
  faPen,
  faPlus,
  faPrint,
  faReceipt,
  faTimes,
  faTrashCan,
  faUserGroup,
  faWallet,
} from "@fortawesome/free-solid-svg-icons";
import { ModulePage } from "../Global/ModulePage";
import { FloatingField } from "../Global/Formularios/TabbedForm";
import BotonExportarGlobal from "../Global/Botones/BotonExportarGlobal";
import GlobalDivTable from "../Global/GlobalDivTable";
import ModalEliminarGlobal from "../Global/Modales/ModalEliminarGlobal";
import ModalComprobantePago from "../Global/Modales/ModalComprobantePago";
import CrudModal from "../Global/Modales/CrudModal";
import ModalExportarGlobal from "../Global/Modales/ModalExportarGlobal";
import ModuleFeedback from "../Global/ModuleFeedback";
import Toast from "../Global/Toast";
import { canWrite } from "../_shared/auth/session";
import {
  downloadPaymentReceiptPdf,
  openPaymentReceipt,
} from "../_shared/utils/comprobantePago";
import { cuotasApi } from "./api/cuotasApi";
import { useCuotas } from "./hooks/useCuotas";
import ModalMesCuotas from "./modales/ModalMesCuotas";
import ModalPagoCuota from "./modales/ModalPagoCuota";
import "./Cuotas.css";

const localToday = () => {
  const now = new Date();
  return new Date(now.getTime() - now.getTimezoneOffset() * 60000)
    .toISOString()
    .slice(0, 10);
};

const currentDate = new Date();
const currentYear = currentDate.getFullYear();
const currentMonth = currentDate.getMonth() + 1;
const PAGE_SIZE = 100;

const decimalInput = (value, maxIntegerDigits = 12, maxDecimals = 2) => {
  const normalized = String(value ?? "")
    .replace(/,/g, ".")
    .replace(/[^0-9.]/g, "");
  const [rawInteger = "", ...decimalParts] = normalized.split(".");
  const integer = rawInteger.slice(0, maxIntegerDigits);
  if (!decimalParts.length) return integer;

  const decimals = decimalParts.join("").slice(0, maxDecimals);
  return `${integer || "0"}.${decimals}`;
};

const normalizeSearchText = (value) =>
  String(value ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim();

const DEFAULT_MONTHS = [
  "Enero",
  "Febrero",
  "Marzo",
  "Abril",
  "Mayo",
  "Junio",
  "Julio",
  "Agosto",
  "Septiembre",
  "Octubre",
  "Noviembre",
  "Diciembre",
].map((nombre, index) => ({ id_mes: index + 1, nombre }));

const paginationItems = (currentPage, totalPages) => {
  if (totalPages <= 7) {
    return Array.from({ length: totalPages }, (_, index) => index + 1);
  }

  const items = [1];
  if (currentPage > 4) items.push("ellipsis-left");

  const from = Math.max(2, currentPage - 1);
  const to = Math.min(totalPages - 1, currentPage + 1);
  for (let page = from; page <= to; page += 1) items.push(page);

  if (currentPage < totalPages - 3) items.push("ellipsis-right");
  items.push(totalPages);
  return items;
};

const MONEY_FORMATTER = new Intl.NumberFormat("es-AR", {
  style: "currency",
  currency: "ARS",
  minimumFractionDigits: 2,
});
const DATE_FORMATTER = new Intl.DateTimeFormat("es-AR", { timeZone: "UTC" });

const money = (value) => MONEY_FORMATTER.format(Number(value || 0));

const formatDate = (value) =>
  value ? DATE_FORMATTER.format(new Date(`${value}T00:00:00Z`)) : "—";

const PRINT_MONTHS = DEFAULT_MONTHS.map((month) => month.nombre.toUpperCase());

const escapePrintHtml = (value) =>
  String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");

const LEGACY_RECEIPT_STYLES = `
  @page {
    size: A4 portrait;
    margin: 0;
  }
  body {
    width: 210mm;
    height: 297mm;
    margin: 0;
    padding: 0;
    font-family: Arial, sans-serif;
    font-size: 12px;
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    align-items: center;
    position: relative;
    transform: rotate(90deg);
    transform-origin: top left;
    left: 70%;
    top: 0;
  }
  .gcuotas-contenedor {
    width: 210mm;
    margin: 10mm 0;
    page-break-after: always;
    box-sizing: border-box;
  }
  .gcuotas-comprobante {
    width: 100%;
    height: 100%;
    display: flex;
    box-sizing: border-box;
  }
  .gcuotas-talon-socio {
    width: 60%;
    padding-left: 12.5mm;
    padding-top: 13mm;
  }
  .gcuotas-talon-cobrador {
    width: 60mm;
    padding-left: 5.5mm;
    padding-top: 16mm;
  }
  p {
    margin-top: 5px;
    font-size: 13px;
  }
  .gcuotas-monto-unit {
    font-weight: 400 !important;
  }
  .gcuotas-total-wrap {
    font-weight: 700 !important;
  }
  .gcuotas-monto-total {
    font-weight: 400 !important;
  }
`;

const printableAmount = (value) => {
  const amount = Number(value || 0);
  return Number.isFinite(amount) ? amount : 0;
};

const groupLegacyReceiptRecords = (records) => {
  const groups = new Map();

  records.forEach((item, index) => {
    const key = String(
      item.id_socio ??
        item.id_empresa ??
        item.documento ??
        item.denominacion ??
        `registro-${index}`,
    );
    const amount = printableAmount(
      item.monto ?? item.monto_sugerido ?? item.monto_base ?? 0,
    );
    const period = item.periodo_impresion || item.periodo || "—";
    const current = groups.get(key);

    if (current) {
      if (!current.periods.includes(period)) current.periods.push(period);
      current.total += amount;
      if (!current.unitAmount && amount) current.unitAmount = amount;
      return;
    }

    groups.set(key, {
      item,
      periods: [period],
      unitAmount: amount,
      total: amount,
    });
  });

  return Array.from(groups.values());
};

const printReceiptsBatch = ({ printWindow, records, entityType }) => {
  if (!printWindow || printWindow.closed) {
    throw new Error("No se pudo abrir la ventana de impresión.");
  }
  if (!Array.isArray(records) || records.length === 0) {
    throw new Error("No hay comprobantes para los meses seleccionados.");
  }

  const isCompany = entityType === "EMPRESA";
  const groupedRecords = groupLegacyReceiptRecords(records);
  const receipts = groupedRecords
    .map(({ item, periods, unitAmount, total }) => {
      const denomination =
        item.denominacion ||
        (isCompany
          ? item.razon_social
          : `${item.apellido || ""} ${item.nombre || ""}`.trim()) ||
        "—";
      const address = item.domicilio || item.domicilio_2 || item.direccion || "-";
      const category = item.categoria || "";
      const paymentMethod =
        item.medio_pago || item.medio_pago_preferido || "No especificado";
      const status = String(item.estado || "PENDIENTE").toUpperCase();
      const amountDetail =
        periods.length > 1
          ? `<span class="gcuotas-monto-unit">$${unitAmount}</span>
             &nbsp;&nbsp;
             <span class="gcuotas-total-wrap">
               Total <span class="gcuotas-monto-total">$${total}</span>
             </span>`
          : `<span class="gcuotas-monto-unit">$${unitAmount}</span>`;
      const statusLine =
        status === "PAGADO" || status === "CONDONADO"
          ? `<p><strong>Estado:</strong> ${escapePrintHtml(status)}</p>`
          : "";

      return `
        <div class="gcuotas-contenedor">
          <div class="gcuotas-comprobante">
            <div class="gcuotas-talon-socio">
              <p><strong>${isCompany ? "Empresa:" : "Afiliado:"}</strong> ${escapePrintHtml(denomination)}</p>
              <p><strong>Domicilio:</strong> ${escapePrintHtml(address)}</p>
              <p><strong>Categoría / Monto:</strong> ${escapePrintHtml(category)} / ${amountDetail}</p>
              <p><strong>Período:</strong> ${escapePrintHtml(periods.join(", "))}</p>
              <p><strong>Medio de Pago:</strong> ${escapePrintHtml(paymentMethod)}</p>
              ${statusLine}
              <p>Por consultas comunicarse al 03564-15205778</p>
              <p>Las cuotas adeudadas se cobrarán al valor actualizado al momento del pago.</p>
            </div>

            <div class="gcuotas-talon-cobrador">
              <p><strong>${isCompany ? "Empresa:" : "Nombre y Apellido:"}</strong> ${escapePrintHtml(denomination)}</p>
              <p><strong>Categoría / Monto:</strong> ${escapePrintHtml(category)} / ${amountDetail}</p>
              <p><strong>Período:</strong> ${escapePrintHtml(periods.join(", "))}</p>
              <p><strong>Medio de Pago:</strong> ${escapePrintHtml(paymentMethod)}</p>
              ${statusLine}
            </div>
          </div>
        </div>`;
    })
    .join("");

  printWindow.document.open();
  printWindow.document.write(`
    <html>
      <head>
        <title>Comprobantes de Pago</title>
        <style>${LEGACY_RECEIPT_STYLES}</style>
      </head>
      <body>${receipts}</body>
    </html>`);
  printWindow.document.close();
  printWindow.focus();
  printWindow.setTimeout(() => printWindow.print(), 250);
  return groupedRecords.length;
};

const isTruthyFlag = (value) =>
  value === true ||
  value === 1 ||
  ["1", "SI", "SÍ", "TRUE", "PAGADO"].includes(
    String(value || "")
      .trim()
      .toUpperCase(),
  );

const isPaidPrincipal = (principal) =>
  Boolean(principal?.id_pago) ||
  isTruthyFlag(principal?.pagado) ||
  isTruthyFlag(principal?.ya_pagado) ||
  String(principal?.estado || "").toUpperCase() === "PAGADO";

const isUnavailablePrincipal = (principal) =>
  !principal ||
  principal.puede_pagar === false ||
  principal.puede_pagar === 0 ||
  principal.puede_pagar === "0" ||
  principal.disponible === false;

const familyTargetsForMonths = (periodMap, monthIds, monthAmounts = {}) =>
  monthIds.reduce((targets, monthId) => {
    const context = periodMap[String(monthId)]?.context;
    const members = Array.isArray(context?.familia?.integrantes)
      ? context.familia.integrantes
      : [];
    const amountState = monthAmounts?.[String(monthId)] || {};
    const customAmount = amountState.personalizado
      ? Number(decimalInput(amountState.monto))
      : null;
    const hasValidCustomAmount =
      Number.isFinite(customAmount) && Number(customAmount) > 0;

    members.forEach((member) => {
      if (member?.puede_pagar) {
        targets.push({
          id_socio: Number(member.id_socio),
          mes: Number(monthId),
          monto: hasValidCustomAmount
            ? Number(customAmount)
            : Number(member.monto_sugerido || 0),
          monto_personalizado: hasValidCustomAmount,
        });
      }
    });

    return targets;
  }, []);

const hasAdditionalFamilyTargets = (periodMap, monthIds) =>
  monthIds.some((monthId) => {
    const context = periodMap[String(monthId)]?.context;
    const principalId = Number(context?.principal?.id_socio || 0);
    const members = Array.isArray(context?.familia?.integrantes)
      ? context.familia.integrantes
      : [];
    return members.some(
      (member) =>
        member?.puede_pagar && Number(member.id_socio) !== principalId,
    );
  });

const selectionKey = (item) =>
  `${item.id_socio}-${item.anio || currentYear}-${item.mes || currentMonth}`;

const emptyForm = () => ({
  id_socio: "",
  anio: String(currentYear),
  mes: String(currentMonth),
  meses: [],
  fecha_pago: localToday(),
  monto: "",
  montos_por_mes: {},
  id_medio_pago: "",
  aplicar_familia: false,
  usar_saldo_favor: false,
  pagos: [],
});

const emptyBalanceForm = () => ({
  id_socio: "",
  saldo_objetivo: "",
  detalle: "",
});

const defaultAmountOption = (principal) => {
  const options = Array.isArray(principal?.opciones_monto)
    ? principal.opciones_monto
    : [];
  const year = Number(principal?.anio);
  const month = Number(principal?.mes);

  // Elegimos por vigencia real, no sólo por importe: una categoría puede haber
  // tenido el mismo valor en períodos históricos distintos.
  if (Number.isInteger(year) && Number.isInteger(month) && month >= 1 && month <= 12) {
    const periodEnd = new Date(Date.UTC(year, month, 0))
      .toISOString()
      .slice(0, 10);
    const periodOption = options.find((option) => {
      const from = option?.vigente_desde ? String(option.vigente_desde).slice(0, 10) : null;
      const to = option?.vigente_hasta ? String(option.vigente_hasta).slice(0, 10) : null;
      return (!from || from <= periodEnd) && (!to || to >= periodEnd);
    });
    if (periodOption) return periodOption;
  }

  const periodBaseAmount = Number(principal?.monto_base);
  if (Number.isFinite(periodBaseAmount) && periodBaseAmount > 0) {
    const amountMatch = options.find(
      (option) =>
        Math.abs(Number(option?.monto_base || 0) - periodBaseAmount) < 0.005,
    );
    if (amountMatch) return amountMatch;
  }

  return options.find((option) => option.actual) || options[0] || null;
};

const currentBatchAmountOption = (item) => {
  const options = Array.isArray(item?.opciones_monto) ? item.opciones_monto : [];
  return options.find((option) => option?.actual) || options[0] || null;
};

const defaultMonthAmountState = (principal) => {
  const option = defaultAmountOption(principal);
  const fallback =
    option?.monto ??
    principal?.monto_sugerido ??
    principal?.monto_base ??
    "";
  return {
    personalizado: false,
    opcion_id: option?.id || "actual",
    monto: String(fallback ?? ""),
  };
};

const reconcileMonthAmountStates = (periodMap, previous = {}) =>
  Object.fromEntries(
    Object.entries(periodMap).map(([monthId, period]) => {
      const principal = period?.context?.principal || null;
      const options = Array.isArray(principal?.opciones_monto)
        ? principal.opciones_monto
        : [];
      const prior = previous?.[monthId];

      if (prior?.personalizado) {
        return [
          monthId,
          {
            personalizado: true,
            opcion_id: prior.opcion_id || defaultAmountOption(principal)?.id || "actual",
            monto: String(prior.monto ?? ""),
          },
        ];
      }

      const option =
        options.find((item) => String(item.id) === String(prior?.opcion_id)) ||
        defaultAmountOption(principal);

      return [
        monthId,
        {
          personalizado: false,
          opcion_id: option?.id || "actual",
          monto: String(
            option?.monto ??
              principal?.monto_sugerido ??
              principal?.monto_base ??
              "",
          ),
        },
      ];
    }),
  );

const enrichPaymentReceipt = (source, context = {}) => {
  if (!source || typeof source !== "object") return source || null;

  const operation =
    source.operacion && typeof source.operacion === "object"
      ? source.operacion
      : source;
  const sourceLines = Array.isArray(source.lineas)
    ? source.lineas
    : Array.isArray(operation.lineas)
      ? operation.lineas
      : [];
  const fallbackLines = Array.isArray(context.lineas) ? context.lineas : [];
  const receiptLines =
    fallbackLines.length > sourceLines.length
      ? fallbackLines
      : sourceLines.length
        ? sourceLines
        : fallbackLines;
  const lineas = receiptLines.map(
    (line, index) => ({
      ...(fallbackLines[index] || {}),
      ...line,
      domicilio:
        line.domicilio ||
        line.domicilio_2 ||
        fallbackLines[index]?.domicilio ||
        context.domicilio ||
        "",
      cobrador:
        line.cobrador ||
        fallbackLines[index]?.cobrador ||
        context.cobrador ||
        "",
      medio_pago:
        line.medio_pago ||
        fallbackLines[index]?.medio_pago ||
        context.medio ||
        "",
    }),
  );

  return {
    ...source,
    organizacion:
      source.organizacion || operation.organizacion || "LALCEC San Francisco",
    operacion: {
      ...operation,
      socios_label: operation.socios_label || context.socios || "—",
      domicilio:
        operation.domicilio ||
        operation.domicilio_2 ||
        context.domicilio ||
        "",
      cobrador: operation.cobrador || context.cobrador || "",
      medio_pago: operation.medio_pago || context.medio || "—",
      tipo_entidad: operation.tipo_entidad || context.tipoEntidad || "",
      lineas,
    },
    lineas,
  };
};

const CuotasTableRows = React.memo(function CuotasTableRows({
  items,
  selectedPayments,
  isResolved,
  isCondoned,
  multiMode,
  writable,
  tipo,
  debtRowClass,
  actionsRef,
}) {
  return items.map((item) => {
    const selected = Boolean(selectedPayments[selectionKey(item)]);
    return (
      <div
        className={`mov-gridTable mov-gridTable--row global-divTable__row entity-table-row cuotas-grid ${isResolved ? "cuotas-grid--paid" : debtRowClass} ${selected ? "is-selected" : ""}`}
        role="row"
        key={item.id_pago || `${item.id_socio}-${item.anio}-${item.mes}`}
        onClick={(event) => actionsRef.current.selectRow(event, item)}
        onKeyDown={(event) => actionsRef.current.selectRowWithKeyboard(event, item)}
        tabIndex={!isResolved && multiMode && writable ? 0 : undefined}
        aria-selected={!isResolved && multiMode ? selected : undefined}
      >
        {!isResolved && multiMode ? (
          <div className="mov-gridCell cuotas-select-cell">
            <input
              type="checkbox"
              checked={selected}
              onChange={() => actionsRef.current.toggleSelection(item)}
              aria-label={`Seleccionar cuota de ${item.denominacion}`}
            />
          </div>
        ) : null}
        <div className="mov-gridCell entity-main-cell">
          <strong>{item.denominacion || "SIN DENOMINACIÓN"}</strong>
          <small>
            {tipo === "EMPRESA"
              ? item.documento
                ? `CUIT ${item.documento}`
                : null
              : [
                  item.documento ? `DNI ${item.documento}` : null,
                  item.familia || null,
                  item.estado_socio === "INACTIVO"
                    ? "REGISTRO DADO DE BAJA"
                    : null,
                ]
                  .filter(Boolean)
                  .join(" · ")}
          </small>
        </div>
        <div className="mov-gridCell is-center">
          <span
            className={`cuotas-category-chip ${item.categoria ? "" : "is-empty"}`}
          >
            {item.categoria || "SIN CATEGORÍA"}
          </span>
        </div>
        <div className="mov-gridCell is-strong is-center">{item.periodo}</div>
        {isResolved ? (
          <>
            <div className="mov-gridCell is-center">
              <span
                className={`cuotas-payment-state ${isCondoned ? "is-condoned" : "is-paid"}`}
              >
                {isCondoned ? "CONDONADO" : "PAGADO"}
              </span>
            </div>
            <div className="mov-gridCell is-center">
              {formatDate(item.fecha_pago)}
            </div>
            <div className="mov-gridCell is-center">
              {item.medio_pago || "—"}
            </div>
            <div className="mov-gridCell cuotas-money-cell">
              {money(item.monto)}
              {Number(item.monto_saldo_favor_aplicado || 0) > 0 ? (
                <small className="cuotas-balance-note">
                  Saldo aplicado {money(item.monto_saldo_favor_aplicado)}
                </small>
              ) : null}
            </div>
          </>
        ) : (
          <>
            <div className="mov-gridCell is-center">
              {item.medio_pago_preferido || "—"}
            </div>
            <div className="mov-gridCell cuotas-money-cell">
              {Number(item.monto_sugerido || 0) > 0 ? (
                <>
                  {money(item.monto_sugerido)}
                  {Number(item.porcentaje_descuento_familiar || 0) > 0 ? (
                    <small className="cuotas-discount-note">
                      Base {money(item.monto_base)}
                    </small>
                  ) : null}
                </>
              ) : (
                "A DEFINIR"
              )}
            </div>
          </>
        )}
        {!multiMode ? (
          <div className="mov-gridCell mov-gridCell--actions">
            <div className="mov-actionsInline">
              {!isCondoned ? (
                <button
                  type="button"
                  className="mov-iconBtn"
                  title="Imprimir comprobante"
                  aria-label={`Imprimir comprobante de ${item.denominacion}`}
                  onClick={() => actionsRef.current.printPaymentRow(item)}
                >
                  <FontAwesomeIcon icon={faPrint} />
                </button>
              ) : null}
              {isResolved ? (
                <button
                  type="button"
                  className="mov-iconBtn mov-iconBtn--danger"
                  title={isCondoned ? "Eliminar condonación" : "Eliminar pago"}
                  aria-label={`${isCondoned ? "Eliminar condonación" : "Eliminar pago"} de ${item.denominacion}`}
                  onClick={() => actionsRef.current.setDeleteRow(item)}
                  disabled={!writable}
                >
                  <FontAwesomeIcon icon={faTimes} />
                </button>
              ) : (
                <>
                  <button
                    type="button"
                    className="mov-iconBtn cuotas-condone-btn"
                    title="Condonar cuota"
                    aria-label={`Condonar cuota de ${item.denominacion}`}
                    onClick={() => actionsRef.current.setCondoneRow(item)}
                    disabled={!writable}
                  >
                    <FontAwesomeIcon icon={faBan} />
                  </button>
                  <button
                    type="button"
                    className="mov-iconBtn"
                    title="Registrar pago"
                    aria-label={`Registrar pago de ${item.denominacion}`}
                    onClick={() => actionsRef.current.openPayment(item)}
                    disabled={!writable}
                  >
                    <FontAwesomeIcon icon={faDollarSign} />
                  </button>
                </>
              )}
            </div>
          </div>
        ) : null}
      </div>
    );
  });
});

const balanceMovementLabel = (type) => ({
  SOBRANTE: "Sobrante acreditado",
  APLICACION_PAGO: "Saldo utilizado",
  REVERSO: "Saldo reintegrado",
  AJUSTE_CREDITO: "Ajuste a favor",
  AJUSTE_DEBITO: "Ajuste descontado",
}[type] || "Movimiento de saldo");

const SaldoFavorTableRows = React.memo(function SaldoFavorTableRows({
  items,
  tipo,
  writable,
  onEdit,
  onDelete,
}) {
  return items.map((item) => (
    <div
      className="mov-gridTable mov-gridTable--row global-divTable__row entity-table-row cuotas-grid cuotas-grid--balance"
      role="row"
      key={`saldo-${item.id_socio}`}
    >
      <div className="mov-gridCell entity-main-cell">
        <strong>{item.denominacion || "SIN DENOMINACIÓN"}</strong>
        <small>
          {[
            item.documento
              ? `${tipo === "EMPRESA" ? "CUIT" : "DNI"} ${item.documento}`
              : null,
            item.socio_eliminado
              ? "REGISTRO ELIMINADO"
              : item.estado_socio === "INACTIVO"
                ? "REGISTRO DADO DE BAJA"
                : null,
          ].filter(Boolean).join(" · ")}
        </small>
      </div>
      <div className="mov-gridCell is-center">
        <span className={`cuotas-category-chip ${item.categoria ? "" : "is-empty"}`}>
          {item.categoria || "SIN CATEGORÍA"}
        </span>
      </div>
      <div className="mov-gridCell is-center">
        {balanceMovementLabel(item.ultimo_tipo)}
      </div>
      <div className="mov-gridCell is-center">
        {item.ultima_fecha ? formatDate(String(item.ultima_fecha).slice(0, 10)) : "—"}
      </div>
      <div className="mov-gridCell is-center">
        {item.ultimo_origen === "BOT"
          ? "Bot"
          : item.ultimo_origen === "MANUAL"
            ? "Manual"
            : "Sistema"}
      </div>
      <div className="mov-gridCell cuotas-money-cell cuotas-balance-value">
        {money(item.saldo_favor)}
      </div>
      <div className="mov-gridCell mov-gridCell--actions">
        {writable ? (
          <div className="mov-actionsInline">
            <button
              type="button"
              className="mov-iconBtn"
              title="Editar saldo a favor"
              aria-label={`Editar saldo a favor de ${item.denominacion}`}
              onClick={() => onEdit(item)}
            >
              <FontAwesomeIcon icon={faPen} />
            </button>
            <button
              type="button"
              className="mov-iconBtn mov-iconBtn--danger"
              title="Eliminar saldo a favor"
              aria-label={`Eliminar saldo a favor de ${item.denominacion}`}
              onClick={() => onDelete(item)}
            >
              <FontAwesomeIcon icon={faTrashCan} />
            </button>
          </div>
        ) : (
          <span className="entity-readonly">CONSULTA</span>
        )}
      </div>
    </div>
  ));
});

export default function Cuotas() {
  const writable = canWrite();
  const contextRequestId = useRef(0);
  const rowActionsRef = useRef({});
  const tableBodyRef = useRef(null);
  const pendingTableScrollRef = useRef(null);
  const totalsRequestId = useRef(0);
  const selectAllRequestId = useRef(0);
  // setSaving(true) recién deshabilita el botón en el siguiente render.
  // Este ref se actualiza de forma sincrónica y evita que un doble click,
  // Enter + click o dos submit events del navegador envíen dos cobros.
  const paymentSubmitInFlightRef = useRef(false);
  const [tipo, setTipo] = useState("PERSONA");
  const [estado, setEstado] = useState("DEUDORES");
  const [buscar, setBuscar] = useState("");
  const [debouncedBuscar, setDebouncedBuscar] = useState("");
  const [anio, setAnio] = useState(String(currentYear));
  const [mes, setMes] = useState(String(currentMonth));
  const [medioPago, setMedioPago] = useState("");
  const [pagina, setPagina] = useState(1);
  const [feedback, setFeedback] = useState(null);
  const [paymentOpen, setPaymentOpen] = useState(false);
  const [paymentMode, setPaymentMode] = useState("single");
  const [paymentForm, setPaymentForm] = useState(emptyForm());
  const [paymentContext, setPaymentContext] = useState(null);
  const [paymentPeriods, setPaymentPeriods] = useState({});
  const [paymentBalance, setPaymentBalance] = useState(0);
  const [contextLoading, setContextLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [balanceModalOpen, setBalanceModalOpen] = useState(false);
  const [balanceEditingRow, setBalanceEditingRow] = useState(null);
  const [balanceForm, setBalanceForm] = useState(emptyBalanceForm());
  const [balancePartnerSearch, setBalancePartnerSearch] = useState("");
  const [balanceSaving, setBalanceSaving] = useState(false);
  const [balanceDeleteRow, setBalanceDeleteRow] = useState(null);
  const [condoneRow, setCondoneRow] = useState(null);
  const [deleteRow, setDeleteRow] = useState(null);
  const [multiMode, setMultiMode] = useState(false);
  const [selectedPayments, setSelectedPayments] = useState({});
  const [selectingAll, setSelectingAll] = useState(false);
  const [knownFilteredSelectionKeys, setKnownFilteredSelectionKeys] = useState({});
  const [receipt, setReceipt] = useState(null);
  const [printMonthsOpen, setPrintMonthsOpen] = useState(false);
  const [selectedPrintMonths, setSelectedPrintMonths] = useState([]);
  const [printingAll, setPrintingAll] = useState(false);
  const [exportOpen, setExportOpen] = useState(false);
  const [estadoTotales, setEstadoTotales] = useState({
    DEUDORES: null,
    PAGADOS: null,
    CONDONADOS: null,
    SALDOS_FAVOR: null,
  });

  useEffect(() => {
    const timeout = window.setTimeout(() => {
      setDebouncedBuscar(buscar.trim());
      setPagina(1);
    }, 250);
    return () => window.clearTimeout(timeout);
  }, [buscar]);

  const filtros = useMemo(
    () => ({
      tipo,
      estado,
      buscar: debouncedBuscar,
      anio,
      mes,
      ...(medioPago ? { id_medio_pago: medioPago } : {}),
      pagina,
      por_pagina: PAGE_SIZE,
    }),
    [tipo, estado, debouncedBuscar, anio, mes, medioPago, pagina],
  );
  const {
    items,
    catalogos,
    paginacion,
    loading,
    error,
    cargar,
    cargarCatalogos,
  } = useCuotas(filtros);

  const filtrosTotales = useMemo(
    () => ({
      tipo,
      buscar: debouncedBuscar,
      anio,
      mes,
      pagina: 1,
      por_pagina: 1,
      incluir_catalogos: 0,
    }),
    [tipo, debouncedBuscar, anio, mes],
  );

  const cargarTotalesEstado = useCallback(async () => {
    const currentRequest = ++totalsRequestId.current;

    setEstadoTotales({
      DEUDORES: null,
      PAGADOS: null,
      CONDONADOS: null,
      SALDOS_FAVOR: null,
    });

    try {
      const [deudoresResult, pagadosResult, condonadosResult, saldosResult] = await Promise.allSettled([
        cuotasApi.listar({
          ...filtrosTotales,
          estado: "DEUDORES",
          ...(medioPago ? { id_medio_pago: medioPago } : {}),
        }),
        cuotasApi.listar({
          ...filtrosTotales,
          estado: "PAGADOS",
          ...(medioPago ? { id_medio_pago: medioPago } : {}),
        }),
        cuotasApi.listar({
          ...filtrosTotales,
          estado: "CONDONADOS",
          ...(medioPago ? { id_medio_pago: medioPago } : {}),
        }),
        cuotasApi.saldosFavor({
          tipo,
          buscar: debouncedBuscar,
          pagina: 1,
          por_pagina: 1,
        }),
      ]);

      if (currentRequest !== totalsRequestId.current) return;

      const totalFromResponse = (response) =>
        Number(
          response?.paginacion?.total ??
            response?.resumen?.total ??
            response?.items?.length ??
            0,
        );

      const totalFromResult = (result) =>
        result.status === "fulfilled" ? totalFromResponse(result.value) : null;

      setEstadoTotales((current) => ({
        DEUDORES: totalFromResult(deudoresResult) ?? current.DEUDORES,
        PAGADOS: totalFromResult(pagadosResult) ?? current.PAGADOS,
        CONDONADOS: totalFromResult(condonadosResult) ?? current.CONDONADOS,
        SALDOS_FAVOR: totalFromResult(saldosResult) ?? current.SALDOS_FAVOR,
      }));
    } catch {
      // El contador es informativo: una falla no debe bloquear la tabla principal.
    }
  }, [filtrosTotales, medioPago, tipo, debouncedBuscar]);

  useEffect(() => {
    void cargarTotalesEstado();
    return () => {
      totalsRequestId.current += 1;
    };
  }, [cargarTotalesEstado]);

  const usaPaginacionRemota = Boolean(
    paginacion &&
      (paginacion.total != null ||
        paginacion.total_paginas != null ||
        paginacion.pagina != null),
  );
  const totalRegistros = usaPaginacionRemota
    ? Number(paginacion.total || 0)
    : items.length;
  const paginaRemota = Number(paginacion?.pagina || pagina);
  const porPaginaRemota = Number(paginacion?.por_pagina || PAGE_SIZE);
  const totalPaginas = usaPaginacionRemota
    ? Number(
        paginacion.total_paginas || Math.ceil(totalRegistros / porPaginaRemota),
      )
    : Math.ceil(items.length / PAGE_SIZE);
  const opcionesPagina = useMemo(
    () => paginationItems(pagina, totalPaginas),
    [pagina, totalPaginas],
  );
  const itemsPagina = useMemo(() => {
    if (usaPaginacionRemota) return items;
    const inicio = (pagina - 1) * PAGE_SIZE;
    return items.slice(inicio, inicio + PAGE_SIZE);
  }, [items, pagina, usaPaginacionRemota]);
  const registroDesde = usaPaginacionRemota
    ? Number(
        paginacion.desde ||
          (totalRegistros ? (paginaRemota - 1) * porPaginaRemota + 1 : 0),
      )
    : totalRegistros
      ? (pagina - 1) * PAGE_SIZE + 1
      : 0;
  const registroHasta = usaPaginacionRemota
    ? Number(
        paginacion.hasta ||
          Math.min(paginaRemota * porPaginaRemota, totalRegistros),
      )
    : Math.min(pagina * PAGE_SIZE, totalRegistros);

  useEffect(() => {
    setPagina(1);
  }, [tipo, estado, debouncedBuscar, anio, mes, medioPago]);

  useEffect(() => {
    if (loading || pagina <= 1) return;
    if (totalPaginas === 0 || pagina > totalPaginas) {
      setPagina(Math.max(1, totalPaginas));
    }
  }, [loading, pagina, totalPaginas]);

  useEffect(() => {
    if (loading || pendingTableScrollRef.current == null) return undefined;

    const scrollTop = pendingTableScrollRef.current;
    let frame = window.requestAnimationFrame(() => {
      frame = window.requestAnimationFrame(() => {
        const body = tableBodyRef.current;
        if (body) {
          const maxScrollTop = Math.max(0, body.scrollHeight - body.clientHeight);
          body.scrollTop = Math.min(scrollTop, maxScrollTop);
        }
        pendingTableScrollRef.current = null;
      });
    });

    return () => window.cancelAnimationFrame(frame);
  }, [loading, itemsPagina.length]);

  const visibleYearOptions = useMemo(
    () =>
      Array.from(
        new Set(
          (catalogos.anios?.length ? catalogos.anios : [currentYear])
            .filter(Boolean)
            .map(String),
        ),
      ).sort((left, right) => Number(right) - Number(left)),
    [catalogos.anios],
  );

  useEffect(() => {
    if (!catalogos.anios?.length || visibleYearOptions.includes(String(anio))) {
      return;
    }

    // Si se eliminó el último pago de un año futuro, ese año deja de ser
    // visible en Cuotas y volvemos automáticamente al año actual.
    setAnio(
      visibleYearOptions.includes(String(currentYear))
        ? String(currentYear)
        : visibleYearOptions[0] || String(currentYear),
    );
  }, [anio, catalogos.anios, visibleYearOptions]);

  const partners = tipo === "EMPRESA" ? catalogos.empresas : catalogos.socios;
  const selectedPartner = partners.find(
    (partner) => String(partner.id_socio) === String(paymentForm.id_socio),
  );
  const monthOptions = catalogos.meses?.length
    ? catalogos.meses
    : DEFAULT_MONTHS;
  const isPaid = estado === "PAGADOS";
  const isCondoned = estado === "CONDONADOS";
  const isBalanceView = estado === "SALDOS_FAVOR";
  const isResolved = isPaid || isCondoned;
  const exportStatusLabel = isPaid
    ? "Pagados"
    : isCondoned
      ? "Condonados"
      : isBalanceView
        ? "Saldos a favor"
      : "Deudores";
  const selectedMonthLabel =
    monthOptions.find((item) => String(item.id_mes) === String(mes))?.nombre ||
    DEFAULT_MONTHS[Number(mes) - 1]?.nombre ||
    "Período";
  const selectedPaymentMethodLabel = (catalogos.medios_pago || []).find(
    (item) => String(item.id_medio_pago) === String(medioPago),
  )?.nombre;
  const exportFilterSubtitle = [
    tipo === "EMPRESA" ? "Empresas" : "Socios",
    exportStatusLabel,
    !isBalanceView ? `${selectedMonthLabel} ${anio}` : null,
    !isBalanceView && selectedPaymentMethodLabel
      ? `Medio de pago: ${selectedPaymentMethodLabel}`
      : null,
    debouncedBuscar ? `Búsqueda: ${debouncedBuscar}` : null,
  ]
    .filter(Boolean)
    .join(" · ");
  const exportColumns = useMemo(
    () => isBalanceView ? [
      {
        label: tipo === "EMPRESA" ? "Empresa" : "Socio/a",
        value: (item) => item.denominacion || "SIN DENOMINACIÓN",
      },
      {
        label: tipo === "EMPRESA" ? "CUIT" : "DNI",
        value: (item) => item.documento || "—",
      },
      { label: "Categoría", value: (item) => item.categoria || "SIN CATEGORÍA" },
      { label: "Último movimiento", value: (item) => balanceMovementLabel(item.ultimo_tipo) },
      { label: "Fecha", value: (item) => item.ultima_fecha ? formatDate(String(item.ultima_fecha).slice(0, 10)) : "—" },
      { label: "Origen", value: (item) => item.ultimo_origen || "SISTEMA" },
      { label: "Saldo a favor", value: (item) => money(item.saldo_favor) },
    ] : [
      {
        label: tipo === "EMPRESA" ? "Empresa" : "Socio/a",
        value: (item) => item.denominacion || "SIN DENOMINACIÓN",
      },
      {
        label: tipo === "EMPRESA" ? "CUIT" : "DNI",
        value: (item) => item.documento || "—",
      },
      {
        label: "Categoría",
        value: (item) => item.categoria || "SIN CATEGORÍA",
      },
      { label: "Período", value: (item) => item.periodo || "—" },
      { label: "Estado", value: () => exportStatusLabel },
      {
        label: "Fecha",
        value: (item) =>
          isResolved
            ? formatDate(item.fecha_pago || item.fecha_condonacion)
            : "—",
      },
      {
        label: "Medio de pago",
        value: (item) =>
          item.medio_pago || item.medio_pago_preferido || "—",
      },
      {
        label: "Importe",
        value: (item) => {
          const amount =
            item.monto ?? item.monto_sugerido ?? item.monto_base ?? 0;
          return Number(amount) > 0 ? money(amount) : "A DEFINIR";
        },
      },
    ],
    [exportStatusLabel, isResolved, isBalanceView, tipo],
  );
  const obtenerTodosFiltrados = useCallback(async (filterOverrides = {}) => {
    const requestFilters = { ...filtros, ...filterOverrides };
    const listFn = requestFilters.estado === "SALDOS_FAVOR"
      ? cuotasApi.saldosFavor
      : cuotasApi.listar;
    const primeraRespuesta = await listFn({
      ...requestFilters,
      pagina: 1,
      por_pagina: PAGE_SIZE,
      incluir_catalogos: 0,
    });
    const registros = [...(primeraRespuesta.items || [])];
    const total = Number(
      primeraRespuesta.paginacion?.total || registros.length,
    );
    const paginas = Number(
      primeraRespuesta.paginacion?.total_paginas ||
        Math.max(1, Math.ceil(total / PAGE_SIZE)),
    );

    for (let paginaActual = 2; paginaActual <= paginas; paginaActual += 1) {
      const respuesta = await listFn({
        ...requestFilters,
        pagina: paginaActual,
        por_pagina: PAGE_SIZE,
        incluir_catalogos: 0,
      });
      registros.push(...(respuesta.items || []));
    }

    return registros;
  }, [filtros]);

  const openPrintAll = useCallback(() => {
    if (loading || totalRegistros <= 0) {
      setFeedback({
        type: "warning",
        message: loading
          ? "Esperá a que terminen de cargarse las cuotas."
          : "No hay cuotas para imprimir con los filtros actuales.",
      });
      return;
    }

    const currentMonthName = PRINT_MONTHS[Number(mes) - 1] || PRINT_MONTHS[0];
    setSelectedPrintMonths([currentMonthName]);
    setPrintMonthsOpen(true);
  }, [loading, mes, totalRegistros]);

  const handlePrintAll = useCallback(async () => {
    if (!selectedPrintMonths.length || printingAll) return;

    const printWindow = window.open("", "_blank", "width=960,height=720");
    if (!printWindow) {
      setFeedback({
        type: "error",
        message:
          "El navegador bloqueó la ventana de impresión. Habilitá las ventanas emergentes e intentá nuevamente.",
      });
      return;
    }

    printWindow.document.write(
      "<!doctype html><html><head><meta charset=\"utf-8\"><title>Preparando impresión</title></head><body style=\"font-family:Arial,sans-serif;padding:32px\">Preparando comprobantes…</body></html>",
    );
    printWindow.document.close();
    setPrintingAll(true);

    try {
      const orderedMonths = [...selectedPrintMonths].sort(
        (left, right) => PRINT_MONTHS.indexOf(left) - PRINT_MONTHS.indexOf(right),
      );
      const records = [];

      for (const monthName of orderedMonths) {
        const monthId = PRINT_MONTHS.indexOf(monthName) + 1;
        if (monthId <= 0) continue;

        const monthRecords = await obtenerTodosFiltrados({ mes: String(monthId) });
        records.push(
          ...monthRecords.map((item) => ({
            ...item,
            estado:
              item.estado ||
              (isPaid ? "PAGADO" : isCondoned ? "CONDONADO" : "PENDIENTE"),
            periodo_impresion:
              item.periodo || `${DEFAULT_MONTHS[monthId - 1]?.nombre || monthName} ${anio}`,
          })),
        );
      }

      const receiptCount = printReceiptsBatch({
        printWindow,
        records,
        entityType: tipo,
      });

      setPrintMonthsOpen(false);
      setFeedback({
        type: "success",
        message: `Se prepararon ${receiptCount} comprobantes para imprimir.`,
        duration: 4200,
      });
    } catch (error) {
      if (!printWindow.closed) printWindow.close();
      setFeedback({
        type: "error",
        message: error?.message || "No se pudieron preparar los comprobantes.",
        duration: 5200,
      });
    } finally {
      setPrintingAll(false);
    }
  }, [
    anio,
    isCondoned,
    isPaid,
    obtenerTodosFiltrados,
    printingAll,
    selectedPrintMonths,
    tipo,
  ]);

  const paymentYearOptions = Array.from(
    new Set([...visibleYearOptions, paymentForm.anio].filter(Boolean).map(String)),
  ).sort((left, right) => Number(right) - Number(left));
  const selectedMonthIds = (paymentForm.meses || [])
    .map(String)
    .sort((left, right) => Number(left) - Number(right));
  const availableMonthIds = monthOptions
    .map((item) => String(item.id_mes))
    .filter((monthId) => {
      const period = paymentPeriods[monthId];
      return period && !period.paid && !period.unavailable;
    });
  const allAvailableMonthsSelected =
    availableMonthIds.length > 0 &&
    availableMonthIds.every((monthId) => selectedMonthIds.includes(monthId));
  const selectedItems = Object.values(selectedPayments);
  const selectedCount = selectedItems.length;
  const selectionFilterKey = useMemo(
    () =>
      JSON.stringify({
        tipo,
        estado,
        buscar: debouncedBuscar,
        anio,
        mes,
        medioPago,
      }),
    [tipo, estado, debouncedBuscar, anio, mes, medioPago],
  );
  const currentFilteredSelectionKeys =
    knownFilteredSelectionKeys[selectionFilterKey] || [];
  const allFilteredPaymentsSelected =
    totalRegistros > 0 &&
    currentFilteredSelectionKeys.length === totalRegistros &&
    currentFilteredSelectionKeys.every((key) => Boolean(selectedPayments[key]));
  const entityLabel = tipo === "EMPRESA" ? "empresa" : "socio";
  const previewPaymentContext =
    paymentContext ||
    paymentPeriods[String(currentMonth)]?.context ||
    Object.values(paymentPeriods).find((period) => period?.context?.familia)?.context ||
    Object.values(paymentPeriods).find((period) => period?.context)?.context ||
    null;
  const family = previewPaymentContext?.familia || null;
  const principal = paymentContext?.principal || previewPaymentContext?.principal || null;
  const familyPaymentTargets = familyTargetsForMonths(
    paymentPeriods,
    selectedMonthIds,
    paymentForm.montos_por_mes,
  );
  const familyPaymentCount = familyPaymentTargets.length;
  const familyPaymentTotal = familyPaymentTargets.reduce(
    (total, target) => total + Number(target.monto || 0),
    0,
  );
  const activePaymentPeriod = paymentPeriods[String(paymentForm.mes)] || null;
  const activeMonthAmount =
    paymentForm.montos_por_mes?.[String(paymentForm.mes)]?.monto ??
    paymentForm.monto;
  const paymentPeriodAmount = Number(
    activeMonthAmount ||
      defaultAmountOption(activePaymentPeriod?.context?.principal)?.monto ||
      activePaymentPeriod?.context?.principal?.monto_sugerido ||
      activePaymentPeriod?.context?.principal?.monto_base ||
      principal?.monto_sugerido ||
      principal?.monto_base ||
      selectedPartner?.monto_sugerido ||
      0,
  );
  const paymentTotal =
    paymentMode === "multiple"
      ? paymentForm.pagos.reduce(
          (total, payment) => total + Number(payment.monto || 0),
          0,
        )
      : paymentForm.aplicar_familia && family
        ? familyPaymentTotal
        : selectedMonthIds.reduce(
            (total, monthId) =>
              total +
              Number(
                paymentForm.montos_por_mes?.[monthId]?.monto ||
                  defaultAmountOption(
                    paymentPeriods[monthId]?.context?.principal,
                  )?.monto ||
                  0,
              ),
            0,
          );
  const canUsePaymentBalance =
    paymentMode === "single" &&
    !paymentForm.aplicar_familia &&
    paymentBalance > 0;
  const paymentBalanceApplied =
    canUsePaymentBalance && paymentForm.usar_saldo_favor
      ? Math.min(paymentBalance, paymentTotal)
      : 0;
  const paymentAmountToCollect = Math.max(
    0,
    paymentTotal - paymentBalanceApplied,
  );

  const clearSelectedPayments = () => {
    selectAllRequestId.current += 1;
    setSelectingAll(false);
    setSelectedPayments({});
    setKnownFilteredSelectionKeys({});
  };

  const clearMultipleSelection = () => {
    clearSelectedPayments();
    setMultiMode(false);
  };

  const cancelMultipleSelection = () => {
    if (saving) return;
    if (paymentMode === "multiple") setPaymentOpen(false);
    clearMultipleSelection();
  };

  const closePayment = () => {
    if (saving) return;
    contextRequestId.current += 1;
    setContextLoading(false);
    setPaymentBalance(0);
    setPaymentOpen(false);
    if (paymentMode === "multiple") clearMultipleSelection();
  };

  const loadPaymentPeriods = async (
    partnerId,
    year,
    paymentDate,
    {
      selectedMonths = [],
      activeMonth = "",
      defaultFamily = false,
      defaultUseBalance = false,
    } = {},
  ) => {
    if (!partnerId || !year || !paymentDate) {
      setPaymentContext(null);
      setPaymentPeriods({});
      setPaymentBalance(0);
      return null;
    }

    const requestId = ++contextRequestId.current;
    setContextLoading(true);
    setPaymentPeriods({});

    try {
      const annualResponse = await cuotasApi.contextosPago({
        id_socio: partnerId,
        anio: year,
        fecha_pago: paymentDate,
      });
      const availableBalance = Math.max(
        0,
        Number(annualResponse?.saldo_favor?.saldo || 0),
      );
      const annualContexts = annualResponse?.periodos || {};
      const periods = monthOptions.map((monthItem) => {
        const monthId = String(monthItem.id_mes);
        const context = annualContexts[monthId] || annualContexts[Number(monthId)] || null;
        return {
          monthId,
          context,
          paid: isPaidPrincipal(context?.principal),
          unavailable: !context || isUnavailablePrincipal(context?.principal),
        };
      });
      if (requestId !== contextRequestId.current) return null;

      const periodMap = Object.fromEntries(
        periods.map((period) => [period.monthId, period]),
      );
      const validSelection = selectedMonths
        .map(String)
        .filter(
          (monthId) =>
            periodMap[monthId] &&
            !periodMap[monthId].paid &&
            !periodMap[monthId].unavailable,
        )
        .sort((left, right) => Number(left) - Number(right));
      const resolvedActiveMonth = validSelection.includes(String(activeMonth))
        ? String(activeMonth)
        : validSelection[0] || "";
      const activeContext = periodMap[resolvedActiveMonth]?.context || null;
      const hasFamilyToPay = hasAdditionalFamilyTargets(
        periodMap,
        validSelection,
      );

      setPaymentPeriods(periodMap);
      setPaymentContext(activeContext);
      setPaymentBalance(availableBalance);
      setPaymentForm((current) => {
        const monthAmounts = reconcileMonthAmountStates(
          periodMap,
          current.montos_por_mes,
        );
        const activeAmount =
          monthAmounts[resolvedActiveMonth]?.monto ||
          defaultMonthAmountState(activeContext?.principal).monto;

        return {
          ...current,
          mes: resolvedActiveMonth || current.mes,
          meses: validSelection,
          monto: String(activeAmount || ""),
          montos_por_mes: monthAmounts,
          aplicar_familia: defaultFamily
            ? hasFamilyToPay
            : current.aplicar_familia && hasFamilyToPay,
          usar_saldo_favor: hasFamilyToPay
            ? false
            : defaultUseBalance
              ? availableBalance > 0
              : current.usar_saldo_favor && availableBalance > 0,
        };
      });
      return periodMap;
    } catch (err) {
      if (requestId === contextRequestId.current) {
        setPaymentContext(null);
        setPaymentPeriods({});
        setPaymentBalance(0);
        setFeedback({
          type: "error",
          message: err.message || "No se pudieron consultar los períodos.",
        });
      }
      return null;
    } finally {
      if (requestId === contextRequestId.current) setContextLoading(false);
    }
  };

  const applyPartnerDefaults = (partnerId, base = paymentForm) => {
    const partner = partners.find(
      (item) => String(item.id_socio) === String(partnerId),
    );
    const next = {
      ...base,
      id_socio: String(partnerId || ""),
      meses: base.meses || [],
      monto: partner ? String(partner.monto_sugerido || "") : "",
      montos_por_mes: {},
      id_medio_pago: String(
        partner?.id_medio_pago ?? partner?.id_medio_pago_preferido ?? "",
      ),
      aplicar_familia: false,
    };
    setPaymentForm(next);
    loadPaymentPeriods(next.id_socio, next.anio, next.fecha_pago, {
      selectedMonths: next.meses,
      activeMonth: next.mes,
      defaultFamily: next.meses.length === 1,
      defaultUseBalance: true,
    });
  };

  const openPayment = (row = null) => {
    setFeedback(null);
    setPaymentMode("single");
    setPaymentContext(null);
    setPaymentBalance(0);
    const next = {
      ...emptyForm(),
      id_socio: String(row?.id_socio || partners?.[0]?.id_socio || ""),
      anio: String(row?.anio || anio),
      mes: String(row?.mes || mes),
      meses: [String(row?.mes || mes)],
    };
    const partner = partners.find(
      (item) => String(item.id_socio) === String(next.id_socio),
    );
    const resolved = {
      ...next,
      monto: String(row?.monto_sugerido || partner?.monto_sugerido || ""),
      id_medio_pago: String(
        row?.id_medio_pago_preferido ??
          partner?.id_medio_pago ??
          partner?.id_medio_pago_preferido ??
          "",
      ),
    };
    setPaymentForm(resolved);
    setPaymentOpen(true);
    loadPaymentPeriods(resolved.id_socio, resolved.anio, resolved.fecha_pago, {
      selectedMonths: resolved.meses,
      activeMonth: resolved.mes,
      defaultFamily: true,
      defaultUseBalance: true,
    });
  };

  const openMultiplePayment = () => {
    if (!selectedCount) {
      setFeedback({
        type: "error",
        message:
          "Seleccioná al menos una cuota para registrar el pago múltiple.",
      });
      return;
    }
    setFeedback(null);
    setPaymentMode("multiple");
    setPaymentContext(null);
    setPaymentBalance(0);
    const selectedPreferredPaymentMethods = selectedItems.map((item) =>
      String(item.id_medio_pago_preferido ?? item.id_medio_pago ?? ""),
    );
    const preferredPaymentMethodIds = Array.from(
      new Set(selectedPreferredPaymentMethods.filter(Boolean)),
    );
    const sharedPreferredPaymentMethod =
      selectedPreferredPaymentMethods.length > 0 &&
      selectedPreferredPaymentMethods.every(Boolean) &&
      preferredPaymentMethodIds.length === 1
        ? preferredPaymentMethodIds[0]
        : "";
    setPaymentForm({
      ...emptyForm(),
      anio,
      mes,
      id_medio_pago: sharedPreferredPaymentMethod,
      pagos: selectedItems.map((item) => {
        const amountOptions = Array.isArray(item.opciones_monto)
          ? item.opciones_monto
          : [];
        const currentOption = currentBatchAmountOption(item);
        return {
          id_socio: item.id_socio,
          anio: item.anio,
          mes: item.mes,
          denominacion: item.denominacion,
          documento: item.documento,
          categoria: item.categoria,
          familia: item.familia,
          porcentaje_descuento_familiar: item.porcentaje_descuento_familiar,
          monto_base: item.monto_base,
          monto_actual_categoria: item.monto_actual_categoria,
          opciones_monto: amountOptions,
          opcion_monto_id: currentOption?.id || "actual",
          domicilio: item.domicilio || item.domicilio_2 || item.direccion || "",
          cobrador: item.cobrador || "",
          // En selección múltiple el valor inicial es siempre la cuota actual.
          monto: String(
            currentOption?.monto ??
              item.monto_actual_categoria ??
              item.monto_sugerido ??
              "",
          ),
        };
      }),
    });
    setPaymentOpen(true);
    setMultiMode(false);
  };

  const printPaymentRow = (item) => {
    const printWindow = window.open("", "_blank", "width=960,height=720");
    if (!printWindow) {
      setFeedback({
        type: "error",
        message:
          "El navegador bloqueó la ventana de impresión. Habilitá las ventanas emergentes e intentá nuevamente.",
      });
      return;
    }

    const receiptPartner =
      partners.find(
        (partner) => String(partner.id_socio) === String(item.id_socio),
      ) || item;

    try {
      printReceiptsBatch({
        printWindow,
        records: [
          {
            ...item,
            domicilio:
              receiptPartner.domicilio_2 ||
              receiptPartner.domicilio ||
              receiptPartner.direccion ||
              item.domicilio ||
              item.domicilio_2 ||
              item.direccion ||
              "",
            cobrador: receiptPartner.cobrador || item.cobrador || "",
            estado:
              item.estado ||
              (isPaid ? "PAGADO" : isCondoned ? "CONDONADO" : "PENDIENTE"),
            periodo_impresion: item.periodo || "—",
          },
        ],
        entityType: tipo,
      });
    } catch (error) {
      if (!printWindow.closed) printWindow.close();
      setFeedback({
        type: "error",
        message: error?.message || "No se pudo preparar el comprobante.",
        duration: 5200,
      });
    }
  };

  const applyMonthSelection = (months, activeMonth, defaultFamily = true) => {
    const normalizedMonths = months
      .map(String)
      .filter((monthId) => {
        const period = paymentPeriods[monthId];
        return period && !period.paid && !period.unavailable;
      })
      .sort((left, right) => Number(left) - Number(right));
    const resolvedActiveMonth = normalizedMonths.includes(String(activeMonth))
      ? String(activeMonth)
      : normalizedMonths[0] || "";
    const activeContext = paymentPeriods[resolvedActiveMonth]?.context || null;
    const hasFamilyToPay = hasAdditionalFamilyTargets(
      paymentPeriods,
      normalizedMonths,
    );

    setPaymentContext(activeContext);
    setPaymentForm((current) => {
      const activeAmount =
        current.montos_por_mes?.[resolvedActiveMonth]?.monto ||
        defaultMonthAmountState(activeContext?.principal).monto;

      return {
        ...current,
        mes: resolvedActiveMonth || current.mes,
        meses: normalizedMonths,
        monto: String(activeAmount || ""),
        aplicar_familia: defaultFamily
          ? hasFamilyToPay
          : current.aplicar_familia && hasFamilyToPay,
      };
    });
  };

  const togglePaymentMonth = (monthId) => {
    const normalizedMonth = String(monthId);
    const period = paymentPeriods[normalizedMonth];
    if (!period || period.paid || period.unavailable) return;

    const selected = selectedMonthIds.includes(normalizedMonth);
    const nextMonths = selected
      ? selectedMonthIds.filter((value) => value !== normalizedMonth)
      : [...selectedMonthIds, normalizedMonth];
    applyMonthSelection(
      nextMonths,
      selected ? nextMonths[0] : normalizedMonth,
      true,
    );
  };

  const toggleAllPaymentMonths = () => {
    applyMonthSelection(
      allAvailableMonthsSelected ? [] : availableMonthIds,
      allAvailableMonthsSelected ? "" : availableMonthIds[0],
      false,
    );
  };

  const updatePaymentYear = (value) => {
    const next = {
      ...paymentForm,
      anio: String(value),
      meses: [],
      montos_por_mes: {},
      aplicar_familia: false,
    };
    setPaymentForm(next);
    setPaymentContext(null);
    loadPaymentPeriods(next.id_socio, next.anio, next.fecha_pago, {
      selectedMonths: [],
    });
  };

  const updatePaymentDate = (value) => {
    const next = { ...paymentForm, fecha_pago: value };
    setPaymentForm(next);
    loadPaymentPeriods(next.id_socio, next.anio, next.fecha_pago, {
      selectedMonths: next.meses,
      activeMonth: next.mes,
      defaultFamily: next.meses.length === 1,
    });
  };

  const updateMonthAmountOption = (monthId, optionId) => {
    const normalizedMonth = String(monthId);
    const principalForMonth =
      paymentPeriods[normalizedMonth]?.context?.principal || null;
    const options = Array.isArray(principalForMonth?.opciones_monto)
      ? principalForMonth.opciones_monto
      : [];
    const option =
      options.find((item) => String(item.id) === String(optionId)) ||
      defaultAmountOption(principalForMonth);
    if (!option) return;

    setPaymentForm((current) => {
      const nextAmount = String(option.monto ?? "");
      return {
        ...current,
        aplicar_familia: false,
        monto:
          String(current.mes) === normalizedMonth ? nextAmount : current.monto,
        montos_por_mes: {
          ...(current.montos_por_mes || {}),
          [normalizedMonth]: {
            personalizado: false,
            opcion_id: String(option.id),
            monto: nextAmount,
          },
        },
      };
    });
  };

  const toggleMonthCustomAmount = (monthId, checked) => {
    const normalizedMonth = String(monthId);
    const principalForMonth =
      paymentPeriods[normalizedMonth]?.context?.principal || null;

    setPaymentForm((current) => {
      const currentState =
        current.montos_por_mes?.[normalizedMonth] ||
        defaultMonthAmountState(principalForMonth);
      let nextState;

      if (checked) {
        nextState = {
          ...currentState,
          personalizado: true,
        };
      } else {
        const options = Array.isArray(principalForMonth?.opciones_monto)
          ? principalForMonth.opciones_monto
          : [];
        const option =
          options.find(
            (item) => String(item.id) === String(currentState.opcion_id),
          ) || defaultAmountOption(principalForMonth);
        nextState = {
          personalizado: false,
          opcion_id: option?.id || "actual",
          monto: String(
            option?.monto ??
              principalForMonth?.monto_sugerido ??
              principalForMonth?.monto_base ??
              "",
          ),
        };
      }

      return {
        ...current,
        monto:
          String(current.mes) === normalizedMonth
            ? String(nextState.monto ?? "")
            : current.monto,
        montos_por_mes: {
          ...(current.montos_por_mes || {}),
          [normalizedMonth]: nextState,
        },
      };
    });
  };

  const updateMonthCustomAmount = (monthId, value) => {
    const normalizedMonth = String(monthId);
    const sanitizedValue = decimalInput(value);
    setPaymentForm((current) => {
      const previous = current.montos_por_mes?.[normalizedMonth] || {};
      return {
        ...current,
        monto:
          String(current.mes) === normalizedMonth
            ? sanitizedValue
            : current.monto,
        montos_por_mes: {
          ...(current.montos_por_mes || {}),
          [normalizedMonth]: {
            ...previous,
            personalizado: true,
            monto: sanitizedValue,
          },
        },
      };
    });
  };

  const updateBatchAmountOption = (index, optionId) => {
    setPaymentForm((current) => ({
      ...current,
      pagos: current.pagos.map((payment, paymentIndex) => {
        if (paymentIndex !== index) return payment;
        const options = Array.isArray(payment.opciones_monto)
          ? payment.opciones_monto
          : [];
        const option = options.find(
          (item) => String(item.id) === String(optionId),
        );
        if (!option) return payment;
        return {
          ...payment,
          opcion_monto_id: String(option.id),
          monto: String(option.monto ?? payment.monto ?? ""),
        };
      }),
    }));
  };

  const submitPayment = async (event) => {
    event.preventDefault();

    // Bloqueo sincrónico: React puede recibir un segundo submit antes de que
    // `saving` se refleje en el DOM. Sin este guard el primer POST registra
    // los pagos y el segundo puede responder SIN_CUOTAS_PENDIENTES, dejando
    // un error visible aunque el cobro haya sido exitoso.
    if (paymentSubmitInFlightRef.current) return;

    if (!paymentForm.id_medio_pago) {
      setFeedback({ type: "error", message: "Seleccioná el medio de pago." });
      return;
    }
    if (!paymentForm.fecha_pago) {
      setFeedback({ type: "error", message: "Completá la fecha de pago." });
      return;
    }

    if (paymentMode === "single") {
      if (!paymentForm.id_socio) {
        setFeedback({
          type: "error",
          message: `Seleccioná un ${tipo === "EMPRESA" ? "empresa" : "socio"}.`,
        });
        return;
      }
      if (!selectedMonthIds.length) {
        setFeedback({
          type: "error",
          message: "Seleccioná al menos un mes para registrar el pago.",
        });
        return;
      }
      if (
        selectedMonthIds.some((monthId) => {
          const amountState = paymentForm.montos_por_mes?.[monthId] || {};
          if (paymentForm.aplicar_familia && !amountState.personalizado) return false;
          return !(Number(decimalInput(amountState.monto)) > 0);
        })
      ) {
        setFeedback({
          type: "error",
          message: "Todos los meses seleccionados deben tener un monto mayor a cero.",
        });
        return;
      }
    } else if (
      !paymentForm.pagos.length ||
      paymentForm.pagos.some(
        (payment) => !(Number(decimalInput(payment.monto)) > 0),
      )
    ) {
      setFeedback({
        type: "error",
        message:
          "Todos los pagos seleccionados deben tener un monto mayor a cero.",
      });
      return;
    }

    paymentSubmitInFlightRef.current = true;
    setSaving(true);
    try {
      let response;
      if (paymentMode === "multiple") {
        response = await cuotasApi.registrarPagos({
          fecha_pago: paymentForm.fecha_pago,
          id_medio_pago: Number(paymentForm.id_medio_pago),
          pagos: paymentForm.pagos.map((payment) => ({
            id_socio: Number(payment.id_socio),
            anio: Number(payment.anio),
            mes: Number(payment.mes),
            monto: Number(decimalInput(payment.monto)),
            monto_personalizado: Boolean(payment.monto_personalizado),
          })),
        });
      } else if (paymentForm.aplicar_familia && family) {
        response = await cuotasApi.registrarPagos({
          id_socio: Number(paymentForm.id_socio),
          anio: Number(paymentForm.anio),
          meses: selectedMonthIds.map(Number),
          fecha_pago: paymentForm.fecha_pago,
          id_medio_pago: Number(paymentForm.id_medio_pago),
          aplicar_familia: true,
          montos_personalizados: Object.fromEntries(
            selectedMonthIds
              .filter((monthId) =>
                Boolean(paymentForm.montos_por_mes?.[monthId]?.personalizado),
              )
              .map((monthId) => [
                String(monthId),
                Number(
                  decimalInput(paymentForm.montos_por_mes?.[monthId]?.monto),
                ),
              ]),
          ),
        });
      } else if (selectedMonthIds.length > 1) {
        response = await cuotasApi.registrarPagos({
          fecha_pago: paymentForm.fecha_pago,
          id_medio_pago: Number(paymentForm.id_medio_pago),
          usar_saldo_favor: Boolean(paymentForm.usar_saldo_favor),
          ...(paymentForm.usar_saldo_favor
            ? {
                saldo_favor_aplicacion_esperada: Number(
                  paymentBalanceApplied.toFixed(2),
                ),
              }
            : {}),
          pagos: selectedMonthIds.map((monthId) => {
            const periodPrincipal =
              paymentPeriods[monthId]?.context?.principal;
            return {
              id_socio: Number(paymentForm.id_socio),
              anio: Number(paymentForm.anio),
              mes: Number(monthId),
              monto: Number(
                decimalInput(
                  paymentForm.montos_por_mes?.[monthId]?.monto ||
                  defaultAmountOption(periodPrincipal)?.monto ||
                  periodPrincipal?.monto_sugerido ||
                  periodPrincipal?.monto_base ||
                  selectedPartner?.monto_sugerido ||
                  0,
                ),
              ),
              monto_personalizado: Boolean(
                paymentForm.montos_por_mes?.[monthId]?.personalizado,
              ),
            };
          }),
        });
      } else {
        response = await cuotasApi.registrarPago({
          id_socio: Number(paymentForm.id_socio),
          anio: Number(paymentForm.anio),
          mes: Number(selectedMonthIds[0]),
          fecha_pago: paymentForm.fecha_pago,
          monto: Number(
            decimalInput(
              paymentForm.montos_por_mes?.[selectedMonthIds[0]]?.monto ||
                paymentForm.monto,
            ),
          ),
          id_medio_pago: Number(paymentForm.id_medio_pago),
          aplicar_familia: false,
          usar_saldo_favor: Boolean(paymentForm.usar_saldo_favor),
          ...(paymentForm.usar_saldo_favor
            ? {
                saldo_favor_aplicacion_esperada: Number(
                  paymentBalanceApplied.toFixed(2),
                ),
              }
            : {}),
          monto_personalizado: Boolean(
            paymentForm.montos_por_mes?.[selectedMonthIds[0]]?.personalizado,
          ),
        });
      }

      const selectedMedium = (catalogos.medios_pago || []).find(
        (item) =>
          String(item.id_medio_pago) === String(paymentForm.id_medio_pago),
      );
      const fallbackLines =
        paymentMode === "multiple"
          ? paymentForm.pagos.map((payment) => ({
              socio: payment.denominacion || `ID ${payment.id_socio}`,
              categoria: payment.categoria || "SIN CATEGORÍA",
              periodo: `${
                monthOptions.find(
                  (monthItem) =>
                    String(monthItem.id_mes) === String(payment.mes),
                )?.nombre || payment.mes
              } ${payment.anio}`,
              monto_base: Number(payment.monto_base || payment.monto || 0),
              porcentaje_descuento_familiar: Number(
                payment.porcentaje_descuento_familiar || 0,
              ),
              monto: Number(payment.monto || 0),
              domicilio: payment.domicilio || "",
              cobrador: payment.cobrador || "",
              medio_pago: selectedMedium?.nombre || "—",
            }))
          : selectedMonthIds.map((monthId) => {
              const periodPrincipal =
                paymentPeriods[monthId]?.context?.principal || principal || {};
              return {
                socio:
                  selectedPartner?.denominacion ||
                  periodPrincipal.denominacion ||
                  `ID ${paymentForm.id_socio}`,
                categoria:
                  periodPrincipal.categoria ||
                  selectedPartner?.categoria ||
                  "SIN CATEGORÍA",
                periodo: `${
                  monthOptions.find(
                    (monthItem) =>
                      String(monthItem.id_mes) === String(monthId),
                  )?.nombre || monthId
                } ${paymentForm.anio}`,
                monto_base: Number(
                  periodPrincipal.monto_base ||
                    selectedPartner?.monto_base ||
                    periodPrincipal.monto_sugerido ||
                    paymentForm.monto ||
                    0,
                ),
                porcentaje_descuento_familiar: Number(
                  periodPrincipal.porcentaje_descuento_familiar ||
                    selectedPartner?.porcentaje_descuento_familiar ||
                    0,
                ),
                monto: Number(
                  paymentForm.montos_por_mes?.[monthId]?.monto ||
                    defaultAmountOption(periodPrincipal)?.monto ||
                    periodPrincipal.monto_sugerido ||
                    periodPrincipal.monto_base ||
                    paymentForm.monto ||
                    0,
                ),
                domicilio:
                  selectedPartner?.domicilio_2 ||
                  selectedPartner?.domicilio ||
                  selectedPartner?.direccion ||
                  "",
                cobrador:
                  periodPrincipal.cobrador || selectedPartner?.cobrador || "",
                medio_pago: selectedMedium?.nombre || "—",
              };
            });
      const receiptPeople =
        paymentMode === "multiple"
          ? paymentForm.pagos
              .map((payment) => payment.denominacion)
              .filter(Boolean)
              .join(" · ")
          : selectedPartner?.denominacion || "";

      setPaymentOpen(false);
      setReceipt(
        enrichPaymentReceipt(response.comprobante || null, {
          socios: receiptPeople,
          domicilio:
            selectedPartner?.domicilio_2 ||
            selectedPartner?.domicilio ||
            selectedPartner?.direccion ||
            "",
          cobrador: principal?.cobrador || selectedPartner?.cobrador || "",
          medio: selectedMedium?.nombre || "—",
          tipoEntidad: tipo,
          lineas: fallbackLines,
        }),
      );
      pendingTableScrollRef.current = tableBodyRef.current?.scrollTop || 0;
      setFeedback(null);
      clearMultipleSelection();
      // Conservamos pestaña, período, página y posición de la tabla. El pago
      // desaparece de Deudores al refrescar, pero el usuario sigue exactamente
      // en el contexto desde el que abrió el modal.
      await Promise.all([cargar(), cargarTotalesEstado()]);
    } catch (err) {
      if (err.code === "SALDO_FAVOR_MODIFICADO" && paymentMode !== "multiple") {
        await loadPaymentPeriods(
          paymentForm.id_socio,
          paymentForm.anio,
          paymentForm.fecha_pago,
          {
            selectedMonths: selectedMonthIds,
            activeMonth: paymentForm.mes,
            defaultFamily: false,
            defaultUseBalance: false,
          },
        );
      }
      setFeedback({ type: "error", message: err.message });
    } finally {
      paymentSubmitInFlightRef.current = false;
      setSaving(false);
    }
  };

  const deletePayment = async () => {
    const response = await cuotasApi.eliminarPago(deleteRow.id_pago);
    setDeleteRow(null);
    setEstado("DEUDORES");
    setFeedback({ type: "success", message: response.mensaje });
    // Si era el último pago de un año futuro, refrescamos los años visibles
    // sin bloquear el cierre ni el feedback del modal.
    void cargarCatalogos();
    void cargarTotalesEstado();
    return response;
  };

  const condonePayment = async () => {
    if (!condoneRow) return null;
    const response = await cuotasApi.condonarPago({
      id_socio: Number(condoneRow.id_socio),
      anio: Number(condoneRow.anio),
      mes: Number(condoneRow.mes),
      fecha_condonacion: localToday(),
    });
    pendingTableScrollRef.current = tableBodyRef.current?.scrollTop || 0;
    setCondoneRow(null);
    setFeedback({ type: "success", message: response.mensaje });
    await Promise.all([cargar(), cargarTotalesEstado(), cargarCatalogos()]);
    return response;
  };

  const toggleSelection = (item) => {
    const key = selectionKey(item);
    setSelectedPayments((current) => {
      const next = { ...current };
      if (next[key]) delete next[key];
      else next[key] = item;
      return next;
    });
  };

  const selectRow = (event, item) => {
    if (!multiMode || isResolved || !writable) return;
    if (!(event.target instanceof Element)) return;

    const interactiveElement = event.target.closest(
      'button, input, select, textarea, a, label, [role="button"]',
    );
    if (interactiveElement) return;

    toggleSelection(item);
  };

  const selectRowWithKeyboard = (event, item) => {
    if (!multiMode || isResolved || !writable) return;
    if (event.target !== event.currentTarget) return;
    if (event.key !== "Enter" && event.key !== " ") return;

    event.preventDefault();
    toggleSelection(item);
  };

  // Mantiene estable la tabla mientras cambian estados exclusivos del modal de pago.
  // Las filas leen siempre los handlers actuales desde este ref sin volver a renderizarse.
  rowActionsRef.current = {
    selectRow,
    selectRowWithKeyboard,
    toggleSelection,
    printPaymentRow,
    openPayment,
    setCondoneRow,
    setDeleteRow,
  };

  const setTypeFilter = (value) => {
    setTipo(value);
    setBuscar("");
  };

  const setYearFilter = (value) => {
    setAnio(value);
  };

  const setMonthFilter = (value) => {
    setMes(value);
  };

  const toggleAllFilteredPayments = async () => {
    const requestId = ++selectAllRequestId.current;
    setSelectingAll(true);
    try {
      const records = await obtenerTodosFiltrados();
      if (requestId !== selectAllRequestId.current) return;

      const filteredEntries = Object.fromEntries(
        records.map((item) => [selectionKey(item), item]),
      );
      const filteredKeys = Object.keys(filteredEntries);
      setKnownFilteredSelectionKeys((current) => ({
        ...current,
        [selectionFilterKey]: filteredKeys,
      }));
      setSelectedPayments((current) => {
        const deselectCurrentFilter =
          filteredKeys.length > 0 &&
          filteredKeys.every((key) => Boolean(current[key]));
        const next = { ...current };

        if (deselectCurrentFilter) {
          filteredKeys.forEach((key) => delete next[key]);
        } else {
          Object.assign(next, filteredEntries);
        }

        return next;
      });
    } catch (err) {
      if (requestId !== selectAllRequestId.current) return;
      setFeedback({
        type: "error",
        message:
          err.message ||
          "No se pudieron seleccionar todos los registros filtrados.",
      });
    } finally {
      if (requestId === selectAllRequestId.current) setSelectingAll(false);
    }
  };

  const setPaymentMethodFilter = (value) => {
    setMedioPago(value);
  };

  const pageFilters = [
    {
      key: "tipo",
      type: "tabs",
      label: "Tipo",
      ariaLabel: "Secciones de cuotas",
      value: tipo,
      onChange: setTypeFilter,
      options: [
        { value: "PERSONA", label: "Socios" },
        { value: "EMPRESA", label: "Empresas" },
      ],
    },
    {
      key: "estado",
      type: "tabs",
      label: "Estado",
      ariaLabel: "Estado de las cuotas",
      value: estado,
      onChange: (value) => {
        setEstado(value);
        setPagina(1);
        if (value === "SALDOS_FAVOR") clearMultipleSelection();
      },
      options: [
        {
          value: "DEUDORES",
          label: (
            <span className="cuotas-state-tabContent">
              <span className="cuotas-state-tabText">Deudores</span>
              <span
                className={`cuotas-state-tabBadge ${estadoTotales.DEUDORES == null ? "is-pending" : ""}`.trim()}
                aria-label={estadoTotales.DEUDORES == null ? "Total de deudores cargando" : `${estadoTotales.DEUDORES} deudores`}
              >
                {estadoTotales.DEUDORES ?? "…"}
              </span>
            </span>
          ),
        },
        {
          value: "PAGADOS",
          label: (
            <span className="cuotas-state-tabContent">
              <span className="cuotas-state-tabText">Pagados</span>
              <span
                className={`cuotas-state-tabBadge ${estadoTotales.PAGADOS == null ? "is-pending" : ""}`.trim()}
                aria-label={estadoTotales.PAGADOS == null ? "Total de pagados cargando" : `${estadoTotales.PAGADOS} pagados`}
              >
                {estadoTotales.PAGADOS ?? "…"}
              </span>
            </span>
          ),
        },
        {
          value: "CONDONADOS",
          label: (
            <span className="cuotas-state-tabContent">
              <span className="cuotas-state-tabText">Condonados</span>
              <span
                className={`cuotas-state-tabBadge ${estadoTotales.CONDONADOS == null ? "is-pending" : ""}`.trim()}
                aria-label={estadoTotales.CONDONADOS == null ? "Total de condonados cargando" : `${estadoTotales.CONDONADOS} condonados`}
              >
                {estadoTotales.CONDONADOS ?? "…"}
              </span>
            </span>
          ),
        },
        {
          value: "SALDOS_FAVOR",
          label: (
            <span className="cuotas-state-tabContent">
              <span className="cuotas-state-tabText">Saldos a favor</span>
              <span
                className={`cuotas-state-tabBadge ${estadoTotales.SALDOS_FAVOR == null ? "is-pending" : ""}`.trim()}
                aria-label={estadoTotales.SALDOS_FAVOR == null ? "Total de saldos a favor cargando" : `${estadoTotales.SALDOS_FAVOR} saldos a favor`}
              >
                {estadoTotales.SALDOS_FAVOR ?? "…"}
              </span>
            </span>
          ),
        },
      ],
    },
    {
      key: "buscar",
      type: "search",
      label: "Búsqueda",
      placeholder: "",
      value: buscar,
      onChange: setBuscar,
      className: "cuotas-search-filter",
    },
    {
      key: "anio",
      type: "select",
      label: "Año",
      value: anio,
      onChange: setYearFilter,
      includeEmptyOption: false,
      options: visibleYearOptions.map((value) => ({ value, label: value })),
      className: "cuotas-year-filter",
    },
    {
      key: "mes",
      type: "select",
      label: "Mes",
      value: mes,
      onChange: setMonthFilter,
      includeEmptyOption: false,
      options: (catalogos.meses || []).map((item) => ({
        value: item.id_mes,
        label: item.nombre,
      })),
      className: "cuotas-month-filter",
    },
    {
      key: "medio_pago",
      type: "select",
      label: "Medio de pago",
      placeholder: "Todos",
      value: medioPago,
      onChange: setPaymentMethodFilter,
      options: (catalogos.medios_pago || []).map((item) => ({
        value: item.id_medio_pago,
        label: item.nombre,
      })),
      className: "cuotas-payment-method-filter",
    },
  ].filter(
    (filter) =>
      !isBalanceView || !["anio", "mes", "medio_pago"].includes(filter.key),
  );

  const tableLabel = isBalanceView
    ? `Saldos a favor de ${tipo === "EMPRESA" ? "empresas" : "socios"}`
    : `Cuotas de ${tipo === "EMPRESA" ? "empresas" : "socios"} ${isPaid ? "pagadas" : isCondoned ? "condonadas" : "adeudadas"}`;
  const baseDebtColumns = [
    tipo === "EMPRESA" ? "Empresa" : "Socio",
    "Categoría",
    "Período",
    "Medio de pago",
    "Importe",
    "Acciones",
  ];
  const columns = isBalanceView
    ? [
        tipo === "EMPRESA" ? "Empresa" : "Socio",
        "Categoría",
        "Último movimiento",
        "Fecha",
        "Origen",
        "Saldo a favor",
        "Acciones",
      ]
    : isResolved
    ? [
        tipo === "EMPRESA" ? "Empresa" : "Socio",
        "Categoría",
        "Período",
        "Estado",
        "Fecha",
        "Medio de pago",
        "Importe",
        "Acciones",
      ]
    : multiMode
      ? ["Selec.", ...baseDebtColumns.slice(0, -1)]
      : baseDebtColumns;

  const debtGridClass = multiMode
    ? "cuotas-grid cuotas-grid--debt cuotas-grid--selecting"
    : "cuotas-grid cuotas-grid--debt";
  const debtRowClass = multiMode
    ? "cuotas-grid--debt cuotas-grid--selecting"
    : "cuotas-grid--debt";
  const toggleMultipleMode = () => {
    if (multiMode) clearMultipleSelection();
    else setMultiMode(true);
  };
  const openExport = () => {
    if (loading || totalRegistros <= 0) {
      setFeedback({
        type: "warning",
        message: loading
          ? "Esperá a que terminen de cargarse las cuotas."
          : "No hay registros para exportar con los filtros actuales.",
      });
      return;
    }
    setExportOpen(true);
  };

  const balancePartnerOptions =
    tipo === "EMPRESA" ? catalogos.empresas || [] : catalogos.socios || [];
  const filteredBalancePartnerOptions = useMemo(() => {
    const query = normalizeSearchText(balancePartnerSearch);
    if (!query) return balancePartnerOptions;

    return balancePartnerOptions.filter((partner) =>
      normalizeSearchText(
        `${partner.denominacion || ""} ${partner.documento || ""}`,
      ).includes(query),
    );
  }, [balancePartnerOptions, balancePartnerSearch]);

  const openNewBalance = () => {
    setBalanceEditingRow(null);
    setBalanceForm(emptyBalanceForm());
    setBalancePartnerSearch("");
    setBalanceModalOpen(true);
  };

  const openEditBalance = (row) => {
    const currentBalance = Number(row.saldo_favor || 0);

    setBalanceEditingRow(row);
    setBalanceForm({
      id_socio: String(row.id_socio),
      saldo_objetivo:
        Number.isFinite(currentBalance) && currentBalance > 0
          ? currentBalance.toFixed(2)
          : "",
      detalle: "",
    });
    setBalanceModalOpen(true);
  };

  const closeBalanceModal = () => {
    if (balanceSaving) return;
    setBalanceModalOpen(false);
    setBalanceEditingRow(null);
    setBalanceForm(emptyBalanceForm());
    setBalancePartnerSearch("");
  };

  const saveBalance = async (event) => {
    event.preventDefault();
    if (balanceSaving) return;

    const partnerId = Number(
      balanceEditingRow?.id_socio || balanceForm.id_socio || 0,
    );
    const targetBalance = Number(balanceForm.saldo_objetivo || 0);
    if (!partnerId) {
      setFeedback({
        type: "error",
        message: `Seleccioná ${tipo === "EMPRESA" ? "una empresa" : "un socio"}.`,
      });
      return;
    }
    if (!Number.isFinite(targetBalance) || targetBalance <= 0) {
      setFeedback({
        type: "error",
        message: "Ingresá un saldo a favor mayor a cero.",
      });
      return;
    }

    setBalanceSaving(true);
    try {
      await cuotasApi.ajustarSaldoFavor({
        id_socio: partnerId,
        operacion: balanceEditingRow ? "EDITAR" : "CREAR",
        saldo_objetivo: targetBalance,
        detalle: balanceForm.detalle.trim() || undefined,
      });
      setFeedback({
        type: "success",
        message: balanceEditingRow
          ? "Saldo a favor actualizado correctamente."
          : "Saldo a favor agregado correctamente.",
      });
      setBalanceModalOpen(false);
      setBalanceEditingRow(null);
      setBalanceForm(emptyBalanceForm());
      await Promise.all([cargar(), cargarTotalesEstado()]);
    } catch (err) {
      setFeedback({
        type: "error",
        message: err.message || "No se pudo actualizar el saldo a favor.",
      });
    } finally {
      setBalanceSaving(false);
    }
  };

  const deleteBalance = async ({ motivo }) => {
    if (!balanceDeleteRow) return { ok: false, mensaje: "No hay saldo seleccionado." };

    try {
      await cuotasApi.ajustarSaldoFavor({
        id_socio: balanceDeleteRow.id_socio,
        operacion: "ELIMINAR",
        detalle: motivo || "Saldo a favor eliminado manualmente.",
      });
      await Promise.all([cargar(), cargarTotalesEstado()]);
      return {
        ok: true,
        mensaje: "Saldo a favor eliminado correctamente.",
      };
    } catch (err) {
      return {
        ok: false,
        mensaje: err.message || "No se pudo eliminar el saldo a favor.",
      };
    }
  };

  return (
    <>
      <ModulePage
        className="cuotas-page"
        title="Cuotas"
        description="Control mensual de cuotas de socios y empresas."
        filters={pageFilters}
        tabsInTitle
        headLeftClassName="cuotas-header-row"
        headFiltersContainerClassName={`cuotas-head-filters ${isBalanceView ? "cuotas-head-filters--balance" : ""}`.trim()}
        headerActions={
          <BotonExportarGlobal
            className="cuotas-export-action"
            label="Exportar"
            loading={loading}
            disabled={totalRegistros === 0}
            onClick={openExport}
            title="Exportar cuotas"
          />
        }
        secondaryActions={
          isBalanceView && writable
            ? [
                {
                  key: "add-balance",
                  label: "Agregar saldo",
                  icon: faPlus,
                  onClick: openNewBalance,
                  className: "mov-btn--primary",
                },
              ]
            : !isResolved && writable
              ? [
                  {
                    key: "multiple-selection",
                    label: multiMode
                      ? "Cancelar selección"
                      : "Selección múltiple",
                    icon: faUserGroup,
                    onClick: toggleMultipleMode,
                    disabled: selectingAll,
                    className: multiMode
                      ? "mov-btn--danger cuotas-multiple-action"
                      : "mov-btn--primary cuotas-multiple-action",
                  },
                ]
              : []
        }
        canCreate={false}
        refreshing={loading}
        notice={
          !writable
            ? "Tu usuario tiene permiso de consulta. Registrar, condonar y eliminar cuotas está deshabilitado."
            : null
        }
      >
        <ModuleFeedback
          type={feedback?.type || "error"}
          message={feedback?.message || error}
          duration={feedback?.duration}
          onClose={() => setFeedback(null)}
        />

        {multiMode ? (
          <Toast
            tipo="info"
            persistente
            cerrarConEscape
            cerrarConInteraccion={false}
            cierreDeshabilitado={saving || selectingAll}
            onClose={cancelMultipleSelection}
            className="cuotas-selection-toast"
            ariaLabelCerrar="Cancelar selección múltiple"
            mensaje={
              <div className="cuotas-selection-toast__copy">
                <strong>
                  {selectedCount} cuota{selectedCount === 1 ? "" : "s"}{" "}
                  seleccionada{selectedCount === 1 ? "" : "s"}
                </strong>
                <span>
                  {selectingAll
                    ? "Seleccionando todos los registros filtrados…"
                    : "Hacé clic en una fila o seleccioná todos los resultados."}
                </span>
              </div>
            }
            acciones={
              <>
                <button
                  type="button"
                  className="mov-btn mov-btn--ghost cuotas-select-all-toast-btn"
                  onClick={toggleAllFilteredPayments}
                  disabled={!totalRegistros || saving || selectingAll}
                >
                  {selectingAll
                    ? "Seleccionando…"
                    : allFilteredPaymentsSelected
                      ? "Deseleccionar todos"
                      : "Seleccionar todos"}
                </button>
                <button
                  type="button"
                  className="mov-btn mov-btn--ghost"
                  onClick={clearSelectedPayments}
                  disabled={!selectedCount || saving || selectingAll}
                >
                  Limpiar
                </button>
                <button
                  type="button"
                  className="mov-btn mov-btn--primary"
                  onClick={openMultiplePayment}
                  disabled={!selectedCount || saving || selectingAll}
                >
                  Continuar ({selectedCount})
                </button>
              </>
            }
          />
        ) : null}

        <GlobalDivTable
          className={`cuotas-table ${totalRegistros ? "has-bottom-pagination" : ""}`.trim()}
          bodyClassName="entity-table-wrap"
          bodyRef={tableBodyRef}
          gridClassName={
            isBalanceView
              ? "cuotas-grid cuotas-grid--balance"
              : isResolved
                ? "cuotas-grid cuotas-grid--paid"
                : debtGridClass
          }
          ariaLabel={tableLabel}
          empty={!loading && !error && !items.length}
          loading={loading}
          loadingLabel={isBalanceView ? "Cargando saldos a favor..." : "Cargando cuotas..."}
          skeletonRows={8}
          columns={columns}
        >
          {!loading && !error && !items.length ? (
            <div className="module-empty">
              <FontAwesomeIcon icon={isResolved ? faReceipt : faWallet} />
              <strong>
                {isBalanceView
                  ? "No hay saldos a favor"
                  : isPaid
                  ? "No hay pagos registrados"
                  : isCondoned
                    ? "No hay cuotas condonadas"
                    : "No hay deudores"}
              </strong>
              <span>
                {isBalanceView
                  ? "No hay socios con crédito disponible para los filtros seleccionados."
                  : isPaid
                  ? "No existen pagos para el mes, año y filtros seleccionados."
                  : isCondoned
                    ? "No existen condonaciones para el mes, año y filtros seleccionados."
                    : "Todos los registros del período están pagados, condonados o todavía no debían cuota."}
              </span>
            </div>
          ) : null}

          {isBalanceView ? (
            <SaldoFavorTableRows
              items={itemsPagina}
              tipo={tipo}
              writable={writable}
              onEdit={openEditBalance}
              onDelete={setBalanceDeleteRow}
            />
          ) : (
            <CuotasTableRows
              items={itemsPagina}
              selectedPayments={selectedPayments}
              isResolved={isResolved}
              isCondoned={isCondoned}
              multiMode={multiMode}
              writable={writable}
              tipo={tipo}
              debtRowClass={debtRowClass}
              actionsRef={rowActionsRef}
            />
          )}
        </GlobalDivTable>

        <div className="cuotas-table-footer">
          {totalRegistros ? (
            <nav
              className="cuotas-pagination"
              aria-label="Paginación de cuotas"
            >
              <p className="cuotas-pagination__summary">
                Mostrando <strong>{registroDesde}</strong>–
                <strong>{registroHasta}</strong> de{" "}
                <strong>{totalRegistros}</strong> registros
                {loading ? <span>Cargando página...</span> : null}
              </p>

              <div className="cuotas-pagination__controls">
                <button
                  type="button"
                  onClick={() => setPagina((actual) => Math.max(1, actual - 1))}
                  disabled={loading || pagina <= 1}
                >
                  Anterior
                </button>

                {opcionesPagina.map((item) =>
                  typeof item === "number" ? (
                    <button
                      type="button"
                      key={item}
                      className={item === pagina ? "is-active" : ""}
                      aria-current={item === pagina ? "page" : undefined}
                      onClick={() => setPagina(item)}
                      disabled={loading}
                    >
                      {item}
                    </button>
                  ) : (
                    <span
                      className="cuotas-pagination__ellipsis"
                      key={item}
                      aria-hidden="true"
                    >
                      …
                    </span>
                  ),
                )}

                <button
                  type="button"
                  onClick={() =>
                    setPagina((actual) => Math.min(totalPaginas, actual + 1))
                  }
                  disabled={loading || pagina >= totalPaginas}
                >
                  Siguiente
                </button>
              </div>
            </nav>
          ) : null}

          <div
            className="cuotas-lower-actions"
            aria-label="Acciones de cuotas"
          >
            {!isBalanceView ? (
              <label className="module-filter module-filter--select is-active cuotas-lower-year-filter">
                <select
                  className="module-filterControl"
                  aria-label="Año"
                  value={anio}
                  onChange={(event) => setYearFilter(event.target.value)}
                >
                  {visibleYearOptions.map((value) => (
                    <option key={value} value={value}>
                      {value}
                    </option>
                  ))}
                </select>
                <span className="module-floatingLabel">Año</span>
              </label>
            ) : null}

            {!isBalanceView ? (
              <button
                type="button"
                className="mov-btn mov-btn--primary mov-btn--compact cuotas-lower-action cuotas-print-all-action"
                onClick={openPrintAll}
                disabled={loading || printingAll || totalRegistros === 0}
                title="Imprimir todos los comprobantes"
              >
                <FontAwesomeIcon icon={faPrint} />
                Imprimir todos
              </button>
            ) : null}

            <BotonExportarGlobal
              className="mov-btn--compact cuotas-lower-action cuotas-export-action"
              label="Exportar"
              loading={loading}
              disabled={totalRegistros === 0}
              onClick={openExport}
              title="Exportar cuotas"
            />

            {writable && isBalanceView ? (
              <button
                type="button"
                className="mov-btn mov-btn--primary mov-btn--compact cuotas-lower-action cuotas-add-balance-action"
                onClick={openNewBalance}
              >
                <FontAwesomeIcon icon={faPlus} />
                Agregar saldo
              </button>
            ) : null}

            {writable && !isResolved && !isBalanceView ? (
              <button
                type="button"
                className={`mov-btn cuotas-lower-action cuotas-multiple-action ${multiMode ? "mov-btn--danger" : "mov-btn--primary"}`}
                onClick={toggleMultipleMode}
                disabled={selectingAll}
              >
                <FontAwesomeIcon icon={faUserGroup} />
                {multiMode ? "Cancelar selección" : "Selección múltiple"}
              </button>
            ) : null}
          </div>
        </div>
      </ModulePage>

      <CrudModal
        open={balanceModalOpen}
        title={balanceEditingRow ? "Editar saldo a favor" : "Agregar saldo a favor"}
        subtitle={
          balanceEditingRow
            ? "Definí el saldo total que debe quedar disponible para esta persona."
            : "Cargá un saldo manual para un socio o empresa. El ajuste queda registrado en el historial."
        }
        onClose={closeBalanceModal}
        onSubmit={saveBalance}
        saving={balanceSaving}
        submitLabel={balanceEditingRow ? "Guardar cambios" : "Agregar saldo"}
        closeOnBackdrop={false}
        modalClassName="cuotas-balance-modal"
      >
        <div className="cuotas-balance-form">
          {balanceEditingRow ? (
            <div className="cuotas-balance-form__field">
              <div
                className="cuotas-balance-partner-card"
                aria-label={`${tipo === "EMPRESA" ? "Empresa" : "Socio"} seleccionado`}
              >
                <span className="cuotas-balance-partner-card__icon" aria-hidden="true">
                  <FontAwesomeIcon icon={faUserGroup} />
                </span>
                <div className="cuotas-balance-partner-card__identity">
                  <small>{tipo === "EMPRESA" ? "Empresa seleccionada" : "Socio seleccionado"}</small>
                  <strong title={balanceEditingRow.denominacion || ""}>
                    {balanceEditingRow.denominacion || "SIN DENOMINACIÓN"}
                  </strong>
                  <span>
                    {balanceEditingRow.documento
                      ? `${tipo === "EMPRESA" ? "CUIT" : "DNI"} ${balanceEditingRow.documento}`
                      : `ID ${balanceEditingRow.id_socio}`}
                    {balanceEditingRow.categoria
                      ? ` · ${balanceEditingRow.categoria}`
                      : ""}
                  </span>
                </div>
                <div className="cuotas-balance-partner-card__balance">
                  <small>Saldo actual</small>
                  <strong>{money(balanceEditingRow.saldo_favor)}</strong>
                </div>
              </div>
            </div>
          ) : (
            <div className="cuotas-balance-form__field cuotas-balance-form__field--floating cuotas-balance-form__field--partner">
              <div className="cuotas-balance-partner-picker">
                <FloatingField
                  label={tipo === "EMPRESA" ? "Buscar empresa" : "Buscar socio"}
                  active
                  placeholderOnFloat
                  className="cuotas-balance-floating-field cuotas-balance-partner-floating-field"
                >
                  <input
                    type="search"
                    aria-label={tipo === "EMPRESA" ? "Buscar empresa" : "Buscar socio"}
                    placeholder={
                      tipo === "EMPRESA"
                        ? "Razón social o CUIT..."
                        : "Nombre, apellido o DNI..."
                    }
                    value={balancePartnerSearch}
                    onChange={(event) => {
                      setBalancePartnerSearch(event.target.value);
                      setBalanceForm((current) => ({
                        ...current,
                        id_socio: "",
                      }));
                    }}
                    autoFocus
                  />
                </FloatingField>

                <FloatingField
                  label={`${tipo === "EMPRESA" ? "Empresa" : "Socio"} *`}
                  active
                  className="cuotas-balance-floating-field cuotas-balance-partner-floating-field"
                >
                  <select
                    aria-label={tipo === "EMPRESA" ? "Empresa" : "Socio"}
                    value={balanceForm.id_socio}
                    onChange={(event) =>
                      setBalanceForm((current) => ({
                        ...current,
                        id_socio: event.target.value,
                      }))
                    }
                    required
                  >
                    <option value="">
                      {filteredBalancePartnerOptions.length
                        ? "Seleccionar..."
                        : "Sin resultados"}
                    </option>
                    {filteredBalancePartnerOptions.map((partner) => (
                      <option key={partner.id_socio} value={partner.id_socio}>
                        {partner.denominacion}
                        {partner.documento ? ` · ${partner.documento}` : ""}
                      </option>
                    ))}
                  </select>
                </FloatingField>

                <small className="cuotas-balance-form__help cuotas-balance-partner-picker__count">
                  {balancePartnerSearch
                    ? `${filteredBalancePartnerOptions.length} resultado${
                        filteredBalancePartnerOptions.length === 1 ? "" : "s"
                      }`
                    : `${balancePartnerOptions.length} ${
                        tipo === "EMPRESA" ? "empresas" : "socios"
                      } disponibles`}
                </small>
              </div>
            </div>
          )}

          <div className="cuotas-balance-form__field cuotas-balance-form__field--floating">
            <FloatingField
              label="Saldo a favor total *"
              active
              placeholderOnFloat
              className="cuotas-balance-floating-field"
            >
              <input
                type="text"
                inputMode="decimal"
                aria-label="Saldo a favor total"
                value={balanceForm.saldo_objetivo}
                onChange={(event) =>
                  setBalanceForm((current) => ({
                    ...current,
                    saldo_objetivo: decimalInput(event.target.value, 10, 2),
                  }))
                }
                placeholder="0.00"
                required
              />
            </FloatingField>
            <small className="cuotas-balance-form__help">
              {balanceEditingRow
                ? `Saldo actual: ${money(balanceEditingRow.saldo_favor)}. Se registrará sólo la diferencia necesaria.`
                : "Este importe quedará disponible para próximos pagos."}
            </small>
          </div>

          <div className="cuotas-balance-form__field cuotas-balance-form__field--floating">
            <FloatingField
              label="Observación"
              active
              textarea
              placeholderOnFloat
              className="cuotas-balance-floating-field"
            >
              <textarea
                aria-label="Observación del saldo a favor"
                value={balanceForm.detalle}
                onChange={(event) =>
                  setBalanceForm((current) => ({
                    ...current,
                    detalle: event.target.value,
                  }))
                }
                rows={3}
                maxLength={500}
                placeholder="Motivo opcional del ajuste..."
              />
            </FloatingField>
          </div>

          <p className="cuotas-balance-form__help">
            Agregar, editar o eliminar un saldo no borra movimientos anteriores:
            el sistema registra un ajuste manual para conservar toda la trazabilidad.
          </p>
        </div>
      </CrudModal>

      <ModalEliminarGlobal
        open={Boolean(balanceDeleteRow)}
        operacion="eliminar"
        row={balanceDeleteRow}
        onClose={() => setBalanceDeleteRow(null)}
        onConfirm={deleteBalance}
        title="Eliminar saldo a favor"
        message="¿Seguro que querés dejar este saldo a favor en $0,00?"
        warning="No se borra el historial. Se registrará un ajuste manual por el saldo completo y quedará trazabilidad del cambio."
        confirmLabel="Eliminar saldo"
        loadingMessage="Eliminando saldo a favor…"
        successMessage="Saldo a favor eliminado correctamente."
        errorMessage="No se pudo eliminar el saldo a favor."
        showReason
        reasonLabel="Motivo u observación"
        reasonPlaceholder="Motivo opcional de la eliminación..."
        details={[
          {
            label: tipo === "EMPRESA" ? "Empresa" : "Socio",
            value: balanceDeleteRow?.denominacion,
          },
          {
            label: "Saldo actual",
            value: money(balanceDeleteRow?.saldo_favor),
          },
          {
            label: "Saldo final",
            value: money(0),
          },
        ]}
      />

      <ModalExportarGlobal
        open={exportOpen}
        loading={loading}
        title="Exportar cuotas"
        subtitle="Elegí el formato y si querés exportar la página actual o todos los resultados filtrados."
        tituloArchivo={`Cuotas - ${exportStatusLabel}`}
        subtituloArchivoActual={`${exportFilterSubtitle} · Página ${pagina} de ${Math.max(1, totalPaginas)}`}
        subtituloArchivoTodos={exportFilterSubtitle}
        nombreArchivo={`cuotas_${tipo.toLowerCase()}_${estado.toLowerCase()}_${anio}_${mes}`}
        columnas={exportColumns}
        registrosActuales={itemsPagina}
        obtenerRegistrosTodos={obtenerTodosFiltrados}
        cantidadActual={itemsPagina.length}
        totalTodos={totalRegistros}
        alcanceActualLabel="Exportar página actual"
        alcanceActualDescription="Descarga únicamente los registros visibles en esta página."
        alcanceTodosLabel="Exportar todos los resultados"
        alcanceTodosDescription="Descarga todos los registros que coinciden con los filtros actuales."
        note="La exportación respeta el tipo, estado, período, medio de pago y búsqueda seleccionados."
        onClose={() => setExportOpen(false)}
        onSuccess={(message) =>
          setFeedback({ type: "success", message, duration: 4200 })
        }
        onError={(message) =>
          setFeedback({ type: "error", message, duration: 5200 })
        }
      />

      {printMonthsOpen ? (
        <ModalMesCuotas
          mesesSeleccionados={selectedPrintMonths}
          onMesSeleccionadosChange={setSelectedPrintMonths}
          onCancelar={() => {
            if (!printingAll) setPrintMonthsOpen(false);
          }}
          onImprimir={handlePrintAll}
          loading={printingAll}
        />
      ) : null}

      <ModalPagoCuota
        paymentOpen={paymentOpen}
        paymentMode={paymentMode}
        tipo={tipo}
        paymentForm={paymentForm}
        entityLabel={entityLabel}
        closePayment={closePayment}
        submitPayment={submitPayment}
        saving={saving}
        selectedMonthIds={selectedMonthIds}
        family={family}
        familyPaymentCount={familyPaymentCount}
        contextLoading={contextLoading}
        paymentTotal={paymentTotal}
        saldoFavorDisponible={paymentBalance}
        saldoFavorAplicado={paymentBalanceApplied}
        importeCobrarAhora={paymentAmountToCollect}
        money={money}
        selectedPartner={selectedPartner}
        principal={principal}
        setPaymentForm={setPaymentForm}
        updatePaymentDate={updatePaymentDate}
        paymentYearOptions={paymentYearOptions}
        updatePaymentYear={updatePaymentYear}
        paymentPeriodAmount={paymentPeriodAmount}
        availableMonthIds={availableMonthIds}
        allAvailableMonthsSelected={allAvailableMonthsSelected}
        toggleAllPaymentMonths={toggleAllPaymentMonths}
        monthOptions={monthOptions}
        paymentPeriods={paymentPeriods}
        togglePaymentMonth={togglePaymentMonth}
        catalogos={catalogos}
        updateMonthAmountOption={updateMonthAmountOption}
        toggleMonthCustomAmount={toggleMonthCustomAmount}
        updateMonthCustomAmount={updateMonthCustomAmount}
        updateBatchAmountOption={updateBatchAmountOption}
      />

      <ModalComprobantePago
        open={Boolean(receipt)}
        comprobante={receipt}
        onClose={() => setReceipt(null)}
        onPrint={() => openPaymentReceipt(receipt, { openPrintDialog: true })}
        onExportPdf={() => downloadPaymentReceiptPdf(receipt)}
      />

      <ModalEliminarGlobal
        open={Boolean(condoneRow)}
        operacion="advertencia"
        row={condoneRow}
        onClose={() => setCondoneRow(null)}
        onConfirm={condonePayment}
        title="Condonar cuota"
        message="¿Seguro que querés condonar esta cuota?"
        warning="El período dejará de figurar como deuda, pero no se registrará ningún ingreso: quedará con estado CONDONADO e importe $0,00."
        confirmLabel="Condonar cuota"
        loadingMessage="Condonando cuota…"
        successMessage="Cuota condonada correctamente."
        errorMessage="No se pudo condonar la cuota."
        details={[
          {
            label: tipo === "EMPRESA" ? "Empresa" : "Socio",
            value: condoneRow?.denominacion,
          },
          { label: "Período", value: condoneRow?.periodo },
          { label: "Estado final", value: "CONDONADO" },
          { label: "Importe contable", value: money(0) },
        ]}
      />

      <ModalEliminarGlobal
        open={Boolean(deleteRow)}
        operacion="eliminar"
        row={deleteRow}
        onClose={() => setDeleteRow(null)}
        onConfirm={deletePayment}
        title={deleteRow?.estado === "CONDONADO" ? "Eliminar condonación" : "Eliminar pago registrado"}
        message={deleteRow?.estado === "CONDONADO" ? "¿Seguro que querés eliminar esta condonación?" : "¿Seguro que querés eliminar este pago?"}
        warning={
          Number(deleteRow?.monto_saldo_favor_aplicado || 0) > 0
            ? `La cuota volverá a aparecer en Deudores y ${money(deleteRow?.monto_saldo_favor_aplicado)} volverán al saldo a favor del socio.`
            : "La cuota volverá a aparecer en Deudores para el mismo mes y año."
        }
        confirmLabel={deleteRow?.estado === "CONDONADO" ? "Eliminar condonación" : "Eliminar pago"}
        loadingMessage={deleteRow?.estado === "CONDONADO" ? "Eliminando condonación…" : "Eliminando pago…"}
        successMessage={deleteRow?.estado === "CONDONADO" ? "Condonación eliminada correctamente." : "Pago eliminado correctamente."}
        errorMessage={deleteRow?.estado === "CONDONADO" ? "No se pudo eliminar la condonación." : "No se pudo eliminar el pago."}
        details={[
          {
            label: tipo === "EMPRESA" ? "Empresa" : "Socio",
            value: deleteRow?.denominacion,
          },
          { label: "Período", value: deleteRow?.periodo },
          { label: "Estado", value: deleteRow?.estado || "PAGADO" },
          { label: "Importe", value: money(deleteRow?.monto) },
          ...(Number(deleteRow?.monto_saldo_favor_aplicado || 0) > 0
            ? [{
                label: "Saldo aplicado",
                value: money(deleteRow?.monto_saldo_favor_aplicado),
              }]
            : []),
          { label: "Medio", value: deleteRow?.medio_pago || "—" },
        ]}
      />
    </>
  );
}
