export { default } from "./ModalComprobantePago";
