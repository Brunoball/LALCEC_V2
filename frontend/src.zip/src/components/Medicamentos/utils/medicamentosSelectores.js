/** Opciones VISIBLES por contexto en Banco de Drogas; no altera catálogos compartidos. */
export const PRESENTACIONES_SECTOR = Object.freeze({
  MEDICAMENTOS: ['COMPRIMIDOS', 'INYECTABLES', 'GOTAS', 'CREMAS', 'OTRAS/OS'],
  DOLOR: ['JARABE', 'CONCENTRADO', 'DOBLE CONCENTRADO', 'AMITRIPTILINA'],
});
export const sectorDePresentacion = valor => PRESENTACIONES_SECTOR.DOLOR.includes(valor) ? 'DOLOR' : 'MEDICAMENTOS';
export const soloOrigenesTrello = catalogos => (catalogos || []).filter(o =>
  o.tipo === 'ORIGEN_INGRESO' && Number(o.activo) === 1 && ['DONACION', 'COMPRA'].includes(o.codigo_sistema));
export const SALIDAS_TRELLO = Object.freeze({
  ENTREGA_DONACION: 'ENTREGA SIN CARGO',
  BAJA_DESCARTE: 'DESCARTE POR VENCIMIENTO',
});
export const soloSalidasTrello = (catalogos, entregable) => (catalogos || []).filter(o =>
  o.tipo === 'SALIDA_STOCK' && Number(o.activo) === 1 &&
  Object.prototype.hasOwnProperty.call(SALIDAS_TRELLO, o.codigo_sistema) &&
  (entregable || o.codigo_sistema !== 'ENTREGA_DONACION'));
export const normalizarMedio = nombre => String(nombre || '').trim().toLocaleUpperCase('es-AR');
export const medioEfectivo = medios => (medios || []).find(m => normalizarMedio(m.nombre) === 'EFECTIVO');
