const { test, expect } = require('./fixtures/auth.fixture');
const { companyData, familyData, personData } = require('./fixtures/socios.fixture');
const {
  apiCall,
  apiResult,
  cleanupCategoriesByPrefix,
  cleanupDiscountsByThresholds,
  cleanupFamilyByPrefix,
  cleanupSocioByDocument,
  expectApiError,
} = require('./helpers/api.helper');
const {
  createCompany,
  createFamily,
  createPerson,
} = require('./helpers/entities.helper');
const { todayIso, uniqueSuffix } = require('./helpers/data.helper');

const person = personData();
const company = companyData();
const familyPersonOne = personData();
const familyPersonTwo = personData();
const batchPersonOne = personData();
const batchPersonTwo = personData();
const apiPaginationPersonOne = personData();
const apiPaginationPersonTwo = personData();
const historicalPricePerson = personData();
const yearRangePerson = personData();
const addressPropagationPerson = personData();
const concurrentPaymentPerson = personData();
const family = familyData();
const now = new Date();
const currentYear = now.getFullYear();
const currentMonth = now.getMonth() + 1;
const previousYear = currentYear - 1;
const secondaryMonth = currentMonth === 1 ? 2 : 1;
const historicalMonth = currentMonth === 1 ? 12 : currentMonth - 1;
const historicalYear = currentMonth === 1 ? previousYear : currentYear;

const pad2 = (value) => String(value).padStart(2, '0');

async function createHistoricalCategory(request) {
  const suffix = uniqueSuffix();
  const name = `PW E2E CAT CUOTAS ${suffix}`;
  const oldAmount = '1200.00';
  const currentAmount = '2400.00';
  const firstEffectiveYear = Math.max(2000, historicalYear - 1);
  const firstEffectiveDate = `${firstEffectiveYear}-01-01`;
  const changeDate = `${currentYear}-${pad2(currentMonth)}-01`;

  const created = await apiCall(request, 'categorias_guardar', {
    method: 'POST',
    data: {
      nombre: name,
      descripcion: 'PW E2E HISTORIAL DE MONTOS PARA CUOTAS',
      monto_actual: oldAmount,
      vigente_desde: firstEffectiveDate,
    },
  });

  const updated = await apiCall(request, 'categorias_guardar', {
    method: 'POST',
    data: {
      id_categoria: created.item.id_categoria,
      nombre: name,
      descripcion: 'PW E2E HISTORIAL DE MONTOS PARA CUOTAS',
      monto_actual: currentAmount,
      vigente_desde: changeDate,
    },
  });

  return {
    id_categoria: Number(updated.item.id_categoria),
    name,
    prefix: name,
    oldAmount: Number(oldAmount),
    currentAmount: Number(currentAmount),
    firstEffectiveDate,
    changeDate,
  };
}

function discountAppliesToday(rule, memberCount) {
  const today = todayIso();
  return Boolean(
    rule.activo &&
      String(rule.vigencia_desde || '') <= today &&
      (!rule.vigencia_hasta || String(rule.vigencia_hasta) >= today) &&
      Number(rule.cantidad_integrantes_desde) <= memberCount &&
      (rule.cantidad_integrantes_hasta === null ||
        Number(rule.cantidad_integrantes_hasta) >= memberCount),
  );
}

async function ensureTwoMemberDiscount(request) {
  const listed = await apiCall(request, 'descuentos_familiares_listar', {
    params: { estado: 'todos' },
  });
  const existing = (listed.items || []).find((item) => discountAppliesToday(item, 2));
  if (existing) return existing;

  const response = await apiCall(request, 'descuentos_familiares_guardar', {
    method: 'POST',
    data: {
      cantidad_integrantes_desde: 2,
      cantidad_integrantes_hasta: 2,
      porcentaje_descuento: '12.50',
      vigencia_desde: todayIso(),
      vigencia_hasta: todayIso(),
      descripcion: 'PW E2E DESCUENTO GLOBAL CUOTAS',
    },
  });
  return response.item;
}

async function activeCategoryAndMedium(request) {
  const categories = await apiCall(request, 'categorias_listar', {
    params: { estado: 'activo' },
  });
  const category = (categories.items || []).find(
    (item) => item.activo && Number(item.monto_actual || 0) > 0,
  );
  expect(category).toBeTruthy();

  const catalogs = await apiCall(request, 'cuotas_catalogos');
  const medium = catalogs.catalogos?.medios_pago?.[0];
  expect(medium).toBeTruthy();
  return { category, medium };
}

async function removePayments(request, items = []) {
  for (const item of items) {
    if (!item?.id_pago) continue;
    await apiCall(request, 'cuotas_eliminar_pago', {
      method: 'POST',
      data: { id_pago: item.id_pago },
    });
  }
}


function singlePaymentDialog(page, person) {
  return page.getByRole('dialog', {
    name: new RegExp(person.apellido, 'i'),
  });
}

test.describe('Cuotas de socios y empresas', () => {
  test.afterEach(async ({ request }) => {
    try {
      await cleanupFamilyByPrefix(request, family.prefix);
    } catch (_error) {
      // La familia puede no haberse creado todavía.
    }
    try {
      await cleanupDiscountsByThresholds(request, [2]);
    } catch (_error) {
      // Solo elimina la regla E2E, si llegó a crearse.
    }

    for (const target of [
      { tipo: 'PERSONA', documento: person.dni },
      { tipo: 'EMPRESA', documento: company.cuit },
      { tipo: 'PERSONA', documento: familyPersonOne.dni },
      { tipo: 'PERSONA', documento: familyPersonTwo.dni },
      { tipo: 'PERSONA', documento: batchPersonOne.dni },
      { tipo: 'PERSONA', documento: batchPersonTwo.dni },
      { tipo: 'PERSONA', documento: apiPaginationPersonOne.dni },
      { tipo: 'PERSONA', documento: apiPaginationPersonTwo.dni },
      { tipo: 'PERSONA', documento: historicalPricePerson.dni },
      { tipo: 'PERSONA', documento: yearRangePerson.dni },
      { tipo: 'PERSONA', documento: addressPropagationPerson.dni },
      { tipo: 'PERSONA', documento: concurrentPaymentPerson.dni },
    ]) {
      try {
        await cleanupSocioByDocument(request, target);
      } catch (_error) {
        // La siguiente ejecución vuelve a intentar la limpieza exacta.
      }
    }
  });

  test('muestra las vistas de deudores, pagados y condonados para socios y empresas', async ({ page }) => {
    await page.goto('/cuotas');

    await expect(page.getByRole('heading', { name: 'Cuotas' })).toBeVisible();
    await expect(page.getByRole('tab', { name: 'Socios' })).toBeVisible();
    await expect(page.getByRole('tab', { name: 'Empresas' })).toBeVisible();
    await expect(page.getByRole('tab', { name: 'Deudores' })).toBeVisible();
    await expect(page.getByRole('tab', { name: 'Pagados' })).toBeVisible();
    await expect(page.getByRole('tab', { name: /Condonados/i })).toBeVisible();

    await expect(page.getByRole('table', { name: /Cuotas de socios adeudadas/i })).toBeVisible();
    await page.getByRole('tab', { name: 'Pagados' }).click();
    await expect(page.getByRole('table', { name: /Cuotas de socios pagadas/i })).toBeVisible();
    await page.getByRole('tab', { name: /Condonados/i }).click();
    await expect(page.getByRole('table', { name: /Cuotas de socios condonadas/i })).toBeVisible();
    await page.getByRole('tab', { name: 'Empresas' }).click();
    await expect(page.getByRole('table', { name: /Cuotas de empresas condonadas/i })).toBeVisible();
    await page.getByRole('tab', { name: 'Pagados' }).click();
    await expect(page.getByRole('table', { name: /Cuotas de empresas pagadas/i })).toBeVisible();
    await page.getByRole('tab', { name: 'Deudores' }).click();
    await expect(page.getByRole('table', { name: /Cuotas de empresas adeudadas/i })).toBeVisible();
  });

  test('registra y elimina pagos mensuales para un socio y una empresa', async ({ request }) => {
    await cleanupSocioByDocument(request, { tipo: 'PERSONA', documento: person.dni });
    await cleanupSocioByDocument(request, { tipo: 'EMPRESA', documento: company.cuit });

    const { category, medium } = await activeCategoryAndMedium(request);
    const savedPerson = await createPerson(request, person, {
      id_categoria: category.id_categoria,
      id_medio_pago: medium.id_medio_pago,
    });
    const savedCompany = await createCompany(request, company, {
      id_categoria: category.id_categoria,
      id_medio_pago: medium.id_medio_pago,
    });

    for (const target of [
      { tipo: 'PERSONA', item: savedPerson, name: `${person.apellido}, ${person.nombre}` },
      { tipo: 'EMPRESA', item: savedCompany, name: company.razonSocial },
    ]) {
      const debt = await apiCall(request, 'cuotas_listar', {
        params: {
          tipo: target.tipo,
          estado: 'DEUDORES',
          anio: currentYear,
          mes: currentMonth,
          buscar: target.tipo === 'EMPRESA' ? company.cuit : person.dni,
        },
      });
      expect(debt.items).toHaveLength(1);
      expect(debt.items[0].id_socio).toBe(target.item.id_socio);
      expect(debt.items[0].periodo).toContain(String(currentYear));

      const tokenizedDebt = await apiCall(request, 'cuotas_listar', {
        params: {
          tipo: target.tipo,
          estado: 'DEUDORES',
          anio: currentYear,
          mes: currentMonth,
          buscar: target.tipo === 'EMPRESA'
            ? `${company.suffix.toLowerCase()}, empresa`
            : `${person.nombre.toLowerCase()}, ${person.apellido.toLowerCase()}`,
        },
      });
      expect(tokenizedDebt.items.map((item) => item.id_socio)).toContain(target.item.id_socio);

      const payment = await apiCall(request, 'cuotas_registrar_pago', {
        method: 'POST',
        data: {
          id_socio: target.item.id_socio,
          anio: currentYear,
          mes: currentMonth,
          fecha_pago: todayIso(),
          monto: debt.items[0].monto_sugerido,
          id_medio_pago: medium.id_medio_pago,
        },
      });
      expect(payment.item.id_pago).toBeGreaterThan(0);
      expect(payment.item.denominacion).toContain(target.name.split(',')[0]);
      expect(payment.comprobante.lineas).toHaveLength(1);

      await expectApiError(
        request,
        'cuotas_registrar_pago',
        {
          method: 'POST',
          data: {
            id_socio: target.item.id_socio,
            anio: currentYear,
            mes: currentMonth,
            fecha_pago: todayIso(),
            monto: debt.items[0].monto_sugerido,
            id_medio_pago: medium.id_medio_pago,
          },
        },
        { status: 409, code: 'PAGO_YA_REGISTRADO' },
      );

      const paid = await apiCall(request, 'cuotas_listar', {
        params: {
          tipo: target.tipo,
          estado: 'PAGADOS',
          anio: currentYear,
          mes: currentMonth,
          buscar: target.tipo === 'EMPRESA' ? company.cuit : person.dni,
        },
      });
      expect(paid.items).toHaveLength(1);
      expect(paid.items[0].id_pago).toBe(payment.item.id_pago);
      expect(Number(paid.items[0].monto)).toBeGreaterThan(0);

      await apiCall(request, 'cuotas_eliminar_pago', {
        method: 'POST',
        data: { id_pago: payment.item.id_pago },
      });

      const debtAgain = await apiCall(request, 'cuotas_listar', {
        params: {
          tipo: target.tipo,
          estado: 'DEUDORES',
          anio: currentYear,
          mes: currentMonth,
          buscar: target.tipo === 'EMPRESA' ? company.cuit : person.dni,
        },
      });
      expect(debtAgain.items).toHaveLength(1);
      expect(debtAgain.items[0].id_socio).toBe(target.item.id_socio);
    }
  });



  test('serializa dos cobros concurrentes del mismo período y persiste exactamente uno', async ({ request }) => {
    await cleanupSocioByDocument(request, {
      tipo: 'PERSONA',
      documento: concurrentPaymentPerson.dni,
    });

    const { category, medium } = await activeCategoryAndMedium(request);
    const saved = await createPerson(request, concurrentPaymentPerson, {
      id_categoria: category.id_categoria,
      id_medio_pago: medium.id_medio_pago,
    });

    const context = await apiCall(request, 'cuotas_contexto_pago', {
      params: {
        id_socio: saved.id_socio,
        anio: currentYear,
        mes: currentMonth,
        fecha_pago: todayIso(),
      },
    });
    expect(context.principal.puede_pagar).toBe(true);

    const payload = {
      id_socio: saved.id_socio,
      anio: currentYear,
      mes: currentMonth,
      fecha_pago: todayIso(),
      monto: context.principal.monto_sugerido,
      id_medio_pago: medium.id_medio_pago,
    };

    // Se disparan realmente en paralelo. El lock/UNIQUE del backend debe hacer
    // que una sola transacción gane y que la otra vea PAGO_YA_REGISTRADO.
    const results = await Promise.all([
      apiResult(request, 'cuotas_registrar_pago', { method: 'POST', data: payload }),
      apiResult(request, 'cuotas_registrar_pago', { method: 'POST', data: payload }),
    ]);

    const successes = results.filter((result) => result.ok);
    const conflicts = results.filter(
      (result) =>
        !result.ok &&
        result.status === 409 &&
        result.body?.codigo === 'PAGO_YA_REGISTRADO',
    );
    expect(successes).toHaveLength(1);
    expect(conflicts).toHaveLength(1);

    const paymentId = Number(successes[0].body?.item?.id_pago);
    expect(paymentId).toBeGreaterThan(0);
    expect(successes[0].body?.item?.tipo_pago).toBe('NORMAL');
    expect(successes[0].body?.item?.porcentaje_descuento_familiar).toBeNull();

    const paid = await apiCall(request, 'cuotas_listar', {
      params: {
        tipo: 'PERSONA',
        estado: 'PAGADOS',
        anio: currentYear,
        mes: currentMonth,
        buscar: concurrentPaymentPerson.dni,
      },
    });
    const matching = (paid.items || []).filter(
      (item) =>
        Number(item.id_socio) === Number(saved.id_socio) &&
        Number(item.id_pago) === paymentId,
    );
    expect(matching).toHaveLength(1);

    await apiCall(request, 'cuotas_eliminar_pago', {
      method: 'POST',
      data: { id_pago: paymentId },
    });
  });

  // Expectativas explícitas: no se calcula la dirección con la función del sistema.
  // El helper crea un alternativo por defecto; cada caso lo define expresamente.
  const addressCases = [
    { name: 'persona: alternativo tiene prioridad y no recibe el número principal', tipo: 'PERSONA', street: 'CALLE PRINCIPAL', number: '9876', alternative: 'SEDE DE COBRO 45', expected: 'SEDE DE COBRO 45' },
    { name: 'persona: dirección guardada únicamente en alternativo', tipo: 'PERSONA', street: '', number: '', alternative: 'CABRERA 2800', expected: 'CABRERA 2800' },
    { name: 'persona: alternativo vacío usa calle y número', tipo: 'PERSONA', street: 'CALLE REGRESION DOMICILIO', number: '9876', alternative: '', expected: 'CALLE REGRESION DOMICILIO 9876' },
    { name: 'persona: alternativo con espacios usa calle y número', tipo: 'PERSONA', street: 'CALLE RESPALDO', number: '100', alternative: '   ', expected: 'CALLE RESPALDO 100' },
    { name: 'persona: número ya incluido en la calle no se repite', tipo: 'PERSONA', street: 'CALLE RESPALDO 100', number: '100', alternative: '', expected: 'CALLE RESPALDO 100' },
    { name: 'persona: sin direcciones devuelve vacío', tipo: 'PERSONA', street: '', number: '', alternative: '', expected: '' },
    { name: 'empresa: alternativo incluye la altura y tiene prioridad', tipo: 'EMPRESA', street: 'AVENIDA PRINCIPAL', number: '', alternative: 'AVENIDA PRINCIPAL 704', expected: 'AVENIDA PRINCIPAL 704' },
    { name: 'empresa: sin alternativo usa domicilio principal', tipo: 'EMPRESA', street: 'AVENIDA RESPALDO 456', number: '', alternative: '', expected: 'AVENIDA RESPALDO 456' },
    { name: 'empresa: sin direcciones devuelve vacío', tipo: 'EMPRESA', street: '', number: '', alternative: '', expected: '' },
  ];

  for (const addressCase of addressCases) {
    test(`propaga domicilio hasta catálogos, contextos, pagos y reimpresión — ${addressCase.name}`, async ({ request }) => {
      const { category, medium } = await activeCategoryAndMedium(request);

      const isCompany = addressCase.tipo === 'EMPRESA';
      const fixture = isCompany ? company : addressPropagationPerson;
      const document = isCompany ? fixture.cuit : fixture.dni;
      const saved = await (isCompany ? createCompany : createPerson)(request, fixture, {
        fecha_alta: `${currentYear}-01-01`,
        domicilio: addressCase.street,
        ...(isCompany ? {} : { numero_domicilio: addressCase.number }),
        domicilio_alternativo: addressCase.alternative,
        id_categoria: category.id_categoria,
        id_medio_pago: medium.id_medio_pago,
      });

      const assertAddress = (item, label) => {
        expect(item, `${label}: falta el objeto esperado`).toBeTruthy();
        expect(item.domicilio ?? '', `${label}: dirección de impresión incorrecta`).toBe(addressCase.expected);
        expect(item.numero_domicilio ?? '', `${label}: número principal alterado`).toBe(isCompany ? '' : addressCase.number);
        expect(String(item.domicilio), `${label}: nunca debe degradar a N/A`).not.toMatch(/^N\/?A$/i);
        if (addressCase.expected && addressCase.number) {
          expect(item.domicilio, `${label}: no agregar el número principal al alternativo ni duplicarlo`)
            .not.toBe(`${addressCase.expected} ${addressCase.number}`);
        }
      };

      const debt = await apiCall(request, 'cuotas_listar', {
        params: {
          tipo: addressCase.tipo,
          estado: 'DEUDORES',
          anio: currentYear,
          mes: currentMonth,
          buscar: document,
        },
      });
      expect(debt.items).toHaveLength(1);
      assertAddress(debt.items[0], 'cuotas_listar DEUDORES');

      const catalogs = await apiCall(request, 'cuotas_catalogos', {
        params: { anio: currentYear, mes: currentMonth },
      });
      const catalogPartner = (catalogs.catalogos?.[isCompany ? 'empresas' : 'socios'] || [])
        .find((item) => Number(item.id_socio) === Number(saved.id_socio));
      expect(catalogPartner, 'cuotas_catalogos: el socio creado debe estar en el catálogo').toBeTruthy();
      assertAddress(catalogPartner, 'cuotas_catalogos');

      const context = await apiCall(request, 'cuotas_contexto_pago', {
        params: {
          id_socio: saved.id_socio,
          anio: currentYear,
          mes: currentMonth,
          fecha_pago: todayIso(),
        },
      });
      assertAddress(context.principal, 'cuotas_contexto_pago.principal');

      const contexts = await apiCall(request, 'cuotas_contextos_pago', {
        params: {
          id_socio: saved.id_socio,
          anio: currentYear,
          fecha_pago: todayIso(),
        },
      });
      const annualCurrent = contexts.periodos?.[String(currentMonth)];
      expect(annualCurrent, 'cuotas_contextos_pago: falta el período actual').toBeTruthy();
      assertAddress(annualCurrent.principal, 'cuotas_contextos_pago.periodos[mes].principal');

      const payment = await apiCall(request, 'cuotas_registrar_pago', {
        method: 'POST',
        data: {
          id_socio: saved.id_socio,
          anio: currentYear,
          mes: currentMonth,
          fecha_pago: todayIso(),
          monto: context.principal.monto_sugerido,
          id_medio_pago: medium.id_medio_pago,
        },
      });

      assertAddress(payment.item, 'cuotas_registrar_pago.item');
      expect(payment.comprobante.domicilio ?? '').toBe(addressCase.expected);
      expect(payment.comprobante.lineas).toHaveLength(1);
      assertAddress(payment.comprobante.lineas[0], 'cuotas_registrar_pago.comprobante.lineas[0]');

      const paid = await apiCall(request, 'cuotas_listar', {
        params: {
          tipo: addressCase.tipo,
          estado: 'PAGADOS',
          anio: currentYear,
          mes: currentMonth,
          buscar: document,
        },
      });
      expect(paid.items).toHaveLength(1);
      assertAddress(paid.items[0], 'cuotas_listar PAGADOS / reimpresión');

      await removePayments(request, payment.items || [payment.item]);
    });
  }

  test('mantiene operativos los alias históricos de registrar cobro y anular', async ({ request }) => {
    await cleanupSocioByDocument(request, { tipo: 'PERSONA', documento: person.dni });
    const { category, medium } = await activeCategoryAndMedium(request);
    const savedPerson = await createPerson(request, person, {
      id_categoria: category.id_categoria,
      id_medio_pago: medium.id_medio_pago,
    });

    const debt = await apiCall(request, 'cuotas_listar', {
      params: {
        tipo: 'PERSONA',
        estado: 'DEUDORES',
        anio: currentYear,
        mes: currentMonth,
        buscar: person.dni,
      },
    });
    expect(debt.items).toHaveLength(1);

    const paid = await apiCall(request, 'cuotas_registrar_cobro', {
      method: 'POST',
      data: {
        id_socio: savedPerson.id_socio,
        anio: currentYear,
        mes: currentMonth,
        fecha_pago: todayIso(),
        monto: debt.items[0].monto_sugerido,
        id_medio_pago: medium.id_medio_pago,
      },
    });
    expect(paid.item.id_pago).toBeGreaterThan(0);

    const removed = await apiCall(request, 'cuotas_anular', {
      method: 'POST',
      data: { id_pago: paid.item.id_pago },
    });
    expect(removed.item.id_pago).toBe(paid.item.id_pago);
  });

  test('detecta el grupo familiar, calcula el descuento y registra todas sus cuotas pendientes', async ({ request }) => {
    const { category, medium } = await activeCategoryAndMedium(request);
    const discount = await ensureTwoMemberDiscount(request);
    const first = await createPerson(request, familyPersonOne, {
      domicilio: 'CALLE FAMILIA UNO',
      numero_domicilio: '101',
      domicilio_alternativo: 'COBRO FAMILIA UNO 801',
      id_categoria: category.id_categoria,
      id_medio_pago: medium.id_medio_pago,
    });
    const second = await createPerson(request, familyPersonTwo, {
      domicilio: 'CALLE FAMILIA DOS',
      numero_domicilio: '202',
      domicilio_alternativo: '',
      id_categoria: category.id_categoria,
      id_medio_pago: medium.id_medio_pago,
    });
    await createFamily(request, family, [first, second]);

    const context = await apiCall(request, 'cuotas_contexto_pago', {
      params: {
        id_socio: first.id_socio,
        anio: currentYear,
        mes: currentMonth,
        fecha_pago: todayIso(),
      },
    });
    expect(context.familia.nombre).toContain(family.nombre);
    expect(context.familia.integrantes).toHaveLength(2);
    expect(context.familia.cantidad_pendientes).toBe(2);
    expect(Number(context.familia.porcentaje_descuento)).toBe(
      Number(discount.porcentaje_descuento),
    );
    expect(Number(context.principal.monto_sugerido)).toBeLessThanOrEqual(
      Number(context.principal.monto_base),
    );
    const familyAddresses = new Map(
      context.familia.integrantes.map((member) => [Number(member.id_socio), member.domicilio]),
    );
    expect(familyAddresses.get(Number(first.id_socio))).toBe('COBRO FAMILIA UNO 801');
    expect(familyAddresses.get(Number(second.id_socio))).toBe('CALLE FAMILIA DOS 202');

    const response = await apiCall(request, 'cuotas_registrar_pago', {
      method: 'POST',
      data: {
        id_socio: first.id_socio,
        anio: currentYear,
        mes: currentMonth,
        fecha_pago: todayIso(),
        id_medio_pago: medium.id_medio_pago,
        aplicar_familia: true,
      },
    });
    expect(response.aplico_familia).toBe(true);
    expect(response.items).toHaveLength(2);
    for (const item of response.items) {
      expect(item.tipo_pago).toBe('DESCUENTO_FAMILIAR');
      expect(Number(item.porcentaje_descuento_familiar)).toBeCloseTo(
        Number(discount.porcentaje_descuento),
        2,
      );
    }
    expect(response.comprobante.lineas).toHaveLength(2);
    expect(response.comprobante.modalidad_label).toMatch(/grupo familiar/i);
    expect(Number(response.comprobante.monto)).toBeGreaterThan(0);
    expect(response.comprobante.lineas.map((line) => line.id_socio).sort()).toEqual(
      [first.id_socio, second.id_socio].sort(),
    );
    const receiptAddresses = new Map(
      response.comprobante.lineas.map((line) => [Number(line.id_socio), line.domicilio]),
    );
    expect(receiptAddresses.get(Number(first.id_socio))).toBe('COBRO FAMILIA UNO 801');
    expect(receiptAddresses.get(Number(second.id_socio))).toBe('CALLE FAMILIA DOS 202');

    const accounting = await apiCall(request, 'contable_ingresos_socios', {
      params: {
        anio: currentYear,
        mes: currentMonth,
        buscar: familyPersonOne.dni,
      },
    });
    const accountingItem = (accounting.items || []).find(
      (item) => Number(item.id_socio) === Number(first.id_socio),
    );
    expect(accountingItem).toBeTruthy();
    expect(accountingItem.tipo_pago).toBe('DESCUENTO_FAMILIAR');
    expect(Number(accountingItem.porcentaje_descuento_familiar)).toBeCloseTo(
      Number(discount.porcentaje_descuento),
      2,
    );

    await removePayments(request, response.items);
  });


  test('monto personalizado familiar se aplica a cada integrante y queda trazado como personalizado', async ({ request }) => {
    const { category, medium } = await activeCategoryAndMedium(request);
    await ensureTwoMemberDiscount(request);
    const first = await createPerson(request, familyPersonOne, {
      id_categoria: category.id_categoria,
      id_medio_pago: medium.id_medio_pago,
    });
    const second = await createPerson(request, familyPersonTwo, {
      id_categoria: category.id_categoria,
      id_medio_pago: medium.id_medio_pago,
    });
    await createFamily(request, family, [first, second]);

    const customAmount = 777.77;
    const response = await apiCall(request, 'cuotas_registrar_pago', {
      method: 'POST',
      data: {
        id_socio: first.id_socio,
        anio: currentYear,
        mes: currentMonth,
        fecha_pago: todayIso(),
        id_medio_pago: medium.id_medio_pago,
        aplicar_familia: true,
        montos_personalizados: {
          [currentMonth]: customAmount,
        },
      },
    });

    expect(response.aplico_familia).toBe(true);
    expect(response.items).toHaveLength(2);
    expect(Number(response.comprobante.monto)).toBeCloseTo(customAmount * 2, 2);
    for (const item of response.items) {
      expect(Number(item.monto)).toBeCloseTo(customAmount, 2);
      expect(item.tipo_pago).toBe('MONTO_PERSONALIZADO');
      expect(item.porcentaje_descuento_familiar).toBeNull();
    }
    for (const line of response.comprobante.lineas) {
      expect(Number(line.monto)).toBeCloseTo(customAmount, 2);
      expect(line.tipo_pago).toBe('MONTO_PERSONALIZADO');
      expect(line.porcentaje_descuento_familiar).toBeNull();
    }

    const accounting = await apiCall(request, 'contable_ingresos_socios', {
      params: {
        anio: currentYear,
        mes: currentMonth,
        buscar: familyPersonOne.dni,
      },
    });
    const accountingItem = (accounting.items || []).find(
      (item) => Number(item.id_socio) === Number(first.id_socio),
    );
    expect(accountingItem).toBeTruthy();
    expect(accountingItem.tipo_pago).toBe('MONTO_PERSONALIZADO');
    expect(accountingItem.porcentaje_descuento_familiar).toBeNull();

    // El contexto individual de una cuota ya pagada también debe conservar la
    // trazabilidad. Cubre el SELECT específico de cuotas_contexto_pago.
    const paidContext = await apiCall(request, 'cuotas_contexto_pago', {
      params: {
        id_socio: first.id_socio,
        anio: currentYear,
        mes: currentMonth,
        fecha_pago: todayIso(),
      },
    });
    expect(paidContext.principal.pagado).toBe(true);
    expect(paidContext.principal.tipo_pago).toBe('MONTO_PERSONALIZADO');
    expect(paidContext.principal.porcentaje_descuento_familiar).toBeNull();

    await removePayments(request, response.items);
  });

  test('al desactivar el pago familiar registra solamente la cuota del socio abierto', async ({ request }) => {
    const { category, medium } = await activeCategoryAndMedium(request);
    await ensureTwoMemberDiscount(request);
    const first = await createPerson(request, familyPersonOne, {
      id_categoria: category.id_categoria,
      id_medio_pago: medium.id_medio_pago,
    });
    const second = await createPerson(request, familyPersonTwo, {
      id_categoria: category.id_categoria,
      id_medio_pago: medium.id_medio_pago,
    });
    await createFamily(request, family, [first, second]);

    const context = await apiCall(request, 'cuotas_contexto_pago', {
      params: {
        id_socio: first.id_socio,
        anio: currentYear,
        mes: currentMonth,
        fecha_pago: todayIso(),
      },
    });

    const response = await apiCall(request, 'cuotas_registrar_pago', {
      method: 'POST',
      data: {
        id_socio: first.id_socio,
        anio: currentYear,
        mes: currentMonth,
        fecha_pago: todayIso(),
        monto: context.principal.monto_sugerido,
        id_medio_pago: medium.id_medio_pago,
        aplicar_familia: false,
      },
    });

    expect(response.aplico_familia).toBe(false);
    expect(response.items).toHaveLength(1);
    expect(response.items[0].id_socio).toBe(first.id_socio);

    const secondDebt = await apiCall(request, 'cuotas_listar', {
      params: {
        tipo: 'PERSONA',
        estado: 'DEUDORES',
        anio: currentYear,
        mes: currentMonth,
        buscar: familyPersonTwo.dni,
      },
    });
    expect(secondDebt.items).toHaveLength(1);
    expect(secondDebt.items[0].id_socio).toBe(second.id_socio);

    await removePayments(request, response.items);
  });

  test('registra varios socios seleccionados en una sola operación y genera un comprobante agrupado', async ({ request }) => {
    const { category, medium } = await activeCategoryAndMedium(request);
    const first = await createPerson(request, batchPersonOne, {
      domicilio: 'CALLE LOTE UNO',
      numero_domicilio: '301',
      domicilio_alternativo: 'COBRO LOTE UNO 901',
      id_categoria: category.id_categoria,
      id_medio_pago: medium.id_medio_pago,
    });
    const second = await createPerson(request, batchPersonTwo, {
      domicilio: '',
      numero_domicilio: '',
      domicilio_alternativo: '',
      id_categoria: category.id_categoria,
      id_medio_pago: medium.id_medio_pago,
    });

    const debts = [];
    for (const target of [batchPersonOne, batchPersonTwo]) {
      const response = await apiCall(request, 'cuotas_listar', {
        params: {
          tipo: 'PERSONA',
          estado: 'DEUDORES',
          anio: currentYear,
          mes: currentMonth,
          buscar: target.dni,
        },
      });
      expect(response.items).toHaveLength(1);
      debts.push(response.items[0]);
    }

    const response = await apiCall(request, 'cuotas_registrar_pagos', {
      method: 'POST',
      data: {
        fecha_pago: todayIso(),
        id_medio_pago: medium.id_medio_pago,
        pagos: debts.map((debt) => ({
          id_socio: debt.id_socio,
          anio: debt.anio,
          mes: debt.mes,
          monto: debt.monto_sugerido,
        })),
      },
    });
    expect(response.items).toHaveLength(2);
    expect(response.comprobante.lineas).toHaveLength(2);
    expect(response.comprobante.modalidad_label).toMatch(/múltiple/i);
    expect(response.comprobante.codigo_operacion).toMatch(/^CUO-/);
    expect(response.items.map((item) => item.id_socio).sort()).toEqual(
      [first.id_socio, second.id_socio].sort(),
    );
    const batchReceiptAddresses = new Map(
      response.comprobante.lineas.map((line) => [Number(line.id_socio), line.domicilio]),
    );
    expect(batchReceiptAddresses.get(Number(first.id_socio))).toBe('COBRO LOTE UNO 901');
    expect(batchReceiptAddresses.get(Number(second.id_socio)) ?? '').toBe('');

    await removePayments(request, response.items);
  });

  test('permite seleccionar cuotas en búsquedas sucesivas y muestra el modal de pago múltiple', async ({ page, request }) => {
    const { category, medium } = await activeCategoryAndMedium(request);
    await createPerson(request, batchPersonOne, {
      id_categoria: category.id_categoria,
      id_medio_pago: medium.id_medio_pago,
    });
    await createPerson(request, batchPersonTwo, {
      id_categoria: category.id_categoria,
      id_medio_pago: medium.id_medio_pago,
    });

    await page.goto('/cuotas');
    await page.getByRole('button', { name: 'Selección múltiple' }).click();
    const search = page.getByRole('textbox', { name: 'Búsqueda', exact: true });

    await search.fill(batchPersonOne.dni);
    await page
      .getByRole('checkbox', { name: new RegExp(batchPersonOne.apellido, 'i') })
      .check();
    await expect(page.getByText(/1 cuota seleccionada/i)).toBeVisible();

    await search.fill(batchPersonTwo.dni);
    await page
      .getByRole('checkbox', { name: new RegExp(batchPersonTwo.apellido, 'i') })
      .check();
    await expect(page.getByText(/2 cuotas seleccionadas/i)).toBeVisible();

    const continueButton = page.getByRole('button', { name: 'Continuar (2)', exact: true });
    await expect(continueButton).toBeVisible();
    await expect(continueButton).toBeEnabled();
    await continueButton.click();
    const dialog = page.getByRole('dialog', { name: 'Registrar pagos seleccionados' });
    await expect(dialog).toBeVisible();
    await expect(dialog).toContainText(batchPersonOne.apellido);
    await expect(dialog).toContainText(batchPersonTwo.apellido);
    await expect(dialog.getByRole('button', { name: 'Registrar 2 pagos' })).toBeVisible();
    await dialog.getByRole('button', { name: 'Cancelar' }).click();
  });

  test('muestra el grupo familiar por defecto y abre el comprobante después de pagar', async ({ page, request }) => {
    const { category, medium } = await activeCategoryAndMedium(request);
    await ensureTwoMemberDiscount(request);
    const first = await createPerson(request, familyPersonOne, {
      id_categoria: category.id_categoria,
      id_medio_pago: medium.id_medio_pago,
    });
    const second = await createPerson(request, familyPersonTwo, {
      id_categoria: category.id_categoria,
      id_medio_pago: medium.id_medio_pago,
    });
    await createFamily(request, family, [first, second]);

    await page.goto('/cuotas');
    await page.getByRole('textbox', { name: 'Búsqueda', exact: true }).fill(familyPersonOne.dni);
    const debtRow = page
      .getByRole('table', { name: /Cuotas de socios adeudadas/i })
      .getByRole('row')
      .filter({ hasText: familyPersonOne.dni });
    await expect(debtRow).toBeVisible();
    await debtRow.getByRole('button', { name: 'Registrar pago' }).click();

    const paymentDialog = singlePaymentDialog(page, familyPersonOne);
    await expect(paymentDialog).toBeVisible();
    const familyTab = paymentDialog.getByRole('tab', { name: /Familia/ });
    await familyTab.click();
    await expect(familyTab).toHaveAttribute('aria-selected', 'true');
    const familyCheck = paymentDialog.getByRole('checkbox', {
      name: 'Aplicar pago a todo el grupo familiar',
    });
    await expect(familyCheck).toBeChecked();
    await paymentDialog.getByRole('button', { name: 'Ver integrantes' }).click();
    await expect(paymentDialog).toContainText(familyPersonTwo.apellido);
    const monthsTab = paymentDialog.getByRole('tab', { name: /Meses a pagar/ });
    await monthsTab.click();
    await expect(monthsTab).toHaveAttribute('aria-selected', 'true');
    await paymentDialog
      .getByLabel('Medio de pago *')
      .selectOption(String(medium.id_medio_pago));
    await paymentDialog.getByRole('button', { name: /Registrar pago familiar \(2 cuotas\)/ }).click();

    const receiptDialog = page.getByRole('dialog', { name: /Registro de 2 pagos/i });
    await expect(receiptDialog).toContainText(/2 pagos realizados con éxito/i);
    await expect(receiptDialog.getByRole('region', { name: 'Información del comprobante' })).toBeVisible();
    await expect(receiptDialog.getByRole('button', { name: 'Comprobantes', exact: true })).toBeVisible();
    await expect(receiptDialog.getByRole('button', { name: 'PDF', exact: true })).toBeVisible();
    await receiptDialog.getByText('Cerrar', { exact: true }).click();

    const paid = await apiCall(request, 'cuotas_listar', {
      params: {
        tipo: 'PERSONA',
        estado: 'PAGADOS',
        anio: currentYear,
        mes: currentMonth,
        buscar: familyPersonOne.dni,
      },
    });
    const paidSecond = await apiCall(request, 'cuotas_listar', {
      params: {
        tipo: 'PERSONA',
        estado: 'PAGADOS',
        anio: currentYear,
        mes: currentMonth,
        buscar: familyPersonTwo.dni,
      },
    });
    await removePayments(request, [...paid.items, ...paidSecond.items]);
  });

  test('expone los 12 contextos de pago y conserva montos históricos por vigencia real', async ({ request }) => {
    const historicalCategory = await createHistoricalCategory(request);
    let savedPerson = null;

    try {
      const { medium } = await activeCategoryAndMedium(request);
      savedPerson = await createPerson(request, historicalPricePerson, {
        fecha_alta: `${Math.max(2000, historicalYear - 1)}-01-01`,
        id_categoria: historicalCategory.id_categoria,
        id_medio_pago: medium.id_medio_pago,
      });

      const historicalAnnual = await apiCall(request, 'cuotas_contextos_pago', {
        params: {
          id_socio: savedPerson.id_socio,
          anio: historicalYear,
          fecha_pago: todayIso(),
        },
      });
      expect(Object.keys(historicalAnnual.periodos || {})).toHaveLength(12);

      const currentAnnual = historicalYear === currentYear
        ? historicalAnnual
        : await apiCall(request, 'cuotas_contextos_pago', {
            params: {
              id_socio: savedPerson.id_socio,
              anio: currentYear,
              fecha_pago: todayIso(),
            },
          });
      expect(Object.keys(currentAnnual.periodos || {})).toHaveLength(12);

      const historicalPrincipal = historicalAnnual.periodos[String(historicalMonth)]?.principal;
      const currentPrincipal = currentAnnual.periodos[String(currentMonth)]?.principal;
      expect(historicalPrincipal).toBeTruthy();
      expect(currentPrincipal).toBeTruthy();
      expect(Number(historicalPrincipal.monto_base)).toBeCloseTo(historicalCategory.oldAmount, 2);
      expect(Number(currentPrincipal.monto_base)).toBeCloseTo(historicalCategory.currentAmount, 2);

      const historicalOptions = (historicalPrincipal.opciones_monto || []).map((item) =>
        Number(item.monto_base),
      );
      expect(historicalOptions).toEqual(
        expect.arrayContaining([historicalCategory.oldAmount, historicalCategory.currentAmount]),
      );

      const singleContext = await apiCall(request, 'cuotas_contexto_pago', {
        params: {
          id_socio: savedPerson.id_socio,
          anio: currentYear,
          mes: currentMonth,
          fecha_pago: todayIso(),
        },
      });
      expect(Number(singleContext.principal.monto_base)).toBeCloseTo(
        Number(currentPrincipal.monto_base),
        2,
      );
    } finally {
      if (savedPerson) {
        await cleanupSocioByDocument(request, {
          tipo: 'PERSONA',
          documento: historicalPricePerson.dni,
        }).catch(() => undefined);
      }
      await cleanupCategoriesByPrefix(request, historicalCategory.prefix);
    }
  });

  test('permite pagar varios meses a toda la familia y omite solamente los cruces ya pagados', async ({ request }) => {
    const { category, medium } = await activeCategoryAndMedium(request);
    await ensureTwoMemberDiscount(request);
    const first = await createPerson(request, familyPersonOne, {
      fecha_alta: `${currentYear}-01-01`,
      id_categoria: category.id_categoria,
      id_medio_pago: medium.id_medio_pago,
    });
    const second = await createPerson(request, familyPersonTwo, {
      fecha_alta: `${currentYear}-01-01`,
      id_categoria: category.id_categoria,
      id_medio_pago: medium.id_medio_pago,
    });
    await createFamily(request, family, [first, second]);

    const secondCurrentContext = await apiCall(request, 'cuotas_contexto_pago', {
      params: {
        id_socio: second.id_socio,
        anio: currentYear,
        mes: currentMonth,
        fecha_pago: todayIso(),
      },
    });
    const prepayment = await apiCall(request, 'cuotas_registrar_pago', {
      method: 'POST',
      data: {
        id_socio: second.id_socio,
        anio: currentYear,
        mes: currentMonth,
        fecha_pago: todayIso(),
        monto: secondCurrentContext.principal.monto_sugerido,
        id_medio_pago: medium.id_medio_pago,
        aplicar_familia: false,
      },
    });

    const response = await apiCall(request, 'cuotas_registrar_pagos', {
      method: 'POST',
      data: {
        id_socio: first.id_socio,
        anio: currentYear,
        meses: [currentMonth, secondaryMonth],
        fecha_pago: todayIso(),
        id_medio_pago: medium.id_medio_pago,
        aplicar_familia: true,
      },
    });

    expect(response.aplico_familia).toBe(true);
    expect(response.items).toHaveLength(3);
    expect(response.comprobante.lineas).toHaveLength(3);
    expect(response.comprobante.modalidad_label).toMatch(/grupo familiar/i);
    expect(
      response.items.some(
        (item) =>
          Number(item.id_socio) === Number(second.id_socio) &&
          Number(item.mes) === Number(currentMonth),
      ),
    ).toBe(false);
    expect(
      response.items.filter((item) => Number(item.mes) === Number(secondaryMonth)),
    ).toHaveLength(2);

    await removePayments(request, response.items);
    await removePayments(request, [prepayment.item]);
  });

  test('muestra años desde el alta más antigua y agrega un año futuro sólo cuando existe un pago', async ({ request }) => {
    const { category, medium } = await activeCategoryAndMedium(request);
    const saved = await createPerson(request, yearRangePerson, {
      fecha_alta: `${previousYear}-01-01`,
      id_categoria: category.id_categoria,
      id_medio_pago: medium.id_medio_pago,
    });
    let futurePayment = null;

    try {
      const before = await apiCall(request, 'cuotas_catalogos');
      const beforeYears = (before.catalogos?.anios || []).map(Number);
      expect(beforeYears).toEqual(expect.arrayContaining([previousYear, currentYear]));

      const testFutureYear = Array.from(
        { length: Math.max(0, 2100 - currentYear) },
        (_, index) => currentYear + index + 1,
      ).find((year) => !beforeYears.includes(year));
      expect(testFutureYear, 'Se necesita al menos un año futuro sin pagos para validar su aparición').toBeTruthy();
      expect(beforeYears).not.toContain(testFutureYear);

      const futureContext = await apiCall(request, 'cuotas_contexto_pago', {
        params: {
          id_socio: saved.id_socio,
          anio: testFutureYear,
          mes: 1,
          fecha_pago: todayIso(),
        },
      });
      futurePayment = await apiCall(request, 'cuotas_registrar_pago', {
        method: 'POST',
        data: {
          id_socio: saved.id_socio,
          anio: testFutureYear,
          mes: 1,
          fecha_pago: todayIso(),
          monto: futureContext.principal.monto_sugerido,
          id_medio_pago: medium.id_medio_pago,
          aplicar_familia: false,
        },
      });

      const after = await apiCall(request, 'cuotas_catalogos');
      expect((after.catalogos?.anios || []).map(Number)).toContain(testFutureYear);

      await apiCall(request, 'cuotas_eliminar_pago', {
        method: 'POST',
        data: { id_pago: futurePayment.item.id_pago },
      });
      futurePayment = null;

      const afterDelete = await apiCall(request, 'cuotas_catalogos');
      expect((afterDelete.catalogos?.anios || []).map(Number)).not.toContain(testFutureYear);
    } finally {
      if (futurePayment?.item?.id_pago) {
        await apiCall(request, 'cuotas_eliminar_pago', {
          method: 'POST',
          data: { id_pago: futurePayment.item.id_pago },
        }).catch(() => undefined);
      }
    }
  });

  test('pagina la API, permite omitir catálogos y filtra deudores y pagados por medio de pago', async ({ request }) => {
    const { category, medium } = await activeCategoryAndMedium(request);
    const sharedSearch = `PW PAGINACION CUOTAS ${uniqueSuffix()}`;
    const first = await createPerson(request, apiPaginationPersonOne, {
      apellido: sharedSearch,
      id_categoria: category.id_categoria,
      id_medio_pago: medium.id_medio_pago,
    });
    const second = await createPerson(request, apiPaginationPersonTwo, {
      apellido: sharedSearch,
      id_categoria: category.id_categoria,
      id_medio_pago: medium.id_medio_pago,
    });

    const baseParams = {
      tipo: 'PERSONA',
      estado: 'DEUDORES',
      anio: currentYear,
      mes: currentMonth,
      buscar: sharedSearch,
      por_pagina: 1,
      incluir_catalogos: 0,
    };
    const firstPage = await apiCall(request, 'cuotas_listar', {
      params: { ...baseParams, pagina: 1 },
    });
    expect(firstPage.items).toHaveLength(1);
    expect(firstPage).not.toHaveProperty('catalogos');
    expect(firstPage.paginacion).toMatchObject({
      pagina: 1,
      por_pagina: 1,
      total: 2,
      total_paginas: 2,
      desde: 1,
      hasta: 1,
      tiene_anterior: false,
      tiene_siguiente: true,
    });

    const secondPage = await apiCall(request, 'cuotas_listar', {
      params: { ...baseParams, pagina: 2 },
    });
    expect(secondPage.items).toHaveLength(1);
    expect(secondPage.paginacion).toMatchObject({
      pagina: 2,
      desde: 2,
      hasta: 2,
      tiene_anterior: true,
      tiene_siguiente: false,
    });
    expect([firstPage.items[0].id_socio, secondPage.items[0].id_socio].sort()).toEqual(
      [first.id_socio, second.id_socio].sort(),
    );

    const clampedPage = await apiCall(request, 'cuotas_listar', {
      params: { ...baseParams, pagina: 999 },
    });
    expect(clampedPage.paginacion.pagina).toBe(2);
    expect(clampedPage.items[0].id_socio).toBe(secondPage.items[0].id_socio);

    const withCatalogs = await apiCall(request, 'cuotas_listar', {
      params: { ...baseParams, pagina: 1, incluir_catalogos: 1 },
    });
    expect(withCatalogs.catalogos?.medios_pago).toEqual(expect.any(Array));

    const preferredMediumDebts = await apiCall(request, 'cuotas_listar', {
      params: {
        ...baseParams,
        por_pagina: 100,
        id_medio_pago: medium.id_medio_pago,
      },
    });
    expect(preferredMediumDebts.paginacion.total).toBe(2);
    const otherMediumDebts = await apiCall(request, 'cuotas_listar', {
      params: {
        ...baseParams,
        por_pagina: 100,
        id_medio_pago: 2147483647,
      },
    });
    expect(otherMediumDebts.items).toEqual([]);
    expect(otherMediumDebts.paginacion.total).toBe(0);

    const payment = await apiCall(request, 'cuotas_registrar_pago', {
      method: 'POST',
      data: {
        id_socio: first.id_socio,
        anio: currentYear,
        mes: currentMonth,
        fecha_pago: todayIso(),
        monto: firstPage.items.find((item) => item.id_socio === first.id_socio)?.monto_sugerido ||
          secondPage.items.find((item) => item.id_socio === first.id_socio)?.monto_sugerido,
        id_medio_pago: medium.id_medio_pago,
        aplicar_familia: false,
      },
    });

    const paidByMedium = await apiCall(request, 'cuotas_listar', {
      params: {
        ...baseParams,
        estado: 'PAGADOS',
        por_pagina: 100,
        id_medio_pago: medium.id_medio_pago,
      },
    });
    expect(paidByMedium.items.map((item) => item.id_pago)).toContain(payment.item.id_pago);
    const paidByOtherMedium = await apiCall(request, 'cuotas_listar', {
      params: {
        ...baseParams,
        estado: 'PAGADOS',
        por_pagina: 100,
        id_medio_pago: 2147483647,
      },
    });
    expect(paidByOtherMedium.paginacion.total).toBe(0);

    await removePayments(request, payment.items);
  });

  test('valida filtros y datos obligatorios del pago', async ({ request }) => {
    await expectApiError(
      request,
      'cuotas_listar',
      { params: { tipo: 'OTRO' } },
      { status: 422, code: 'FILTRO_INVALIDO' },
    );
    await expectApiError(
      request,
      'cuotas_listar',
      { params: { estado: 'ARCHIVADOS' } },
      { status: 422, code: 'FILTRO_INVALIDO' },
    );
    await expectApiError(
      request,
      'cuotas_contextos_pago',
      { params: { id_socio: 2147483647, anio: 'NO_VALIDO' } },
      { status: 422, code: 'VALIDATION_ERROR' },
    );
    await expectApiError(
      request,
      'cuotas_registrar_pago',
      { method: 'POST', data: {} },
      { status: 422, code: 'VALIDATION_ERROR' },
    );
    // Primero verificamos específicamente el contrato de medio inexistente.
    await expectApiError(
      request,
      'cuotas_registrar_pagos',
      {
        method: 'POST',
        data: {
          fecha_pago: todayIso(),
          id_medio_pago: 2147483647,
          pagos: [],
        },
      },
      { status: 422, code: 'MEDIO_PAGO_INVALIDO' },
    );

    // Para alcanzar la validación de "pagos obligatorios" usamos un medio creado
    // por el propio E2E. Así la prueba no depende ni referencia catálogos reales.
    const validationMediumName = `PW E2E MEDIO VALIDACION ${uniqueSuffix()}`;
    let validationMedium = null;
    try {
      const createdMedium = await apiCall(request, 'configuracion_lista_guardar', {
        method: 'POST',
        data: { lista: 'medios_pago', nombre: validationMediumName },
      });
      validationMedium = createdMedium.item;

      await expectApiError(
        request,
        'cuotas_registrar_pagos',
        {
          method: 'POST',
          data: {
            fecha_pago: todayIso(),
            id_medio_pago: validationMedium.id_medio_pago,
            pagos: [],
          },
        },
        { status: 422, code: 'VALIDATION_ERROR' },
      );
    } finally {
      if (validationMedium?.id_medio_pago) {
        await apiCall(request, 'configuracion_lista_eliminar_definitivo', {
          method: 'POST',
          data: { lista: 'medios_pago', id: validationMedium.id_medio_pago },
        }).catch(() => false);
      }
    }

    await expectApiError(
      request,
      'cuotas_eliminar_pago',
      { method: 'POST', data: { id_pago: 2147483647 } },
      { status: 404, code: 'PAGO_NO_ENCONTRADO' },
    );
  });

  test('rechaza cuotas sin categoría, anteriores al alta y pertenecientes a socios inactivos', async ({ request }) => {
    const edgePerson = personData();
    const { category, medium } = await activeCategoryAndMedium(request);
    let saved = null;

    const paymentPayload = () => ({
      id_socio: saved.id_socio,
      anio: currentYear,
      mes: currentMonth,
      fecha_pago: todayIso(),
      monto: '100.00',
      id_medio_pago: medium.id_medio_pago,
      aplicar_familia: false,
    });
    const updatePerson = (overrides = {}) =>
      apiCall(request, 'socios_guardar', {
        method: 'POST',
        data: {
          id_socio: saved.id_socio,
          tipo_socio: 'PERSONA',
          apellido: edgePerson.apellido,
          nombre: edgePerson.nombre,
          dni: edgePerson.dni,
          fecha_alta: '2000-01-01',
          domicilio: 'CALLE PLAYWRIGHT',
          numero_domicilio: '123',
          localidad: 'SAN FRANCISCO',
          telefono: edgePerson.telefono,
          email: edgePerson.email,
          id_categoria: category.id_categoria,
          id_medio_pago: medium.id_medio_pago,
          enviar_recordatorio: false,
          observaciones: 'PW E2E BORDES DE CUOTAS',
          ...overrides,
        },
      });

    try {
      saved = await createPerson(request, edgePerson, {
        id_categoria: null,
        id_medio_pago: medium.id_medio_pago,
      });
      await expectApiError(
        request,
        'cuotas_registrar_pago',
        { method: 'POST', data: paymentPayload() },
        { status: 409, code: 'CATEGORIA_REQUERIDA' },
      );

      await updatePerson({ fecha_alta: `${currentYear + 1}-01-01` });
      await expectApiError(
        request,
        'cuotas_registrar_pago',
        { method: 'POST', data: paymentPayload() },
        { status: 409, code: 'PERIODO_ANTERIOR_AL_ALTA' },
      );

      await updatePerson();
      await apiCall(request, 'socios_eliminar', {
        method: 'POST',
        data: {
          id: saved.id_socio,
          fecha_baja: todayIso(),
          motivo_baja: 'PW E2E SOCIO INACTIVO PARA VALIDAR CUOTAS',
        },
      });
      await expectApiError(
        request,
        'cuotas_registrar_pago',
        { method: 'POST', data: paymentPayload() },
        { status: 409, code: 'SOCIO_INACTIVO' },
      );
    } finally {
      await cleanupSocioByDocument(request, {
        tipo: 'PERSONA',
        documento: edgePerson.dni,
      }).catch(() => false);
    }
  });
});
