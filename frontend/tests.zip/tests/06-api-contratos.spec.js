const { test, expect } = require('@playwright/test');
const { companyData, familyData, personData } = require('./fixtures/socios.fixture');
const { userData } = require('./fixtures/usuarios.fixture');
const {
  apiCall,
  apiResult,
  cleanupCatalogByName,
  cleanupFamilyByPrefix,
  cleanupSocioByDocument,
  cleanupUsersByPrefix,
  closeApiSession,
  createApiSession,
  expectApiError,
} = require('./helpers/api.helper');
const {
  createCatalog,
  createCompany,
  createFamily,
  createPerson,
  createUser,
  findCatalogByName,
} = require('./helpers/entities.helper');
const { todayIso, uniqueSuffix } = require('./helpers/data.helper');
const { loadTestEnv } = require('./helpers/env.helper');

loadTestEnv();

const PRIVATE_ROUTE_TRANSIENT_HTTP_STATUS = new Set([408, 425, 429, 500, 502, 503, 504]);
const PRIVATE_ROUTE_RETRY_DELAYS_MS = [300, 800, 1600];

function isTransientPrivateRouteNetworkError(error) {
  const message = String(error?.message || error || '').toLowerCase();
  return [
    'socket hang up',
    'econnreset',
    'econnrefused',
    'etimedout',
    'esockettimedout',
    'eai_again',
    'enotfound',
    'network socket disconnected',
    'connection reset',
    'connection closed',
    'fetch failed',
  ].some((token) => message.includes(token));
}

function waitForRetry(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function privateRouteWithoutSession(requestContext, action, options = {}) {
  let lastError = null;
  const maxAttempts = PRIVATE_ROUTE_RETRY_DELAYS_MS.length + 1;

  for (let attempt = 1; attempt <= maxAttempts; attempt += 1) {
    try {
      const result = await apiResult(requestContext, action, {
        ...options,
        session: null,
      });

      if (
        PRIVATE_ROUTE_TRANSIENT_HTTP_STATUS.has(result.status) &&
        attempt < maxAttempts
      ) {
        await waitForRetry(PRIVATE_ROUTE_RETRY_DELAYS_MS[attempt - 1]);
        continue;
      }

      return result;
    } catch (error) {
      lastError = error;
      if (
        attempt >= maxAttempts ||
        !isTransientPrivateRouteNetworkError(error)
      ) {
        throw error;
      }
      await waitForRetry(PRIVATE_ROUTE_RETRY_DELAYS_MS[attempt - 1]);
    }
  }

  throw lastError || new Error(`No se pudo verificar la ruta privada ${action}.`);
}

test.describe.configure({ mode: 'serial' });

test.describe('Contratos, validaciones y seguridad de la API actual', () => {
  test('health responde sin sesión y confirma disponibilidad de la API', async ({ request }) => {
    const health = await apiCall(request, 'health', { session: null });
    expect(health).toBeTruthy();
    expect(health.exito).not.toBe(false);
  });

  test('el router rechaza action ausente, rutas desconocidas, métodos incorrectos y tokens excesivos', async ({ request }) => {
    const missingAction = await apiResult(request, '', { session: null });
    expect(missingAction.status).toBe(400);
    expect(missingAction.body?.mensaje).toMatch(/Falta el parámetro action/i);

    const unknownAction = await apiResult(request, 'pw_e2e_accion_inexistente', {
      session: null,
    });
    expect(unknownAction.status).toBe(404);
    expect(unknownAction.body?.mensaje).toMatch(/Acción no encontrada/i);

    const wrongMethod = await apiResult(request, 'health', {
      method: 'POST',
      data: {},
      session: null,
    });
    expect(wrongMethod.status).toBe(405);
    expect(wrongMethod.body?.mensaje).toMatch(/Método HTTP no permitido/i);

    const oversizedToken = await apiResult(request, 'dashboard_resumen', {
      session: { token: 'x'.repeat(129) },
    });
    expect(oversizedToken.status).toBe(401);
    expect(oversizedToken.body?.codigo).toBe('SESSION_REQUIRED');
  });

  test('la infraestructura E2E exige header, confirmación, scope y auditoría válidos', async ({ request }) => {
    const withoutHeader = await apiResult(request, 'e2e_status', {
      headers: { 'X-LALCEC-E2E': 'NO' },
    });
    expect(withoutHeader.status).toBe(403);
    expect(withoutHeader.body?.codigo).toBe('E2E_HEADER_REQUIRED');

    await expectApiError(
      request,
      'e2e_cleanup',
      { method: 'POST', data: { confirmacion: 'NO' } },
      { status: 422, code: 'E2E_CLEANUP_CONFIRMACION_INVALIDA' },
    );
    await expectApiError(
      request,
      'e2e_cleanup_scope',
      {
        method: 'POST',
        data: {
          confirmacion: 'LIMPIAR_PLAYWRIGHT',
          scope: 'scope_no_permitido',
          value: 'PW E2E',
        },
      },
      { status: 422, code: 'E2E_SCOPE_INVALIDO' },
    );
    await expectApiError(
      request,
      'e2e_saldo_favor_fixture',
      {
        method: 'POST',
        data: {
          confirmacion: 'NO',
          id_socio: 2147483647,
          monto: 100,
        },
      },
      { status: 422, code: 'E2E_CLEANUP_CONFIRMACION_INVALIDA' },
    );
    await expectApiError(
      request,
      'e2e_saldo_favor_fixture',
      {
        method: 'POST',
        data: {
          confirmacion: 'LIMPIAR_PLAYWRIGHT',
          id_socio: 2147483647,
          monto: 100,
        },
      },
      { status: 409, code: 'E2E_SCOPE_BLOCKED' },
    );
    // Las opciones económicas faltantes solo pueden prepararse con admin,
    // header E2E, confirmación y nombres automáticos predefinidos.
    await expectApiError(request, 'e2e_medicamentos_contable_fixture', {
      method: 'POST', headers: { 'X-LALCEC-E2E': 'NO' },
      data: { confirmacion: 'LIMPIAR_PLAYWRIGHT', opciones: [
        { tipo: 'CATEGORIA_EGRESO', nombre: 'COMPRA DE MEDICAMENTOS' },
      ] },
    }, { status: 403, code: 'E2E_HEADER_REQUIRED' });
    await expectApiError(request, 'e2e_medicamentos_contable_fixture', {
      method: 'POST', data: { confirmacion: 'NO', opciones: [
        { tipo: 'CATEGORIA_EGRESO', nombre: 'COMPRA DE MEDICAMENTOS' },
      ] },
    }, { status: 422, code: 'E2E_CLEANUP_CONFIRMACION_INVALIDA' });
    await expectApiError(request, 'e2e_medicamentos_contable_fixture', {
      method: 'POST', data: { confirmacion: 'LIMPIAR_PLAYWRIGHT', opciones: [
        { tipo: 'CATEGORIA_EGRESO', nombre: 'PW E2E OPCION NO AUTORIZADA' },
      ] },
    }, { status: 422, code: 'E2E_MED_OPCION_NO_PERMITIDA' });

    await expectApiError(
      request,
      'e2e_auditoria',
      { params: { tabla: 'socios', id: 1 } },
      { status: 422, code: 'E2E_AUDITORIA_INVALIDA' },
    );
  });

  test('CORS autoriza el preflight local esperado y no refleja orígenes externos', async ({ request }) => {
    const allowedOrigin = 'http://localhost:3000';
    const allowed = await apiResult(request, 'health', {
      method: 'OPTIONS',
      session: null,
      headers: {
        Origin: allowedOrigin,
        'Access-Control-Request-Method': 'GET',
        'Access-Control-Request-Headers': 'authorization, x-lalcec-e2e',
      },
    });
    expect(allowed.status).toBe(204);
    expect(allowed.headers['access-control-allow-origin']).toBe(allowedOrigin);
    expect(allowed.headers['access-control-allow-credentials']).toBe('true');
    expect(allowed.headers['access-control-allow-headers']).toContain('X-LALCEC-E2E');

    const blocked = await apiResult(request, 'health', {
      method: 'OPTIONS',
      session: null,
      headers: {
        Origin: 'https://origen-no-permitido.example.test',
        'Access-Control-Request-Method': 'GET',
      },
    });
    expect(blocked.status).toBe(204);
    expect(blocked.headers['access-control-allow-origin']).toBeUndefined();
  });


  test('todas las rutas privadas rechazan una solicitud sin sesión', async ({ request }) => {
    const endpoints = [
      ['auth_usuario_actual', 'GET'],
      ['auth_logout', 'POST'],
      ['dashboard_resumen', 'GET'],
      ['cuotas_listar', 'GET'],
      ['cuotas_totales_estado', 'GET'],
      ['cuotas_saldos_favor', 'GET'],
      ['cuotas_ajustar_saldo_favor', 'POST', { data: {} }],
      ['cuotas_catalogos', 'GET'],
      ['cuotas_contexto_pago', 'GET', { params: { id_socio: 2147483647, anio: 2026, mes: 8 } }],
      ['cuotas_contextos_pago', 'GET', { params: { id_socio: 2147483647, anio: 2026 } }],
      ['cuotas_registrar_pago', 'POST', { data: {} }],
      ['cuotas_registrar_pagos', 'POST', { data: {} }],
      ['cuotas_condonar_pago', 'POST', { data: {} }],
      ['cuotas_eliminar_pago', 'POST', { data: {} }],
      ['cuotas_registrar_cobro', 'POST', { data: {} }],
      ['cuotas_anular', 'POST', { data: {} }],
      ['contable_resumen', 'GET'],
      ['contable_catalogos', 'GET'],
      ['contable_opciones_configuracion', 'GET'],
      ['contable_ingresos_socios', 'GET'],
      ['contable_ingresos_listar', 'GET'],
      ['contable_egresos_listar', 'GET'],
      ['contable_egreso_archivo', 'GET', { params: { id: 2147483647 } }],
      ['contable_opcion_guardar', 'POST', { data: {} }],
      ['contable_opcion_cambiar_estado', 'POST', { data: {} }],
      ['contable_opcion_eliminar', 'POST', { data: {} }],
      ['contable_ingreso_guardar', 'POST', { data: {} }],
      ['contable_ingreso_eliminar', 'POST', { data: {} }],
      ['contable_egreso_guardar', 'POST', { data: {} }],
      ['contable_egreso_eliminar', 'POST', { data: {} }],
      ['socios_listar', 'GET'],
      ['socios_obtener', 'GET', { params: { id: 2147483647 } }],
      ['socios_historial', 'GET', { params: { id: 2147483647 } }],
      ['socios_guardar', 'POST', { data: {} }],
      ['socios_eliminar', 'POST', { data: {} }],
      ['socios_eliminar_definitivo', 'POST', { data: {} }],
      ['socios_reactivar', 'POST', { data: {} }],
      ['familias_listar', 'GET'],
      ['familias_obtener', 'GET', { params: { id: 2147483647 } }],
      ['familias_guardar', 'POST', { data: {} }],
      ['familias_eliminar', 'POST', { data: {} }],
      ['familias_eliminar_definitivo', 'POST', { data: {} }],
      ['familias_reactivar', 'POST', { data: {} }],
      ['categorias_listar', 'GET'],
      ['categorias_obtener', 'GET', { params: { id: 2147483647 } }],
      ['categorias_historial', 'GET', { params: { id: 2147483647 } }],
      ['categorias_guardar', 'POST', { data: {} }],
      ['categorias_eliminar', 'POST', { data: {} }],
      ['categorias_reactivar', 'POST', { data: {} }],
      ['descuentos_familiares_listar', 'GET'],
      ['descuentos_familiares_guardar', 'POST', { data: {} }],
      ['descuentos_familiares_eliminar', 'POST', { data: {} }],
      ['configuracion_obtener', 'GET'],
      ['configuracion_lista_guardar', 'POST', { data: {} }],
      ['configuracion_lista_eliminar', 'POST', { data: {} }],
      ['configuracion_lista_baja', 'POST', { data: {} }],
      ['configuracion_lista_reactivar', 'POST', { data: {} }],
      ['configuracion_lista_eliminar_definitivo', 'POST', { data: {} }],
      ['usuarios_listar', 'GET'],
      ['usuarios_guardar', 'POST', { data: {} }],
      ['usuarios_cambiar_estado', 'POST', { data: {} }],
      ['usuarios_eliminar', 'POST', { data: {} }],
    ];

    for (const [action, method, extra = {}] of endpoints) {
      // Este barrido hace decenas de requests seguidas contra Hostinger. LiteSpeed
      // puede cortar una conexión keep-alive de forma transitoria ("socket hang up")
      // aun cuando la API está sana. Como TODAS estas solicitudes van sin sesión,
      // reintentar incluso los POST es seguro: el middleware de autenticación debe
      // rechazarlos antes de que cualquier mutación pueda ejecutarse.
      const result = await privateRouteWithoutSession(
        request,
        action,
        { method, ...extra },
      );

      expect(result.status, `${method} ${action}`).toBe(401);
      expect(result.body?.codigo, `${method} ${action}`).toBe('SESSION_REQUIRED');
    }
  });

  test('la sesión autenticada expone el perfil actual y queda invalidada al cerrar sesión', async ({ request }) => {
    const session = await createApiSession(request, {
      username: process.env.PW_USER,
      password: process.env.PW_PASSWORD,
    });

    const current = await apiCall(request, 'auth_usuario_actual', { session });
    expect(current.usuario.id).toBe(session.usuario.id);
    expect(current.usuario.nombre).toBe(session.usuario.nombre);
    expect(current.usuario.rol).toBe('admin');
    expect(current.organizacion).toBeTruthy();

    await closeApiSession(request, session);
    await expectApiError(
      request,
      'auth_usuario_actual',
      { session },
      { status: 401, code: 'SESSION_REQUIRED' },
    );
  });

  test('contabilidad valida período, catálogos y datos obligatorios', async ({ request }) => {
    await expectApiError(
      request,
      'contable_resumen',
      { params: { anio: 'NO_VALIDO', mes: 8 } },
      { status: 422, code: 'FILTRO_INVALIDO', message: /año/i },
    );
    await expectApiError(
      request,
      'contable_ingresos_socios',
      { params: { anio: 2026, mes: 13 } },
      { status: 422, code: 'FILTRO_INVALIDO', message: /mes/i },
    );
    await expectApiError(
      request,
      'contable_opcion_guardar',
      { method: 'POST', data: { tipo: 'TIPO_INEXISTENTE', nombre: 'PW E2E PRUEBA' } },
      { status: 422, code: 'TIPO_OPCION_INVALIDO' },
    );
    await expectApiError(
      request,
      'contable_opcion_cambiar_estado',
      { method: 'POST', data: { id_opcion: 2147483647, activo: 'tal vez' } },
      { status: 422, code: 'ESTADO_OPCION_INVALIDO' },
    );
    await expectApiError(
      request,
      'contable_opcion_eliminar',
      { method: 'POST', data: { id_opcion: 2147483647 } },
      { status: 404, code: 'OPCION_CONTABLE_NO_ENCONTRADA' },
    );
    await expectApiError(
      request,
      'contable_ingreso_guardar',
      { method: 'POST', data: {} },
      { status: 422, code: 'VALIDATION_ERROR' },
    );
    await expectApiError(
      request,
      'contable_egreso_guardar',
      { method: 'POST', data: {} },
      { status: 422, code: 'VALIDATION_ERROR' },
    );
    await expectApiError(
      request,
      'contable_ingreso_eliminar',
      { method: 'POST', data: { id_ingreso: 2147483647 } },
      { status: 404, code: 'INGRESO_NO_ENCONTRADO' },
    );
    await expectApiError(
      request,
      'contable_egreso_eliminar',
      { method: 'POST', data: { id_egreso: 2147483647 } },
      { status: 404, code: 'EGRESO_NO_ENCONTRADO' },
    );
    await expectApiError(
      request,
      'contable_egreso_archivo',
      { params: { id: 2147483647 } },
      { status: 404, code: 'ARCHIVO_NO_ENCONTRADO' },
    );
  });

  test('las operaciones sobre categorías, descuentos y usuarios inexistentes responden 404', async ({ request }) => {
    for (const [action, options, code] of [
      ['categorias_obtener', { params: { id: 2147483647 } }, 'CATEGORIA_NO_ENCONTRADA'],
      ['categorias_historial', { params: { id: 2147483647 } }, 'CATEGORIA_NO_ENCONTRADA'],
      ['categorias_eliminar', { method: 'POST', data: { id: 2147483647 } }, 'CATEGORIA_NO_ENCONTRADA'],
      ['categorias_reactivar', { method: 'POST', data: { id: 2147483647 } }, 'CATEGORIA_NO_ENCONTRADA'],
      ['descuentos_familiares_eliminar', { method: 'POST', data: { id: 2147483647 } }, 'DESCUENTO_FAMILIAR_NO_ENCONTRADO'],
      ['usuarios_cambiar_estado', { method: 'POST', data: { id: 2147483647, activo: false } }, 'USUARIO_NO_ENCONTRADO'],
      ['usuarios_eliminar', { method: 'POST', data: { id: 2147483647 } }, 'USUARIO_NO_ENCONTRADO'],
    ]) {
      await expectApiError(request, action, options, { status: 404, code });
    }
  });

  test('socios valida filtros, campos, duplicados, tipo inmutable y confirmación destructiva', async ({ request }) => {
    const person = personData();
    const company = companyData();

    try {
      await expectApiError(
        request,
        'socios_listar',
        { params: { tipo: 'OTRO' } },
        { status: 422, code: 'FILTRO_INVALIDO' },
      );
      await expectApiError(
        request,
        'socios_listar',
        { params: { pagina: 0 } },
        { status: 422, code: 'PAGINA_INVALIDA' },
      );
      await expectApiError(
        request,
        'socios_listar',
        { params: { familia: 'NO_VALIDO' } },
        { status: 422, code: 'FILTRO_INVALIDO' },
      );
      await expectApiError(
        request,
        'socios_listar',
        { params: { alta_desde: '2026-12-31', alta_hasta: '2026-01-01' } },
        { status: 422, code: 'FILTRO_INVALIDO' },
      );
      await expectApiError(
        request,
        'socios_listar',
        { params: { estado: 'BORRADO' } },
        { status: 422, code: 'FILTRO_INVALIDO' },
      );
      await expectApiError(
        request,
        'socios_obtener',
        { params: { id: 0 } },
        { status: 422, code: 'VALIDATION_ERROR' },
      );
      await expectApiError(
        request,
        'socios_obtener',
        { params: { id: 2147483647 } },
        { status: 404, code: 'SOCIO_NO_ENCONTRADO' },
      );
      await expectApiError(
        request,
        'socios_historial',
        { params: { id: 2147483647 } },
        { status: 404, code: 'SOCIO_NO_ENCONTRADO' },
      );
      await expectApiError(
        request,
        'socios_guardar',
        { method: 'POST', data: { tipo_socio: 'OTRO', apellido: 'PW E2E INVALIDO', email: 'pw.tipo.invalido@example.test' } },
        { status: 422, code: 'VALIDATION_ERROR' },
      );
      await expectApiError(
        request,
        'socios_guardar',
        {
          method: 'POST',
          data: {
            tipo_socio: 'PERSONA',
            apellido: 'PW E2E PRUEBA',
            nombre: 'DNI',
            dni: '123',
            fecha_alta: todayIso(),
          },
        },
        { status: 422, code: 'VALIDATION_ERROR', message: /DNI/i },
      );
      await expectApiError(
        request,
        'socios_guardar',
        {
          method: 'POST',
          data: {
            tipo_socio: 'EMPRESA',
            razon_social: 'PW E2E EMPRESA INVÁLIDA',
            cuit: '2030',
            fecha_alta: todayIso(),
          },
        },
        { status: 422, code: 'VALIDATION_ERROR', message: /CUIT/i },
      );
      await expectApiError(
        request,
        'socios_guardar',
        {
          method: 'POST',
          data: {
            tipo_socio: 'PERSONA',
            apellido: 'PW E2E PRUEBA',
            nombre: 'EMAIL',
            dni: person.dni,
            email: 'correo-invalido',
            fecha_alta: todayIso(),
          },
        },
        { status: 422, code: 'VALIDATION_ERROR', message: /correo|email/i },
      );

      const saved = await createPerson(request, person);
      expect(saved.id_socio).toBeGreaterThan(0);

      await expectApiError(
        request,
        'socios_guardar',
        {
          method: 'POST',
          data: {
            tipo_socio: 'PERSONA',
            apellido: `${person.apellido} DUPLICADO`,
            nombre: person.nombre,
            dni: person.dni,
            fecha_alta: todayIso(),
          },
        },
        { status: 409, code: 'DNI_DUPLICADO' },
      );
      await expectApiError(
        request,
        'socios_guardar',
        {
          method: 'POST',
          data: {
            id_socio: saved.id_socio,
            tipo_socio: 'EMPRESA',
            razon_social: company.razonSocial,
            cuit: company.cuit,
            fecha_alta: todayIso(),
          },
        },
        { status: 409, code: 'TIPO_SOCIO_INMUTABLE' },
      );
      await expectApiError(
        request,
        'socios_eliminar',
        { method: 'POST', data: { id: saved.id_socio, fecha_baja: todayIso(), motivo_baja: '' } },
        { status: 422, code: 'VALIDATION_ERROR' },
      );
      await expectApiError(
        request,
        'socios_eliminar_definitivo',
        { method: 'POST', data: { id: saved.id_socio, confirmacion: 'NO' } },
        { status: 422, code: 'CONFIRMACION_ELIMINACION_INVALIDA' },
      );
    } finally {
      await cleanupSocioByDocument(request, {
        tipo: 'PERSONA',
        documento: person.dni,
      }).catch(() => false);
      // También limpia una empresa que pudiera haberse creado si una versión
      // anterior del test envió el identificador de edición con una clave incorrecta.
      await cleanupSocioByDocument(request, {
        tipo: 'EMPRESA',
        documento: company.cuit,
      }).catch(() => false);
    }
  });

  test('familias valida integrantes, titular, duplicados, conflictos y estados', async ({ request }) => {
    const memberA = personData();
    const memberB = personData();
    const memberForDelete = personData();
    const family = familyData();
    let personA;
    let personB;
    let personForDelete;

    try {
      await expectApiError(
        request,
        'familias_listar',
        { params: { estado: 'borrada' } },
        { status: 422, code: 'FILTRO_INVALIDO' },
      );
      await expectApiError(
        request,
        'familias_obtener',
        { params: { id: 2147483647 } },
        { status: 404, code: 'FAMILIA_NO_ENCONTRADA' },
      );
      await expectApiError(
        request,
        'familias_guardar',
        { method: 'POST', data: { nombre: family.nombre, integrantes: [] } },
        { status: 422, code: 'VALIDATION_ERROR', message: /integrante/i },
      );

      personA = await createPerson(request, memberA);
      personB = await createPerson(request, memberB);
      personForDelete = await createPerson(request, memberForDelete);

      const memberPayload = (person, titular) => ({
        id_socio: person.id_socio,
        parentesco: titular ? 'TITULAR' : 'INTEGRANTE',
        es_titular: titular,
        fecha_incorporacion: todayIso(),
        observaciones: 'CONTRATO E2E',
      });

      await expectApiError(
        request,
        'familias_guardar',
        {
          method: 'POST',
          data: {
            nombre: `${family.nombre} TITULARES`,
            integrantes: [memberPayload(personA, true), memberPayload(personB, true)],
          },
        },
        { status: 409, code: 'TITULAR_DUPLICADO' },
      );

      const saved = await createFamily(request, family, [personA, personB]);
      expect(saved.id_familia).toBeGreaterThan(0);

      await expectApiError(
        request,
        'familias_guardar',
        {
          method: 'POST',
          data: {
            nombre: family.nombre,
            integrantes: [memberPayload(personB, true)],
          },
        },
        { status: 409, code: 'FAMILIA_DUPLICADA' },
      );
      await expectApiError(
        request,
        'familias_guardar',
        {
          method: 'POST',
          data: {
            nombre: `${family.nombre} OTRA`,
            integrantes: [memberPayload(personA, true)],
          },
        },
        { status: 409, code: 'SOCIO_YA_TIENE_FAMILIA' },
      );
      await expectApiError(
        request,
        'familias_guardar',
        {
          method: 'POST',
          data: {
            id_familia: saved.id_familia,
            nombre: family.nombre,
            integrantes: [memberPayload(personA, true)],
          },
        },
        { status: 422, code: 'MOTIVO_DESVINCULACION_REQUERIDO' },
      );

      await expectApiError(
        request,
        'familias_eliminar',
        {
          method: 'POST',
          data: {
            id: saved.id_familia,
            fecha_baja: '2000-01-01',
            motivo_baja: 'BAJA CON FECHA INVÁLIDA E2E',
          },
        },
        { status: 422, code: 'FECHA_INVALIDA' },
      );

      await apiCall(request, 'familias_eliminar', {
        method: 'POST',
        data: { id: saved.id_familia, fecha_baja: todayIso(), motivo_baja: 'BAJA E2E' },
      });
      await expectApiError(
        request,
        'familias_eliminar',
        { method: 'POST', data: { id: saved.id_familia } },
        { status: 409, code: 'ESTADO_SIN_CAMBIOS' },
      );
      await expectApiError(
        request,
        'familias_guardar',
        {
          method: 'POST',
          data: {
            id_familia: saved.id_familia,
            nombre: `${family.nombre} EDITADA`,
            integrantes: [memberPayload(personA, true)],
          },
        },
        { status: 409, code: 'FAMILIA_INACTIVA' },
      );
      await apiCall(request, 'familias_reactivar', {
        method: 'POST',
        data: { id: saved.id_familia },
      });
      await expectApiError(
        request,
        'familias_reactivar',
        { method: 'POST', data: { id: saved.id_familia } },
        { status: 409, code: 'ESTADO_SIN_CAMBIOS' },
      );

      // Reactivar conserva el historial, pero no reconstruye los vínculos. Se
      // incorpora un tercer socio sin vínculo histórico para probar el borrado
      // de una familia activa sin duplicar el par familia-socio conservado.
      await apiCall(request, 'familias_guardar', {
        method: 'POST',
        data: {
          id_familia: saved.id_familia,
          nombre: family.nombre,
          descripcion: family.descripcion,
          integrantes: [memberPayload(personForDelete, true)],
        },
      });
      await expectApiError(
        request,
        'familias_eliminar_definitivo',
        {
          method: 'POST',
          data: { id: saved.id_familia, confirmacion: 'NO' },
        },
        { status: 422, code: 'CONFIRMACION_ELIMINACION_INVALIDA' },
      );

      const deletedActive = await apiCall(request, 'familias_eliminar_definitivo', {
        method: 'POST',
        data: { id: saved.id_familia, confirmacion: 'ELIMINAR' },
      });
      expect(deletedActive.id_familia).toBe(saved.id_familia);
      expect(deletedActive.impacto_eliminacion).toEqual({
        socios_sin_familia: 1,
        vinculos_eliminados: 3,
      });
      await expectApiError(
        request,
        'familias_obtener',
        { params: { id: saved.id_familia } },
        { status: 404, code: 'FAMILIA_NO_ENCONTRADA' },
      );

      for (const person of [personA, personB, personForDelete]) {
        const preserved = await apiCall(request, 'socios_obtener', {
          params: { id: person.id_socio },
        });
        expect(preserved.item.id_socio).toBe(person.id_socio);
        expect(preserved.item.id_familia).toBeNull();
        expect(preserved.item.familia).toBeNull();
      }

      const inactiveFamily = await createFamily(
        request,
        {
          ...family,
          nombre: `${family.nombre} BAJA DEFINITIVA`,
          descripcion: `${family.descripcion} BAJA DEFINITIVA`,
        },
        [personB],
      );
      await apiCall(request, 'familias_eliminar', {
        method: 'POST',
        data: {
          id: inactiveFamily.id_familia,
          fecha_baja: todayIso(),
          motivo_baja: 'BAJA PREVIA A ELIMINACIÓN DEFINITIVA E2E',
        },
      });
      const deletedInactive = await apiCall(request, 'familias_eliminar_definitivo', {
        method: 'POST',
        data: { id: inactiveFamily.id_familia, confirmacion: 'ELIMINAR' },
      });
      expect(deletedInactive.impacto_eliminacion).toEqual({
        socios_sin_familia: 0,
        vinculos_eliminados: 1,
      });
      await expectApiError(
        request,
        'familias_obtener',
        { params: { id: inactiveFamily.id_familia } },
        { status: 404, code: 'FAMILIA_NO_ENCONTRADA' },
      );
      const preservedAfterInactiveDelete = await apiCall(request, 'socios_obtener', {
        params: { id: personB.id_socio },
      });
      expect(preservedAfterInactiveDelete.item.id_familia).toBeNull();
    } finally {
      try {
        await cleanupFamilyByPrefix(request, family.prefix);
      } catch (_error) {
        // La familia puede no haberse creado.
      }
      for (const target of [memberA, memberB, memberForDelete]) {
        await cleanupSocioByDocument(request, {
          tipo: 'PERSONA',
          documento: target.dni,
        }).catch(() => false);
      }
    }
  });

  test('los dos catálogos validan altas, duplicados, baja, reactivación y eliminación definitiva con desvinculación', async ({ request }) => {
    const suffix = uniqueSuffix();
    const definitions = [
      {
        list: 'medios_pago',
        idField: 'id_medio_pago',
        name: `PW E2E MEDIO API ${suffix}`,
        usedName: `PW E2E MEDIO USADO ${suffix}`,
        owner: personData(),
        type: 'PERSONA',
      },
      {
        list: 'condiciones_iva',
        idField: 'id_condicion_iva',
        name: `PW E2E IVA API ${suffix}`,
        usedName: `PW E2E IVA USADA ${suffix}`,
        owner: companyData(),
        type: 'EMPRESA',
      },
    ];

    try {
      await expectApiError(
        request,
        'configuracion_lista_guardar',
        { method: 'POST', data: { lista: 'otra', nombre: 'PW E2E X' } },
        { status: 422, code: 'LISTA_CONFIGURACION_INVALIDA' },
      );
      // El contrato actual de clean_text recorta al máximo permitido en lugar de
      // rechazar el texto largo. Verificamos explícitamente ese comportamiento y
      // eliminamos inmediatamente el registro E2E creado para no dejar residuos.
      const longCatalogInput = `PW E2E MEDIO LARGO ${suffix} ${'X'.repeat(300)}`;
      const longCatalog = await apiCall(request, 'configuracion_lista_guardar', {
        method: 'POST',
        data: { lista: 'medios_pago', nombre: longCatalogInput },
      });
      expect(longCatalog.item.nombre).toBe(longCatalogInput.toUpperCase().slice(0, 100));
      expect(longCatalog.item.nombre).toHaveLength(100);
      await apiCall(request, 'configuracion_lista_eliminar_definitivo', {
        method: 'POST',
        data: { lista: 'medios_pago', id: longCatalog.item.id_medio_pago },
      });

      for (const definition of definitions) {
        const unused = await createCatalog(request, definition.list, definition.name);
        expect(unused[definition.idField]).toBeGreaterThan(0);
        await expectApiError(
          request,
          'configuracion_lista_guardar',
          { method: 'POST', data: { lista: definition.list, nombre: definition.name } },
          { status: 409, code: 'NOMBRE_DUPLICADO' },
        );

        // Conservamos también la ruta histórica configuracion_lista_eliminar como
        // contrato de compatibilidad: hoy equivale a eliminación definitiva.
        const removedUnused = await apiCall(request, 'configuracion_lista_eliminar', {
          method: 'POST',
          data: { lista: definition.list, id: unused[definition.idField] },
        });
        expect(removedUnused.eliminado_definitivo).toBe(true);
        expect(removedUnused.cantidad_usos).toBe(0);
        expect(removedUnused.registros_desvinculados).toBe(0);
        expect(await findCatalogByName(request, definition.list, definition.name)).toBeNull();

        const used = await createCatalog(request, definition.list, definition.usedName);
        let owner;
        if (definition.type === 'PERSONA') {
          owner = await createPerson(request, definition.owner, {
            id_medio_pago: used[definition.idField],
          });
        } else {
          owner = await createCompany(request, definition.owner, {
            id_condicion_iva: used[definition.idField],
          });
        }

        const disabled = await apiCall(request, 'configuracion_lista_baja', {
          method: 'POST',
          data: { lista: definition.list, id: used[definition.idField] },
        });
        expect(disabled.eliminado_definitivo).toBe(false);
        expect(disabled.item.activo).toBe(false);

        const stillLinkedWhileInactive = await apiCall(request, 'socios_obtener', {
          params: { id: owner.id_socio },
        });
        expect(stillLinkedWhileInactive.item[definition.idField]).toBe(used[definition.idField]);

        const reactivated = await apiCall(request, 'configuracion_lista_reactivar', {
          method: 'POST',
          data: { lista: definition.list, id: used[definition.idField] },
        });
        expect(reactivated.item.activo).toBe(true);

        const removedUsed = await apiCall(request, 'configuracion_lista_eliminar_definitivo', {
          method: 'POST',
          data: { lista: definition.list, id: used[definition.idField] },
        });
        expect(removedUsed.eliminado_definitivo).toBe(true);
        expect(removedUsed.cantidad_usos).toBeGreaterThanOrEqual(1);
        expect(removedUsed.registros_desvinculados).toBeGreaterThanOrEqual(1);
        expect(await findCatalogByName(request, definition.list, definition.usedName)).toBeNull();

        const ownerAfterDelete = await apiCall(request, 'socios_obtener', {
          params: { id: owner.id_socio },
        });
        expect(ownerAfterDelete.item[definition.idField]).toBeNull();
      }
    } finally {
      for (const definition of definitions) {
        await cleanupSocioByDocument(request, {
          tipo: definition.type,
          documento: definition.type === 'PERSONA'
            ? definition.owner.dni
            : definition.owner.cuit,
        }).catch(() => false);
        await cleanupCatalogByName(request, definition.list, definition.name).catch(() => false);
        await cleanupCatalogByName(request, definition.list, definition.usedName).catch(() => false);
      }
    }
  });

  test('usuarios valida formato, autoprotección, baja y eliminación definitiva aun con historial', async ({ request }) => {
    const user = userData();
    const selfUser = userData();
    let created;
    let selfCreated;
    let selfSession;
    let userSession;

    try {
      await expectApiError(
        request,
        'usuarios_guardar',
        {
          method: 'POST',
          data: {
            usuario: 'ab',
            email: `pw.short.${uniqueSuffix().toLowerCase()}@example.test`,
            rol: 'vista',
            contrasena: 'Password123',
            confirmar_contrasena: 'Password123',
          },
        },
        { status: 422, code: 'VALIDATION_ERROR', message: /3 caracteres/i },
      );
      await expectApiError(
        request,
        'usuarios_guardar',
        {
          method: 'POST',
          data: {
            usuario: `pw e2e ${uniqueSuffix()}`,
            email: `pw.invalidchars.${uniqueSuffix().toLowerCase()}@example.test`,
            rol: 'vista',
            contrasena: 'Password123',
            confirmar_contrasena: 'Password123',
          },
        },
        { status: 422, code: 'VALIDATION_ERROR' },
      );
      await expectApiError(
        request,
        'usuarios_guardar',
        {
          method: 'POST',
          data: {
            usuario: `${user.username}_mail`,
            email: 'correo-invalido',
            rol: 'vista',
            contrasena: user.password,
            confirmar_contrasena: user.password,
          },
        },
        { status: 422, code: 'VALIDATION_ERROR', message: /email/i },
      );
      await expectApiError(
        request,
        'usuarios_guardar',
        {
          method: 'POST',
          data: {
            usuario: `${user.username}_rol`,
            rol: 'superadmin',
            contrasena: user.password,
            confirmar_contrasena: user.password,
          },
        },
        { status: 422, code: 'VALIDATION_ERROR', message: /rol/i },
      );
      await expectApiError(
        request,
        'usuarios_guardar',
        {
          method: 'POST',
          data: {
            usuario: `${user.username}_pass`,
            rol: 'vista',
            contrasena: 'corta',
            confirmar_contrasena: 'corta',
          },
        },
        { status: 422, code: 'VALIDATION_ERROR', message: /8 y 128/i },
      );

      created = await createUser(request, user);
      expect(created.id).toBeGreaterThan(0);

      await expectApiError(
        request,
        'usuarios_guardar',
        {
          method: 'POST',
          data: {
            usuario: user.username,
            email: `otro.${user.email}`,
            rol: 'vista',
            contrasena: user.password,
            confirmar_contrasena: user.password,
          },
        },
        { status: 409, code: 'USUARIO_DUPLICADO' },
      );
      await expectApiError(
        request,
        'usuarios_guardar',
        {
          method: 'POST',
          data: {
            usuario: `${user.username}_otro`,
            email: user.email,
            rol: 'vista',
            contrasena: user.password,
            confirmar_contrasena: user.password,
          },
        },
        { status: 409, code: 'EMAIL_DUPLICADO' },
      );

      selfCreated = await createUser(request, selfUser, { rol: 'admin' });
      selfSession = await createApiSession(request, {
        username: selfUser.username,
        password: selfUser.password,
      });
      expect(selfSession.usuario.rol).toBe('admin');

      await expectApiError(
        request,
        'usuarios_guardar',
        {
          method: 'POST',
          session: selfSession,
          data: {
            id: selfCreated.id,
            usuario: selfUser.username,
            email: selfUser.email,
            rol: 'vista',
            contrasena: '',
            confirmar_contrasena: '',
          },
        },
        { status: 409, code: 'USUARIO_ACTUAL_ROL' },
      );
      await expectApiError(
        request,
        'usuarios_cambiar_estado',
        { method: 'POST', data: { id: selfCreated.id, activo: false }, session: selfSession },
        { status: 409, code: 'USUARIO_ACTUAL_BAJA' },
      );
      await expectApiError(
        request,
        'usuarios_eliminar',
        { method: 'POST', data: { id: selfCreated.id }, session: selfSession },
        { status: 409, code: 'USUARIO_ACTUAL_ELIMINAR' },
      );
      await closeApiSession(request, selfSession);
      selfSession = null;
      await apiCall(request, 'usuarios_eliminar', {
        method: 'POST',
        data: { id: selfCreated.id },
      });
      selfCreated = null;
      await expectApiError(
        request,
        'usuarios_cambiar_estado',
        { method: 'POST', data: { id: created.id, activo: 'tal vez' } },
        { status: 422, code: 'VALIDATION_ERROR' },
      );

      await apiCall(request, 'usuarios_cambiar_estado', {
        method: 'POST',
        data: { id: created.id, activo: false },
      });
      await expectApiError(
        request,
        'auth_login',
        {
          method: 'POST',
          session: null,
          data: { usuario: user.username, contrasena: user.password },
        },
        { status: 403, code: 'USER_DISABLED' },
      );
      await apiCall(request, 'usuarios_cambiar_estado', {
        method: 'POST',
        data: { id: created.id, activo: true },
      });

      userSession = await createApiSession(request, {
        username: user.username,
        password: user.password,
      });
      await closeApiSession(request, userSession);
      userSession = null;

      const usersWithHistory = await apiCall(request, 'usuarios_listar');
      const userWithHistory = usersWithHistory.usuarios.find(
        (item) => Number(item.id) === Number(created.id),
      );
      expect(userWithHistory).toBeTruthy();
      expect(Number(userWithHistory.cantidad_accesos)).toBeGreaterThan(0);
      expect(userWithHistory.puede_eliminar).toBe(true);

      const deleted = await apiCall(request, 'usuarios_eliminar', {
        method: 'POST',
        data: { id: created.id },
      });
      expect(Number(deleted.id)).toBe(Number(created.id));

      const usersAfterDelete = await apiCall(request, 'usuarios_listar');
      expect(
        usersAfterDelete.usuarios.some((item) => Number(item.id) === Number(created.id)),
      ).toBe(false);
      created = null;
    } finally {
      await closeApiSession(request, userSession).catch(() => undefined);
      await closeApiSession(request, selfSession).catch(() => undefined);
      try {
        await cleanupUsersByPrefix(request, user.username);
        await cleanupUsersByPrefix(request, selfUser.username);
      } catch (_error) {
        // La limpieza protegida puede estar deshabilitada fuera del entorno local.
      }
    }
  });
});
