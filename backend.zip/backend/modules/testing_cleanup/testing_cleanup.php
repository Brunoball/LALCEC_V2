<?php
declare(strict_types=1);

// Dependencias compartidas del escudo Playwright usadas por este modulo.
// require_once evita declarar las funciones dos veces cuando el Router ya cargo el guard.
require_once __DIR__ . '/../../core/e2e_guard.php';

final class TestingCleanup
{
    private const CONFIRMATION = 'LIMPIAR_PLAYWRIGHT';

    /**
     * Los validadores E2E son funciones globales provistas por e2e_guard.php.
     * Se invocan por nombre para evitar falsos avisos de 'undefined function'
     * del analizador de VS Code, sin duplicar las reglas del escudo.
     * Si falta alguna funcion, la operacion queda bloqueada (fail closed).
     */
    private static function verificarEscudoE2E(string $funcion, mixed ...$argumentos): bool
    {
        if (!function_exists($funcion)) {
            api_error(
                'El escudo de seguridad de Playwright no esta disponible.',
                'E2E_GUARD_UNAVAILABLE',
                503
            );
        }

        return (bool) call_user_func($funcion, ...$argumentos);
    }

    private static function requireE2EAdmin(): array
    {
        if (!self::verificarEscudoE2E('e2e_request_enabled')) {
            api_error(
                'Las herramientas de Playwright requieren X-LALCEC-E2E=PLAYWRIGHT.',
                'E2E_HEADER_REQUIRED',
                403
            );
        }
        return require_admin();
    }

    private static function requireConfirmation(array $body): void
    {
        $confirmation = strtoupper(trim((string)($body['confirmacion'] ?? '')));
        if ($confirmation !== self::CONFIRMATION) {
            api_error(
                'Confirmación de limpieza E2E inválida.',
                'E2E_CLEANUP_CONFIRMACION_INVALIDA',
                422
            );
        }
    }

    public static function run(): never
    {
        $auth = self::requireE2EAdmin();
        self::requireConfirmation(request_body());

        $result = self::cleanup($auth['db'], (int)$auth['id_sesion']);
        api_success($result, 'Limpieza final de Playwright completada.');
    }

    public static function cleanupScope(): never
    {
        $auth = self::requireE2EAdmin();
        $body = request_body();
        self::requireConfirmation($body);

        $scope = strtolower(trim((string)($body['scope'] ?? '')));
        $value = $body['value'] ?? null;
        $result = self::cleanupScoped($auth['db'], $scope, $value);
        api_success($result, 'Limpieza E2E acotada completada.');
    }

    /**
     * Fixture controlado para probar el circuito de saldos a favor antes de que
     * el backend conversacional del bot sea quien genere los SOBRANTES reales.
     * Sólo admite socios E2E y nunca queda expuesto como API funcional normal.
     */
    /**
     * Prepara solamente opciones CONTABLES AUTOMÁTICAS de Medicamentos que
     * faltan en la DB durante Playwright. Son nombres fijos, por lo que
     * contable_opcion_guardar (que exige "PW E2E") no sirve para este caso.
     * Un registro de auditoría marcado como PW E2E identifica EXCLUSIVAMENTE
     * la opción creada aquí para su posterior limpieza segura.
     */
    public static function medicamentosContableFixture(): never
    {
        $auth = self::requireE2EAdmin();
        $body = request_body();
        self::requireConfirmation($body);
        $items = $body['opciones'] ?? null;
        if (!is_array($items) || array_is_list($items) === false || count($items) < 1 || count($items) > 12) {
            api_error('Opciones de medicamentos E2E inválidas.', 'E2E_MED_OPCIONES_INVALIDAS', 422);
        }
        $permitidas = [
            'CATEGORIA_EGRESO' => [
                'COMPRA DE MEDICAMENTOS', 'DEVOLUCIONES DE SEÑAS',
                'DEVOLUCIONES DE VENTAS DE MEDICAMENTOS',
            ],
            'CONCEPTO_EGRESO' => [
                'COMPRA DE MEDICAMENTOS', 'DEVOLUCIÓN DE SEÑA',
                'DEVOLUCIÓN DE VENTA DE MEDICAMENTOS',
            ],
            'CATEGORIA_INGRESO' => [
                'VENTA DE MEDICAMENTOS', 'SEÑAS DE MEDICAMENTOS',
                'REINTEGROS DE COMPRAS DE MEDICAMENTOS',
            ],
            'CONCEPTO_INGRESO' => [
                'VENTA DE MEDICAMENTOS', 'COBRO DE SEÑA',
                'REINTEGRO DE COMPRA DE MEDICAMENTOS',
            ],
        ];
        $db = $auth['db'];
        $creadas = [];
        $existentes = [];
        $db->beginTransaction();
        try {
            foreach ($items as $item) {
                if (!is_array($item)) {
                    api_error('Opción de medicamentos E2E inválida.', 'E2E_MED_OPCION_INVALIDA', 422);
                }
                $tipo = (string)($item['tipo'] ?? '');
                $nombre = (string)($item['nombre'] ?? '');
                if (!isset($permitidas[$tipo]) || !in_array($nombre, $permitidas[$tipo], true)) {
                    api_error('Opción no autorizada para el fixture de Medicamentos.', 'E2E_MED_OPCION_NO_PERMITIDA', 422);
                }
                $q = $db->prepare("INSERT INTO contable_opciones (tipo,nombre,activo)
                    VALUES (?,?,1) ON DUPLICATE KEY UPDATE id_opcion=LAST_INSERT_ID(id_opcion)");
                $q->execute([$tipo, $nombre]);
                $id = (int)$db->lastInsertId();
                if ($q->rowCount() === 1) {
                    audit_change($db, $auth, 'TESTING', 'E2E_MEDICAMENTOS_OPCION',
                        'contable_opciones', $id,
                        'PW E2E OPCION AUTOMATICA MEDICAMENTOS ' . $tipo,
                        null, ['tipo' => $tipo, 'nombre' => $nombre]);
                    $creadas[] = $id;
                } else {
                    $existentes[] = $id;
                }
            }
            $db->commit();
        } catch (Throwable $error) {
            if ($db->inTransaction()) $db->rollBack();
            throw $error;
        }
        api_success(['creadas' => $creadas, 'existentes' => $existentes],
            'Opciones contables de Medicamentos preparadas para Playwright.');
    }

    public static function saldoFavorFixture(): never
    {
        $auth = self::requireE2EAdmin();
        $body = request_body();
        self::requireConfirmation($body);

        $partnerId = filter_var(
            $body['id_socio'] ?? null,
            FILTER_VALIDATE_INT,
            ['options' => ['min_range' => 1]]
        );
        if ($partnerId === false) {
            api_error('El socio E2E indicado no es válido.', 'E2E_SALDO_SOCIO_INVALIDO', 422);
        }
        $partnerId = (int)$partnerId;
        if (!self::verificarEscudoE2E('e2e_socio', $auth['db'], $partnerId)) {
            api_error(
                'El fixture de saldo sólo puede aplicarse a socios creados por Playwright.',
                'E2E_SCOPE_BLOCKED',
                409
            );
        }
        if (!self::tableExists($auth['db'], 'saldos_favor_movimientos')) {
            api_error('La tabla de saldos a favor no está disponible.', 'E2E_SALDO_SCHEMA_FALTANTE', 409);
        }

        $rawAmount = str_replace(',', '.', trim((string)($body['monto'] ?? '')));
        if ($rawAmount === '' || !is_numeric($rawAmount)) {
            api_error('El monto del saldo E2E no es válido.', 'E2E_SALDO_MONTO_INVALIDO', 422);
        }
        $amount = round((float)$rawAmount, 2);
        if ($amount <= 0 || $amount > 100000000) {
            api_error('El monto del saldo E2E debe ser mayor a cero.', 'E2E_SALDO_MONTO_INVALIDO', 422);
        }

        $date = valid_date($body['fecha'] ?? date('Y-m-d'), 'saldo E2E');
        $mediumId = null;
        if (($body['id_medio_pago'] ?? null) !== null && ($body['id_medio_pago'] ?? '') !== '') {
            $validatedMedium = filter_var(
                $body['id_medio_pago'],
                FILTER_VALIDATE_INT,
                ['options' => ['min_range' => 1]]
            );
            if ($validatedMedium === false) {
                api_error('El medio de pago E2E no es válido.', 'E2E_SALDO_MEDIO_INVALIDO', 422);
            }
            $mediumId = (int)$validatedMedium;
            $medium = $auth['db']->prepare(
                'SELECT 1 FROM medios_pago WHERE id_medio_pago = ? AND activo = 1 LIMIT 1'
            );
            $medium->execute([$mediumId]);
            if (!$medium->fetchColumn()) {
                api_error('El medio de pago E2E no existe o está inactivo.', 'E2E_SALDO_MEDIO_INVALIDO', 422);
            }
        }

        $token = strtoupper(bin2hex(random_bytes(8)));
        $reference = 'PW E2E SALDO ' . $token;
        $idempotencyKey = 'PW:E2E:SALDO:' . $partnerId . ':' . $token;
        $statement = $auth['db']->prepare(
            "INSERT INTO saldos_favor_movimientos
                (id_socio, fecha, tipo, monto, origen, id_medio_pago, id_usuario,
                 referencia_externa, clave_idempotencia, detalle)
             VALUES (?, ?, 'SOBRANTE', ?, 'BOT', ?, ?, ?, ?, ?)"
        );
        // El fixture debe quedar cronológicamente antes que las acciones que
        // el propio test ejecuta después (pago, reverso, etc.). No usar una
        // hora fija futura como 12:00 porque, si la suite corre por la mañana,
        // un REVERSO creado con NOW() parecería anterior al SOBRANTE.
        $movementDate = $date === date('Y-m-d')
            ? date('Y-m-d H:i:s')
            : $date . ' 00:00:00';

        $statement->execute([
            $partnerId,
            $movementDate,
            $amount,
            $mediumId,
            (int)$auth['id_usuario'],
            $reference,
            $idempotencyKey,
            'PW E2E SOBRANTE PARA PRUEBAS DE SALDO A FAVOR',
        ]);

        api_success([
            'movimiento' => [
                'id_movimiento' => (int)$auth['db']->lastInsertId(),
                'id_socio' => $partnerId,
                'fecha' => $date,
                'tipo' => 'SOBRANTE',
                'monto' => number_format($amount, 2, '.', ''),
                'origen' => 'BOT',
                'id_medio_pago' => $mediumId,
                'referencia_externa' => $reference,
            ],
        ], 'Saldo E2E acreditado correctamente.');
    }

    public static function audit(): never
    {
        $auth = self::requireE2EAdmin();
        $table = trim((string)($_GET['tabla'] ?? ''));
        $id = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        if ($id === false || !in_array($table, ['categorias', 'descuentos_familiares'], true)) {
            api_error('Consulta de auditoría E2E inválida.', 'E2E_AUDITORIA_INVALIDA', 422);
        }

        $allowed = $table === 'categorias'
            ? self::verificarEscudoE2E('e2e_category', $auth['db'], (int)$id)
            : self::verificarEscudoE2E('e2e_discount', $auth['db'], (int)$id);
        if (!$allowed) {
            api_error('La auditoría solicitada no pertenece a un registro E2E.', 'E2E_SCOPE_BLOCKED', 409);
        }

        $statement = $auth['db']->prepare(
            'SELECT accion, descripcion, creado_en
             FROM auditoria
             WHERE tabla_afectada = ? AND id_registro = ?
             ORDER BY id_auditoria ASC'
        );
        $statement->execute([$table, (string)$id]);
        api_success(['items' => $statement->fetchAll()], 'Auditoría E2E obtenida.');
    }

    /**
     * Esta acción existe únicamente para que el globalSetup verifique que el
     * Router está ejecutando e2e_guard_mutation(). En una corrida E2E normal
     * NUNCA debe alcanzarse: el guard fail-closed la intercepta antes y devuelve
     * E2E_SCOPE_BLOCKED.
     */
    public static function guardProbe(): never
    {
        self::requireE2EAdmin();
        api_error(
            'El probe E2E alcanzó el handler: el escudo del Router no está activo.',
            'E2E_GUARD_NOT_ACTIVE',
            500
        );
    }

    public static function status(): never
    {
        $auth = self::requireE2EAdmin();
        api_success([
            'residuos' => self::residueCounts($auth['db'], (int)$auth['id_sesion']),
        ], 'Estado E2E obtenido.');
    }

    public static function snapshot(): never
    {
        $auth = self::requireE2EAdmin();
        api_success([
            'snapshot' => self::realDataSnapshot($auth['db']),
        ], 'Huella de datos reales obtenida.');
    }

    /** Opciones comunes de Medicamentos creadas por el fixture (no por usuarios). */
    private static function fixtureOpcionesMedicamentosSql(string $alias = 'o'): string
    {
        return "EXISTS (SELECT 1 FROM auditoria fixture_a
            WHERE fixture_a.tabla_afectada = 'contable_opciones'
              AND fixture_a.id_registro = (CAST({$alias}.id_opcion AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci)
              AND fixture_a.modulo = 'TESTING'
              AND fixture_a.accion = 'E2E_MEDICAMENTOS_OPCION'
              AND fixture_a.descripcion LIKE 'PW E2E OPCION AUTOMATICA MEDICAMENTOS %')";
    }

    private static function cleanup(PDO $db, int $currentSessionId): array
    {
        $filesToDelete = [];
        $counts = [
            'contable_ingresos' => 0,
            'contable_egresos' => 0,
            'contable_opciones' => 0,
            'medicamentos' => 0,
            'medicamentos_movimientos' => 0,
            'medicamentos_prestamos' => 0,
            'medicamentos_prestamos_detalle' => 0,
            'medicamentos_prestamos_devoluciones' => 0,
            'medicamentos_prestamos_senas_movimientos' => 0,
            'medicamentos_solicitudes' => 0,
            'medicamentos_alertas_descartadas' => 0,
            'medicamentos_opciones' => 0,
            'familias' => 0,
            'socios' => 0,
            'socios_eliminados' => 0,
            'saldos_favor_movimientos' => 0,
            'pagos' => 0,
            'pagos_inscripciones' => 0,
            'categorias' => 0,
            'descuentos_familiares' => 0,
            'medios_pago' => 0,
            'condiciones_iva' => 0,
            'usuarios' => 0,
            'sesiones' => 0,
            'login_auditoria' => 0,
            'auditoria' => 0,
            'archivos' => 0,
        ];
        $skipped = [];

        $db->beginTransaction();
        try {
            $testSocios = self::testSocioIds($db);
            $testFamilies = self::ids($db,
                "SELECT id_familia FROM familias
                 WHERE nombre LIKE 'PW E2E FAM %' OR nombre LIKE 'PW EE FAM %'"
            );
            $testCategories = self::ids($db,
                "SELECT id_categoria FROM categorias
                 WHERE nombre LIKE 'PW E2E CAT %' OR nombre LIKE 'PW EE CAT %'"
            );
            $testDiscounts = self::ids($db,
                "SELECT id_descuento_familiar FROM descuentos_familiares
                 WHERE descripcion LIKE 'PW E2E %' OR descripcion LIKE 'PW EE %'"
            );
            $testUsers = self::ids($db,
                "SELECT idUsuario FROM sis_usuarios WHERE usuario LIKE 'pw_e2e_%' OR email LIKE '%@example.test'"
            );
            $testMeans = self::ids($db,
                "SELECT id_medio_pago FROM medios_pago
                 WHERE nombre LIKE 'PW E2E %' OR nombre LIKE 'PW EE %'"
            );
            $testIva = self::ids($db,
                "SELECT id_condicion_iva FROM condiciones_iva
                 WHERE nombre LIKE 'PW E2E %' OR nombre LIKE 'PW EE %'"
            );
            $testOptions = self::ids($db,
                "SELECT id_opcion FROM contable_opciones
                 WHERE nombre LIKE 'PW E2E %' OR nombre LIKE 'PW EE %'"
            );
            // Guardar aparte los IDs firmados por nuestro fixture. La opción
            // preexistente no tiene esta marca y jamás puede ser eliminada.
            $fixtureOptions = self::ids($db,
                'SELECT o.id_opcion FROM contable_opciones o WHERE '
                . self::fixtureOpcionesMedicamentosSql('o')
            );

            $testIncomeIds = self::ids($db,
                "SELECT id_ingreso FROM contable_ingresos
                 WHERE detalle LIKE 'PW E2E %' OR detalle LIKE 'PW EE %'
                    OR proveedor LIKE 'PW E2E %' OR proveedor LIKE 'PW EE %'
                    OR categoria LIKE 'PW E2E %' OR categoria LIKE 'PW EE %'
                    OR concepto LIKE 'PW E2E %' OR concepto LIKE 'PW EE %'"
            );
            $testExpenseIds = self::ids($db,
                "SELECT id_egreso FROM contable_egresos
                 WHERE detalle LIKE 'PW E2E %' OR detalle LIKE 'PW EE %'
                    OR proveedor LIKE 'PW E2E %' OR proveedor LIKE 'PW EE %'
                    OR categoria LIKE 'PW E2E %' OR categoria LIKE 'PW EE %'
                    OR concepto LIKE 'PW E2E %' OR concepto LIKE 'PW EE %'
                    OR numero_comprobante LIKE 'E2E-%'"
            );

            if ($testExpenseIds !== []) {
                $filesToDelete = self::columnForIds($db, 'contable_egresos', 'id_egreso', 'archivo_path', $testExpenseIds);
            }

            // Préstamos y movimientos vinculados a medicamentos E2E, sin lotes.
            $testMedicamentos = [];
            $testMovimientosMedicamentos = [];
            $testPrestamosMedicamentos = [];
            $testDetallesMedicamentos = [];
            $testDevolucionesMedicamentos = [];
            $testSenasMedicamentos = [];
            if (self::tableExists($db,'medicamentos')) {
                $testMedicamentos=self::ids($db,
                    "SELECT id_medicamento FROM medicamentos WHERE nombre_comercial LIKE 'PW E2E %' OR nombre_comercial LIKE 'PW EE %'");
            }
            if ($testMedicamentos !== []) {
                $in=self::placeholders(count($testMedicamentos));
                $testPrestamosMedicamentos=self::ids($db,
                    "SELECT DISTINCT id_prestamo FROM medicamentos_prestamos_detalle WHERE id_medicamento IN ({$in})",$testMedicamentos);
                $testMovimientosMedicamentos=self::ids($db,
                    "SELECT id_movimiento FROM medicamentos_movimientos WHERE id_medicamento IN ({$in})",$testMedicamentos);
                $linkedIncome=self::ids($db,
                    "SELECT DISTINCT id_ingreso_contable FROM medicamentos_movimientos WHERE id_medicamento IN ({$in}) AND id_ingreso_contable IS NOT NULL",$testMedicamentos);
                $linkedExpense=self::ids($db,
                    "SELECT DISTINCT id_egreso_contable FROM medicamentos_movimientos WHERE id_medicamento IN ({$in}) AND id_egreso_contable IS NOT NULL",$testMedicamentos);
                $testIncomeIds=array_values(array_unique(array_merge($testIncomeIds,$linkedIncome)));
                $testExpenseIds=array_values(array_unique(array_merge($testExpenseIds,$linkedExpense)));
            }
            if ($testPrestamosMedicamentos !== []) {
                $in=self::placeholders(count($testPrestamosMedicamentos));
                // Fail closed si un préstamo enlazó un socio real.
                $realSocios=self::ids($db,
                    "SELECT DISTINCT id_socio FROM medicamentos_prestamos WHERE id_prestamo IN ({$in})",$testPrestamosMedicamentos);
                if (array_diff($realSocios,$testSocios)!==[]) {
                    api_error('Hay préstamos de medicamentos E2E asociados a socios reales. Se requiere revisar los datos antes de limpiar.', 'E2E_CLEANUP_INTEGRIDAD', 409);
                }
                $otherMedicines=self::ids($db,
                    "SELECT DISTINCT id_medicamento FROM medicamentos_prestamos_detalle WHERE id_prestamo IN ({$in})",$testPrestamosMedicamentos);
                if(array_diff($otherMedicines,$testMedicamentos)!==[])
                    api_error('Un préstamo E2E incluye medicamentos reales. Limpieza cancelada.', 'E2E_CLEANUP_INTEGRIDAD', 409);
                $testDetallesMedicamentos=self::ids($db,
                    "SELECT id_detalle_prestamo FROM medicamentos_prestamos_detalle WHERE id_prestamo IN ({$in})",$testPrestamosMedicamentos);
                $testSenasMedicamentos=self::ids($db,
                    "SELECT id_movimiento_sena FROM medicamentos_prestamos_senas_movimientos WHERE id_prestamo IN ({$in})",$testPrestamosMedicamentos);
                $senasIngreso=self::ids($db,
                    "SELECT DISTINCT id_ingreso_contable FROM medicamentos_prestamos_senas_movimientos WHERE id_prestamo IN ({$in}) AND id_ingreso_contable IS NOT NULL",$testPrestamosMedicamentos);
                $senasEgreso=self::ids($db,
                    "SELECT DISTINCT id_egreso_contable FROM medicamentos_prestamos_senas_movimientos WHERE id_prestamo IN ({$in}) AND id_egreso_contable IS NOT NULL",$testPrestamosMedicamentos);
                $testIncomeIds=array_values(array_unique(array_merge($testIncomeIds,$senasIngreso)));
                $testExpenseIds=array_values(array_unique(array_merge($testExpenseIds,$senasEgreso)));
            }
            if ($testDetallesMedicamentos !== []) {
                $in=self::placeholders(count($testDetallesMedicamentos));
                $testDevolucionesMedicamentos=self::ids($db,
                    "SELECT id_devolucion FROM medicamentos_prestamos_devoluciones WHERE id_detalle_prestamo IN ({$in})",$testDetallesMedicamentos);
            }
            // Eliminar SOLO claves E2E marcadas por Playwright; no existe FK
            // de las solicitudes al medicamento. Jamás borrar claves normales.
            if (self::tableExists($db,'medicamentos_solicitudes')) {
                $q=$db->prepare("DELETE FROM medicamentos_solicitudes WHERE clave LIKE 'med-PWE2E-%'");
                $q->execute();
                $counts['medicamentos_solicitudes'] += $q->rowCount();
            }
            // Descartes de medicamentos/préstamos E2E, ANTES de borrar sus padres.
            // Se filtran simultáneamente tipo y referencia para evitar colisiones.
            if (self::tableExists($db,'medicamentos_alertas_descartadas')) {
                foreach ([['MEDICAMENTO',$testMedicamentos],['PRESTAMO',$testPrestamosMedicamentos]] as [$tipo,$ids]) {
                    if ($ids === []) continue;
                    $q=$db->prepare('DELETE FROM medicamentos_alertas_descartadas WHERE tipo=? AND id_referencia IN ('
                        .self::placeholders(count($ids)).')');
                    $q->execute(array_merge([$tipo],$ids));
                    $counts['medicamentos_alertas_descartadas'] += $q->rowCount();
                }
            }
            $counts['medicamentos_movimientos'] += self::deleteByIds($db,'medicamentos_movimientos','id_movimiento',$testMovimientosMedicamentos);
            $counts['medicamentos_prestamos_senas_movimientos'] += self::deleteByIds($db,'medicamentos_prestamos_senas_movimientos','id_movimiento_sena',$testSenasMedicamentos);
            $counts['medicamentos_prestamos_devoluciones'] += self::deleteByIds($db,'medicamentos_prestamos_devoluciones','id_devolucion',$testDevolucionesMedicamentos);
            $counts['medicamentos_prestamos_detalle'] += self::deleteByIds($db,'medicamentos_prestamos_detalle','id_detalle_prestamo',$testDetallesMedicamentos);
            $counts['medicamentos_prestamos'] += self::deleteByIds($db,'medicamentos_prestamos','id_prestamo',$testPrestamosMedicamentos);
            $counts['medicamentos'] += self::deleteByIds($db,'medicamentos','id_medicamento',$testMedicamentos);
            // Opciones de selectores creadas por Playwright (nombre PW E2E/PW EE) que ya
            // no usa ningún medicamento ni movimiento. Una opción E2E usada por datos
            // reales se conserva (fail-safe); las opciones reales nunca se tocan.
            if (self::tableExists($db,'medicamentos_opciones')) {
                $q=$db->prepare("DELETE o FROM medicamentos_opciones o
                    WHERE (o.nombre LIKE 'PW E2E %' OR o.nombre LIKE 'PW EE %')
                      AND NOT (o.tipo='PRESENTACION' AND EXISTS (SELECT 1 FROM medicamentos m WHERE m.presentacion=o.nombre))
                      AND NOT (o.tipo='UNIDAD_STOCK' AND EXISTS (SELECT 1 FROM medicamentos m WHERE m.unidad_stock=o.nombre))
                      AND NOT (o.tipo='ORIGEN_INGRESO' AND EXISTS (SELECT 1 FROM medicamentos_movimientos mv WHERE mv.tipo='INGRESO_OTRO' AND mv.origen=o.nombre))
                      AND NOT (o.tipo='SALIDA_STOCK' AND EXISTS (SELECT 1 FROM medicamentos_movimientos mv WHERE mv.tipo='AJUSTE_SALIDA' AND mv.origen=o.nombre))");
                $q->execute();
                $counts['medicamentos_opciones'] += $q->rowCount();
            }

            $testPaymentIds = $testSocios === []
                ? []
                : self::columnForIds($db, 'pagos', 'id_socio', 'id_pago', $testSocios);
            $testRegistrationPaymentIds = self::tableExists($db, 'pagos_inscripciones') && $testSocios !== []
                ? self::columnForIds($db, 'pagos_inscripciones', 'id_socio', 'id_pago_inscripcion', $testSocios)
                : [];

            $counts['contable_ingresos'] += self::deleteByIds($db, 'contable_ingresos', 'id_ingreso', $testIncomeIds);
            $counts['contable_egresos'] += self::deleteByIds($db, 'contable_egresos', 'id_egreso', $testExpenseIds);

            if ($testFamilies !== []) {
                self::deleteByIds($db, 'familias_socios', 'id_familia', $testFamilies);
            }
            if ($testSocios !== []) {
                if (self::tableExists($db, 'saldos_favor_movimientos')) {
                    $counts['saldos_favor_movimientos'] += self::deleteByIds(
                        $db,
                        'saldos_favor_movimientos',
                        'id_socio',
                        $testSocios
                    );
                }
                if (self::tableExists($db, 'socios_eliminados')) {
                    $counts['socios_eliminados'] += self::deleteByIds($db, 'socios_eliminados', 'id_socio', $testSocios);
                }
                self::deleteByIds($db, 'familias_socios', 'id_socio', $testSocios);
                $counts['pagos'] += self::deleteByIds($db, 'pagos', 'id_socio', $testSocios);
                if (self::tableExists($db, 'pagos_inscripciones')) {
                    $counts['pagos_inscripciones'] += self::deleteByIds($db, 'pagos_inscripciones', 'id_socio', $testSocios);
                }
                self::deleteByIds($db, 'socios_historial_estados', 'id_socio', $testSocios);
                $counts['socios'] += self::deleteByIds($db, 'socios', 'id_socio', $testSocios);
            }
            $counts['familias'] += self::deleteByIds($db, 'familias', 'id_familia', $testFamilies);

            // Los asientos E2E ya fueron eliminados. Antes de borrar una
            // opción automática de prueba, verificar que ningún asiento REAL
            // haya empezado a utilizarla en paralelo. En ese caso se conserva.
            foreach ($fixtureOptions as $fixtureId) {
                $q = $db->prepare('SELECT tipo,nombre FROM contable_opciones WHERE id_opcion=? FOR UPDATE');
                $q->execute([$fixtureId]);
                $opcion = $q->fetch();
                if (!$opcion) continue;
                $mapa = [
                    'CATEGORIA_INGRESO' => ['contable_ingresos', 'categoria'],
                    'CONCEPTO_INGRESO' => ['contable_ingresos', 'concepto'],
                    'CATEGORIA_EGRESO' => ['contable_egresos', 'categoria'],
                    'CONCEPTO_EGRESO' => ['contable_egresos', 'concepto'],
                ];
                if (!isset($mapa[$opcion['tipo']])) {
                    $skipped['opciones_med_e2e_inseguras'][] = $fixtureId;
                    continue;
                }
                [$tabla, $columna] = $mapa[$opcion['tipo']];
                $uso = self::scalar($db,
                    "SELECT COUNT(*) FROM {$tabla} WHERE {$columna} = ?",
                    [$opcion['nombre']]
                );
                if ($uso > 0) {
                    $skipped['opciones_med_e2e_usadas'][] = $fixtureId;
                    continue;
                }
                $testOptions[] = $fixtureId;
            }
            $testOptions = array_values(array_unique($testOptions));
            $counts['contable_opciones'] += self::deleteByIds($db, 'contable_opciones', 'id_opcion', $testOptions);

            if ($testCategories !== []) {
                $blocked = self::ids($db,
                    'SELECT DISTINCT id_categoria FROM socios WHERE id_categoria IN ('
                    . self::placeholders(count($testCategories)) . ')',
                    $testCategories
                );
                $safeCategories = array_values(array_diff($testCategories, $blocked));
                if ($blocked !== []) $skipped['categorias_en_uso'] = $blocked;
                self::deleteByIds($db, 'categorias_historial_precios', 'id_categoria', $safeCategories);
                $counts['categorias'] += self::deleteByIds($db, 'categorias', 'id_categoria', $safeCategories);
            }

            $counts['descuentos_familiares'] += self::deleteByIds(
                $db,
                'descuentos_familiares',
                'id_descuento_familiar',
                $testDiscounts
            );

            if ($testMeans !== []) {
                $safeMeans = [];
                foreach ($testMeans as $id) {
                    $uses = self::scalar($db,
                        'SELECT (SELECT COUNT(*) FROM pagos WHERE id_medio_pago = ?)'
                        . ' + (SELECT COUNT(*) FROM socios WHERE id_medio_pago = ?)'
                        . ' + (SELECT COUNT(*) FROM contable_ingresos WHERE id_medio_pago = ?)'
                        . ' + (SELECT COUNT(*) FROM contable_egresos WHERE id_medio_pago = ?)',
                        [$id, $id, $id, $id]
                    );
                    if ($uses === 0) $safeMeans[] = $id;
                    else $skipped['medios_pago_en_uso'][] = $id;
                }
                $counts['medios_pago'] += self::deleteByIds($db, 'medios_pago', 'id_medio_pago', $safeMeans);
            }

            if ($testIva !== []) {
                $safeIva = [];
                foreach ($testIva as $id) {
                    $uses = self::scalar($db, 'SELECT COUNT(*) FROM socios_empresas WHERE id_condicion_iva = ?', [$id]);
                    if ($uses === 0) $safeIva[] = $id;
                    else $skipped['condiciones_iva_en_uso'][] = $id;
                }
                $counts['condiciones_iva'] += self::deleteByIds($db, 'condiciones_iva', 'id_condicion_iva', $safeIva);
            }

            // Sesiones E2E viejas o abiertas por tests individuales. La sesión
            // global actual se conserva hasta el logout del teardown.
            $sessionStatement = $db->prepare(
                "DELETE FROM sis_sesiones
                 WHERE idSesion <> ?
                   AND (user_agent LIKE 'LALCEC-PLAYWRIGHT-E2E%'"
                 . ($testUsers !== []
                    ? ' OR idUsuario IN (' . self::placeholders(count($testUsers)) . ')'
                    : '')
                 . ')'
            );
            $sessionStatement->execute(array_merge([$currentSessionId], $testUsers));
            $counts['sesiones'] += $sessionStatement->rowCount();

            if ($testUsers !== []) {
                $counts['login_auditoria'] += self::deleteByIds($db, 'sis_login_auditoria', 'idUsuario', $testUsers);
            }
            $statement = $db->prepare(
                "DELETE FROM sis_login_auditoria
                 WHERE usuario LIKE 'pw_e2e_%'
                    OR user_agent LIKE 'LALCEC-PLAYWRIGHT-E2E%'"
            );
            $statement->execute();
            $counts['login_auditoria'] += $statement->rowCount();
            $counts['usuarios'] += self::deleteByIds($db, 'sis_usuarios', 'idUsuario', $testUsers);

            $auditReferences = [
                'socios' => $testSocios,
                'familias' => $testFamilies,
                'categorias' => $testCategories,
                'descuentos_familiares' => $testDiscounts,
                'pagos' => $testPaymentIds,
                'pagos_inscripciones' => $testRegistrationPaymentIds,
                'contable_ingresos' => $testIncomeIds,
                'contable_egresos' => $testExpenseIds,
                'contable_opciones' => $testOptions,
                'medicamentos' => $testMedicamentos,
                'medicamentos_movimientos' => $testMovimientosMedicamentos,
                'medicamentos_prestamos' => $testPrestamosMedicamentos,
                'medicamentos_prestamos_detalle' => $testDetallesMedicamentos,
                'medicamentos_prestamos_devoluciones' => $testDevolucionesMedicamentos,
                'medicamentos_prestamos_senas_movimientos' => $testSenasMedicamentos,
                'medios_pago' => $testMeans,
                'condiciones_iva' => $testIva,
                'sis_usuarios' => $testUsers,
            ];
            foreach ($auditReferences as $table => $ids) {
                if ($ids === []) continue;
                $params = array_merge([$table], array_map('strval', $ids));
                $statement = $db->prepare(
                    'DELETE FROM auditoria WHERE tabla_afectada = ? AND id_registro IN ('
                    . self::placeholders(count($ids)) . ')'
                );
                $statement->execute($params);
                $counts['auditoria'] += $statement->rowCount();
            }

            $statement = $db->prepare(
                "DELETE FROM auditoria
                 WHERE (descripcion LIKE '%PW E2E%'
                    OR descripcion LIKE '%PW EE%'
                    OR datos_anteriores LIKE '%PW E2E%'
                    OR datos_anteriores LIKE '%PW EE%'
                    OR datos_anteriores LIKE '%pw_e2e_%'
                    OR datos_nuevos LIKE '%PW E2E%'
                    OR datos_nuevos LIKE '%PW EE%'
                    OR datos_nuevos LIKE '%pw_e2e_%'
                    OR datos_anteriores LIKE '%@example.test%'
                    OR datos_nuevos LIKE '%@example.test%'
                    OR user_agent LIKE 'LALCEC-PLAYWRIGHT-E2E%')
                   AND NOT (modulo = 'TESTING'
                     AND accion = 'E2E_MEDICAMENTOS_OPCION'
                     AND tabla_afectada = 'contable_opciones'
                     AND EXISTS (SELECT 1 FROM contable_opciones o
                         WHERE o.id_opcion = CAST(auditoria.id_registro AS UNSIGNED)))"
            );
            $statement->execute();
            $counts['auditoria'] += $statement->rowCount();

            $db->commit();
        } catch (Throwable $error) {
            if ($db->inTransaction()) $db->rollBack();
            throw $error;
        }

        foreach ($filesToDelete as $relativePath) {
            if (self::deleteContableFile((string)$relativePath)) {
                $counts['archivos']++;
            }
        }

        return [
            'eliminados' => $counts,
            'omitidos_por_seguridad' => $skipped,
        ];
    }

    private static function cleanupScoped(PDO $db, string $scope, mixed $value): array
    {
        $deleted = 0;
        $skipped = [];

        if ($scope === 'login_prefijo') {
            $prefix = trim((string)$value);
            if (!str_starts_with($prefix, 'pw_e2e_')) {
                api_error('Prefijo E2E de login inválido.', 'E2E_SCOPE_INVALIDO', 422);
            }
            $statement = $db->prepare('DELETE FROM sis_login_auditoria WHERE usuario LIKE ?');
            $statement->execute([$prefix . '%']);
            return ['eliminados' => $statement->rowCount(), 'omitidos_por_seguridad' => []];
        }

        $db->beginTransaction();
        try {
            if ($scope === 'socio_id') {
                $id = filter_var($value, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
                if ($id === false) {
                    api_error('ID de socio E2E inválido.', 'E2E_SCOPE_INVALIDO', 422);
                }
                $id = (int)$id;
                $isE2E = self::scalar(
                    $db,
                    "SELECT COUNT(*)
                     FROM socios s
                     LEFT JOIN socios_personas p ON p.id_socio = s.id_socio
                     LEFT JOIN socios_empresas e ON e.id_socio = s.id_socio
                     WHERE s.id_socio = ?
                       AND (
                           p.apellido LIKE 'PW EE APELLIDO %'
                           OR p.apellido LIKE 'PW E2E %'
                           OR p.email LIKE '%@example.test'
                           OR e.razon_social LIKE 'PW E2E %'
                           OR e.razon_social LIKE 'PW EE %'
                           OR e.email LIKE '%@example.test'
                       )",
                    [$id]
                );
                if ($isE2E !== 1) {
                    api_error('El socio indicado no pertenece al conjunto E2E.', 'E2E_SCOPE_BLOQUEADO', 403);
                }

                if (self::tableExists($db,'medicamentos_prestamos') &&
                    self::scalar($db,'SELECT COUNT(*) FROM medicamentos_prestamos WHERE id_socio=?',[$id])>0) {
                    api_error('El socio tiene préstamos de Medicamentos. Usá la limpieza E2E global para retirarlos con sus registros asociados.', 'E2E_CLEANUP_INTEGRIDAD', 409);
                }
                // Limpieza física exclusiva del harness. La operación real de
                // negocio archiva y conserva todos estos registros.
                if (self::tableExists($db, 'saldos_favor_movimientos')) {
                    $deleted += self::deleteByIds($db, 'saldos_favor_movimientos', 'id_socio', [$id]);
                }
                if (self::tableExists($db, 'socios_eliminados')) {
                    $deleted += self::deleteByIds($db, 'socios_eliminados', 'id_socio', [$id]);
                }
                self::deleteByIds($db, 'familias_socios', 'id_socio', [$id]);
                self::deleteByIds($db, 'pagos', 'id_socio', [$id]);
                if (self::tableExists($db, 'pagos_inscripciones')) {
                    self::deleteByIds($db, 'pagos_inscripciones', 'id_socio', [$id]);
                }
                self::deleteByIds($db, 'socios_historial_estados', 'id_socio', [$id]);
                $deleted += self::deleteByIds($db, 'socios', 'id_socio', [$id]);
            } elseif ($scope === 'familia_prefijo') {
                $prefix = trim((string)$value);
                if (!str_starts_with($prefix, 'PW E2E FAM ') && !str_starts_with($prefix, 'PW EE FAM ')) {
                    api_error('Prefijo E2E de familia inválido.', 'E2E_SCOPE_INVALIDO', 422);
                }
                $ids = self::ids($db, 'SELECT id_familia FROM familias WHERE nombre LIKE ?', [$prefix . '%']);
                foreach ($ids as $id) {
                    $realMembers = self::scalar(
                        $db,
                        'SELECT COUNT(*) FROM familias_socios fs WHERE fs.id_familia = ? AND NOT EXISTS ('
                        . self::e2eSocioExistsSql('fs.id_socio') . ')',
                        [$id]
                    );
                    if ($realMembers > 0) {
                        $skipped['familias_con_socios_no_e2e'][] = $id;
                        continue;
                    }
                    self::deleteByIds($db, 'familias_socios', 'id_familia', [$id]);
                    $deleted += self::deleteByIds($db, 'familias', 'id_familia', [$id]);
                }
            } elseif ($scope === 'categoria_prefijo') {
                $prefix = trim((string)$value);
                if (!str_starts_with($prefix, 'PW E2E CAT ') && !str_starts_with($prefix, 'PW EE CAT ')) {
                    api_error('Prefijo E2E de categoría inválido.', 'E2E_SCOPE_INVALIDO', 422);
                }
                $ids = self::ids($db, 'SELECT id_categoria FROM categorias WHERE nombre LIKE ?', [$prefix . '%']);
                foreach ($ids as $id) {
                    if (self::scalar($db, 'SELECT COUNT(*) FROM socios WHERE id_categoria = ?', [$id]) > 0) {
                        $skipped['categorias_en_uso'][] = $id;
                        continue;
                    }
                    self::deleteByIds($db, 'categorias_historial_precios', 'id_categoria', [$id]);
                    $deleted += self::deleteByIds($db, 'categorias', 'id_categoria', [$id]);
                }
            } elseif ($scope === 'descuentos_umbrales') {
                $values = is_array($value) ? $value : explode(',', (string)$value);
                $thresholds = array_values(array_unique(array_filter(
                    array_map('intval', $values),
                    static fn(int $item): bool => $item >= 2 && $item <= 50
                )));
                if ($thresholds === []) api_error('Umbrales E2E inválidos.', 'E2E_SCOPE_INVALIDO', 422);
                $placeholders = self::placeholders(count($thresholds));
                $statement = $db->prepare(
                    "DELETE FROM descuentos_familiares
                     WHERE cantidad_integrantes_desde IN ({$placeholders})
                       AND (descripcion LIKE 'PW E2E %' OR descripcion LIKE 'PW EE %')"
                );
                $statement->execute($thresholds);
                $deleted += $statement->rowCount();
            } elseif ($scope === 'usuario_prefijo') {
                $prefix = trim((string)$value);
                if (!str_starts_with($prefix, 'pw_e2e_')) {
                    api_error('Prefijo E2E de usuario inválido.', 'E2E_SCOPE_INVALIDO', 422);
                }
                $ids = self::ids($db, 'SELECT idUsuario FROM sis_usuarios WHERE usuario LIKE ?', [$prefix . '%']);
                if ($ids !== []) {
                    self::deleteByIds($db, 'sis_sesiones', 'idUsuario', $ids);
                    self::deleteByIds($db, 'sis_login_auditoria', 'idUsuario', $ids);
                    foreach ($ids as $id) {
                        $statement = $db->prepare("DELETE FROM auditoria WHERE tabla_afectada = 'sis_usuarios' AND id_registro = ?");
                        $statement->execute([(string)$id]);
                    }
                    $deleted += self::deleteByIds($db, 'sis_usuarios', 'idUsuario', $ids);
                }
                $statement = $db->prepare('DELETE FROM sis_login_auditoria WHERE usuario LIKE ?');
                $statement->execute([$prefix . '%']);
            } else {
                api_error('Scope de limpieza E2E no permitido.', 'E2E_SCOPE_INVALIDO', 422);
            }

            $db->commit();
        } catch (Throwable $error) {
            if ($db->inTransaction()) $db->rollBack();
            throw $error;
        }

        return ['eliminados' => $deleted, 'omitidos_por_seguridad' => $skipped];
    }

    private static function residueCounts(PDO $db, int $currentSessionId): array
    {
        ensure_socios_eliminados_schema($db);
        $counts = [
            'socios' => count(self::testSocioIds($db)),
            'familias' => self::scalar($db, "SELECT COUNT(*) FROM familias WHERE nombre LIKE 'PW E2E FAM %' OR nombre LIKE 'PW EE FAM %'"),
            'categorias' => self::scalar($db, "SELECT COUNT(*) FROM categorias WHERE nombre LIKE 'PW E2E CAT %' OR nombre LIKE 'PW EE CAT %'"),
            'descuentos_familiares' => self::scalar($db, "SELECT COUNT(*) FROM descuentos_familiares WHERE descripcion LIKE 'PW E2E %' OR descripcion LIKE 'PW EE %'"),
            'medios_pago' => self::scalar($db, "SELECT COUNT(*) FROM medios_pago WHERE nombre LIKE 'PW E2E %' OR nombre LIKE 'PW EE %'"),
            'condiciones_iva' => self::scalar($db, "SELECT COUNT(*) FROM condiciones_iva WHERE nombre LIKE 'PW E2E %' OR nombre LIKE 'PW EE %'"),
            'usuarios' => self::scalar($db, "SELECT COUNT(*) FROM sis_usuarios WHERE usuario LIKE 'pw_e2e_%' OR email LIKE '%@example.test'"),
            'contable_opciones' => self::scalar($db,
                "SELECT COUNT(*) FROM contable_opciones o WHERE o.nombre LIKE 'PW E2E %' OR o.nombre LIKE 'PW EE %' OR "
                . self::fixtureOpcionesMedicamentosSql('o')),
            'medicamentos' => self::tableExists($db,'medicamentos') ? self::scalar($db, "SELECT COUNT(*) FROM medicamentos WHERE nombre_comercial LIKE 'PW E2E %' OR nombre_comercial LIKE 'PW EE %'") : 0,
            'medicamentos_solicitudes' => self::tableExists($db,'medicamentos_solicitudes')
                ? self::scalar($db, "SELECT COUNT(*) FROM medicamentos_solicitudes WHERE clave LIKE 'med-PWE2E-%'") : 0,
            'medicamentos_alertas_descartadas' => self::tableExists($db,'medicamentos_alertas_descartadas')
                ? self::scalar($db, "SELECT COUNT(*) FROM medicamentos_alertas_descartadas x WHERE
                    (x.tipo='MEDICAMENTO' AND EXISTS (SELECT 1 FROM medicamentos m WHERE m.id_medicamento=x.id_referencia AND (m.nombre_comercial LIKE 'PW E2E %' OR m.nombre_comercial LIKE 'PW EE %')))
                    OR (x.tipo='PRESTAMO' AND EXISTS (SELECT 1 FROM medicamentos_prestamos_detalle d JOIN medicamentos m ON m.id_medicamento=d.id_medicamento WHERE d.id_prestamo=x.id_referencia AND (m.nombre_comercial LIKE 'PW E2E %' OR m.nombre_comercial LIKE 'PW EE %')))") : 0,
            'contable_ingresos' => self::scalar($db, "SELECT COUNT(*) FROM contable_ingresos WHERE detalle LIKE 'PW E2E %' OR detalle LIKE 'PW EE %' OR proveedor LIKE 'PW E2E %' OR proveedor LIKE 'PW EE %' OR categoria LIKE 'PW E2E %' OR categoria LIKE 'PW EE %' OR concepto LIKE 'PW E2E %' OR concepto LIKE 'PW EE %'"),
            'contable_egresos' => self::scalar($db, "SELECT COUNT(*) FROM contable_egresos WHERE detalle LIKE 'PW E2E %' OR detalle LIKE 'PW EE %' OR proveedor LIKE 'PW E2E %' OR proveedor LIKE 'PW EE %' OR categoria LIKE 'PW E2E %' OR categoria LIKE 'PW EE %' OR concepto LIKE 'PW E2E %' OR concepto LIKE 'PW EE %' OR numero_comprobante LIKE 'E2E-%'"),
            'sesiones' => self::scalar($db, "SELECT COUNT(*) FROM sis_sesiones WHERE idSesion <> ? AND user_agent LIKE 'LALCEC-PLAYWRIGHT-E2E%'", [$currentSessionId]),
            'login_auditoria' => self::scalar($db, "SELECT COUNT(*) FROM sis_login_auditoria WHERE usuario LIKE 'pw_e2e_%' OR user_agent LIKE 'LALCEC-PLAYWRIGHT-E2E%'"),
            'auditoria' => self::scalar($db, "SELECT COUNT(*) FROM auditoria WHERE descripcion LIKE '%PW E2E%' OR descripcion LIKE '%PW EE%' OR datos_anteriores LIKE '%PW E2E%' OR datos_anteriores LIKE '%PW EE%' OR datos_anteriores LIKE '%pw_e2e_%' OR datos_nuevos LIKE '%PW E2E%' OR datos_nuevos LIKE '%PW EE%' OR datos_nuevos LIKE '%pw_e2e_%' OR datos_anteriores LIKE '%@example.test%' OR datos_nuevos LIKE '%@example.test%' OR user_agent LIKE 'LALCEC-PLAYWRIGHT-E2E%'"),
        ];

        $testSocios = self::testSocioIds($db);
        $counts['socios_eliminados'] = $testSocios === [] ? 0 : self::scalar(
            $db,
            'SELECT COUNT(*) FROM socios_eliminados WHERE id_socio IN (' . self::placeholders(count($testSocios)) . ')',
            $testSocios
        );
        $counts['pagos'] = $testSocios === [] ? 0 : self::scalar(
            $db,
            'SELECT COUNT(*) FROM pagos WHERE id_socio IN (' . self::placeholders(count($testSocios)) . ')',
            $testSocios
        );
        $counts['saldos_favor_movimientos'] = self::tableExists($db, 'saldos_favor_movimientos') && $testSocios !== []
            ? self::scalar(
                $db,
                'SELECT COUNT(*) FROM saldos_favor_movimientos WHERE id_socio IN (' . self::placeholders(count($testSocios)) . ')',
                $testSocios
            )
            : 0;
        $counts['pagos_inscripciones'] = self::tableExists($db, 'pagos_inscripciones') && $testSocios !== []
            ? self::scalar(
                $db,
                'SELECT COUNT(*) FROM pagos_inscripciones WHERE id_socio IN (' . self::placeholders(count($testSocios)) . ')',
                $testSocios
            )
            : 0;

        return $counts;
    }

    private static function realDataSnapshot(PDO $db): array
    {
        ensure_socios_eliminados_schema($db);
        $e2eSocio = self::e2eSocioExistsSql('s.id_socio');
        $e2eSocioFs = self::e2eSocioExistsSql('fs.id_socio');
        $queries = [
            'socios' => "SELECT s.* FROM socios s WHERE NOT EXISTS ({$e2eSocio}) ORDER BY s.id_socio",
            'socios_eliminados' => "SELECT se.* FROM socios_eliminados se WHERE NOT EXISTS (" . self::e2eSocioExistsSql('se.id_socio') . ") ORDER BY se.id_socio",
            'socios_personas' => "SELECT p.* FROM socios_personas p WHERE NOT (p.apellido LIKE 'PW EE APELLIDO %' OR p.apellido LIKE 'PW E2E %' OR p.email LIKE '%@example.test') ORDER BY p.id_socio",
            'socios_empresas' => "SELECT e.* FROM socios_empresas e WHERE NOT (e.razon_social LIKE 'PW E2E %' OR e.razon_social LIKE 'PW EE %' OR e.email LIKE '%@example.test') ORDER BY e.id_socio",
            'socios_historial_estados' => "SELECT h.* FROM socios_historial_estados h WHERE NOT EXISTS (" . self::e2eSocioExistsSql('h.id_socio') . ") ORDER BY h.id_historial_estado",
            'familias' => "SELECT f.* FROM familias f WHERE NOT (f.nombre LIKE 'PW E2E FAM %' OR f.nombre LIKE 'PW EE FAM %') ORDER BY f.id_familia",
            'familias_socios' => "SELECT fs.* FROM familias_socios fs WHERE NOT EXISTS (SELECT 1 FROM familias f WHERE f.id_familia = fs.id_familia AND (f.nombre LIKE 'PW E2E FAM %' OR f.nombre LIKE 'PW EE FAM %')) AND NOT EXISTS ({$e2eSocioFs}) ORDER BY fs.id_familia, fs.id_socio",
            'categorias' => "SELECT c.* FROM categorias c WHERE NOT (c.nombre LIKE 'PW E2E CAT %' OR c.nombre LIKE 'PW EE CAT %') ORDER BY c.id_categoria",
            'categorias_historial_precios' => "SELECT h.* FROM categorias_historial_precios h WHERE NOT EXISTS (SELECT 1 FROM categorias c WHERE c.id_categoria = h.id_categoria AND (c.nombre LIKE 'PW E2E CAT %' OR c.nombre LIKE 'PW EE CAT %')) ORDER BY h.id_historial_precio",
            'descuentos_familiares' => "SELECT d.* FROM descuentos_familiares d WHERE NOT (d.descripcion LIKE 'PW E2E %' OR d.descripcion LIKE 'PW EE %') ORDER BY d.id_descuento_familiar",
            'pagos' => "SELECT p.* FROM pagos p WHERE NOT EXISTS (" . self::e2eSocioExistsSql('p.id_socio') . ") ORDER BY p.id_pago",
            'saldos_favor_movimientos' => "SELECT sf.* FROM saldos_favor_movimientos sf WHERE NOT EXISTS (" . self::e2eSocioExistsSql('sf.id_socio') . ") ORDER BY sf.id_movimiento",
            'medios_pago' => "SELECT m.* FROM medios_pago m WHERE NOT (m.nombre LIKE 'PW E2E %' OR m.nombre LIKE 'PW EE %') ORDER BY m.id_medio_pago",
            'condiciones_iva' => "SELECT c.* FROM condiciones_iva c WHERE NOT (c.nombre LIKE 'PW E2E %' OR c.nombre LIKE 'PW EE %') ORDER BY c.id_condicion_iva",
            'contable_opciones' => "SELECT o.* FROM contable_opciones o WHERE NOT (o.nombre LIKE 'PW E2E %' OR o.nombre LIKE 'PW EE %') AND NOT "
                . self::fixtureOpcionesMedicamentosSql('o') . ' ORDER BY o.id_opcion',
            'contable_ingresos' => "SELECT i.* FROM contable_ingresos i WHERE NOT (i.detalle LIKE 'PW E2E %' OR i.detalle LIKE 'PW EE %' OR i.proveedor LIKE 'PW E2E %' OR i.proveedor LIKE 'PW EE %' OR i.categoria LIKE 'PW E2E %' OR i.categoria LIKE 'PW EE %' OR i.concepto LIKE 'PW E2E %' OR i.concepto LIKE 'PW EE %') ORDER BY i.id_ingreso",
            'contable_egresos' => "SELECT e.* FROM contable_egresos e WHERE NOT (e.detalle LIKE 'PW E2E %' OR e.detalle LIKE 'PW EE %' OR e.proveedor LIKE 'PW E2E %' OR e.proveedor LIKE 'PW EE %' OR e.categoria LIKE 'PW E2E %' OR e.categoria LIKE 'PW EE %' OR e.concepto LIKE 'PW E2E %' OR e.concepto LIKE 'PW EE %' OR e.numero_comprobante LIKE 'E2E-%') ORDER BY e.id_egreso",
            'sis_usuarios' => "SELECT u.* FROM sis_usuarios u WHERE u.usuario NOT LIKE 'pw_e2e_%' AND COALESCE(u.email,'') NOT LIKE '%@example.test' ORDER BY u.idUsuario",
            // ultimo_uso es un heartbeat operativo: require_auth() lo actualiza cada minuto
            // cuando un usuario REAL navega por el sistema. Incluirlo en la huella hacía
            // fallar una corrida E2E contra producción aunque Playwright no hubiera tocado
            // ningún dato real. Se excluye SOLO ese campo volátil; siguen protegidos
            // idSesion, session_key, idUsuario, expira_en, ip, user_agent y activo.
            'sis_sesiones' => "SELECT s.idSesion, s.session_key, s.idUsuario, s.expira_en, s.ip, s.user_agent, s.activo FROM sis_sesiones s WHERE COALESCE(s.user_agent,'') NOT LIKE 'LALCEC-PLAYWRIGHT-E2E%' AND NOT EXISTS (SELECT 1 FROM sis_usuarios u WHERE u.idUsuario = s.idUsuario AND (u.usuario LIKE 'pw_e2e_%' OR COALESCE(u.email,'') LIKE '%@example.test')) ORDER BY s.idSesion",
            'sis_login_auditoria' => "SELECT l.* FROM sis_login_auditoria l WHERE l.usuario NOT LIKE 'pw_e2e_%' AND COALESCE(l.user_agent,'') NOT LIKE 'LALCEC-PLAYWRIGHT-E2E%' ORDER BY l.idLog",
            'auditoria' => "SELECT a.* FROM auditoria a WHERE COALESCE(a.user_agent,'') NOT LIKE 'LALCEC-PLAYWRIGHT-E2E%' AND COALESCE(a.descripcion,'') NOT LIKE '%PW E2E%' AND COALESCE(a.descripcion,'') NOT LIKE '%PW EE%' AND COALESCE(a.datos_anteriores,'') NOT LIKE '%PW E2E%' AND COALESCE(a.datos_anteriores,'') NOT LIKE '%PW EE%' AND COALESCE(a.datos_anteriores,'') NOT LIKE '%pw_e2e_%' AND COALESCE(a.datos_nuevos,'') NOT LIKE '%PW E2E%' AND COALESCE(a.datos_nuevos,'') NOT LIKE '%PW EE%' AND COALESCE(a.datos_nuevos,'') NOT LIKE '%pw_e2e_%' AND COALESCE(a.datos_anteriores,'') NOT LIKE '%@example.test%' AND COALESCE(a.datos_nuevos,'') NOT LIKE '%@example.test%' ORDER BY a.id_auditoria",
        ];
        if (self::tableExists($db,'medicamentos')) {
            $isTestMed="(m.nombre_comercial LIKE 'PW E2E %' OR m.nombre_comercial LIKE 'PW EE %')";
            $queries['medicamentos']="SELECT m.* FROM medicamentos m WHERE NOT {$isTestMed} ORDER BY m.id_medicamento";
            $queries['medicamentos_movimientos']="SELECT x.* FROM medicamentos_movimientos x JOIN medicamentos m ON m.id_medicamento=x.id_medicamento WHERE NOT {$isTestMed} ORDER BY x.id_movimiento";
            $queries['medicamentos_prestamos']="SELECT p.* FROM medicamentos_prestamos p WHERE NOT EXISTS (SELECT 1 FROM medicamentos_prestamos_detalle d JOIN medicamentos m ON m.id_medicamento=d.id_medicamento WHERE d.id_prestamo=p.id_prestamo AND {$isTestMed}) ORDER BY p.id_prestamo";
            $queries['medicamentos_prestamos_detalle']="SELECT d.* FROM medicamentos_prestamos_detalle d JOIN medicamentos m ON m.id_medicamento=d.id_medicamento WHERE NOT {$isTestMed} ORDER BY d.id_detalle_prestamo";
            $queries['medicamentos_prestamos_devoluciones']="SELECT r.* FROM medicamentos_prestamos_devoluciones r JOIN medicamentos_prestamos_detalle d ON d.id_detalle_prestamo=r.id_detalle_prestamo JOIN medicamentos m ON m.id_medicamento=d.id_medicamento WHERE NOT {$isTestMed} ORDER BY r.id_devolucion";
            $queries['medicamentos_prestamos_senas_movimientos']="SELECT sm.* FROM medicamentos_prestamos_senas_movimientos sm WHERE NOT EXISTS (SELECT 1 FROM medicamentos_prestamos_detalle d JOIN medicamentos m ON m.id_medicamento=d.id_medicamento WHERE d.id_prestamo=sm.id_prestamo AND {$isTestMed}) ORDER BY sm.id_movimiento_sena";
            // Los asientos de medicamentos E2E no llevan necesariamente una
            // etiqueta en el texto: se identifican por sus FK de stock/señas.
            $testIncome = "(EXISTS (SELECT 1 FROM medicamentos_movimientos x JOIN medicamentos m ON m.id_medicamento=x.id_medicamento WHERE x.id_ingreso_contable=i.id_ingreso AND {$isTestMed}) OR EXISTS (SELECT 1 FROM medicamentos_prestamos_senas_movimientos sm JOIN medicamentos_prestamos_detalle d ON d.id_prestamo=sm.id_prestamo JOIN medicamentos m ON m.id_medicamento=d.id_medicamento WHERE sm.id_ingreso_contable=i.id_ingreso AND {$isTestMed}))";
            $testExpense = str_replace(['i.id_ingreso','id_ingreso_contable'],['e.id_egreso','id_egreso_contable'],$testIncome);
            $queries['contable_ingresos']=preg_replace('/ ORDER BY i\\.id_ingreso$/'," AND NOT {$testIncome} ORDER BY i.id_ingreso",$queries['contable_ingresos']);
            $queries['contable_egresos']=preg_replace('/ ORDER BY e\\.id_egreso$/'," AND NOT {$testExpense} ORDER BY e.id_egreso",$queries['contable_egresos']);
        }
        // Incluir en la huella de seguridad las dos tablas nuevas de
        // Medicamentos sin contar registros creados por Playwright.
        if (self::tableExists($db, 'medicamentos_solicitudes')) {
            $queries['medicamentos_solicitudes'] = "SELECT s.* FROM medicamentos_solicitudes s
                WHERE s.clave NOT LIKE 'med-PWE2E-%' ORDER BY s.id_solicitud";
        }
        if (self::tableExists($db, 'medicamentos_alertas_descartadas')) {
            $queries['medicamentos_alertas_descartadas'] = "SELECT x.* FROM medicamentos_alertas_descartadas x
              WHERE NOT (x.tipo='MEDICAMENTO' AND EXISTS (SELECT 1 FROM medicamentos m WHERE m.id_medicamento=x.id_referencia AND (m.nombre_comercial LIKE 'PW E2E %' OR m.nombre_comercial LIKE 'PW EE %')))
                AND NOT (x.tipo='PRESTAMO' AND EXISTS (SELECT 1 FROM medicamentos_prestamos_detalle d JOIN medicamentos m ON m.id_medicamento=d.id_medicamento WHERE d.id_prestamo=x.id_referencia AND (m.nombre_comercial LIKE 'PW E2E %' OR m.nombre_comercial LIKE 'PW EE %')))
              ORDER BY x.id_alerta";
        }
        if (self::tableExists($db, 'pagos_inscripciones')) {
            $queries['pagos_inscripciones'] = "SELECT p.* FROM pagos_inscripciones p WHERE NOT EXISTS (" . self::e2eSocioExistsSql('p.id_socio') . ") ORDER BY p.id_pago_inscripcion";
        }

        ksort($queries);
        $tables = [];
        $global = hash_init('sha256');
        foreach ($queries as $name => $sql) {
            $fingerprint = self::fingerprintQuery($db, $sql);
            $tables[$name] = $fingerprint;
            hash_update($global, $name . ':' . $fingerprint['count'] . ':' . $fingerprint['sha256'] . "\n");
        }

        return [
            'sha256' => hash_final($global),
            'tablas' => $tables,
        ];
    }

    private static function fingerprintQuery(PDO $db, string $sql): array
    {
        $statement = $db->query($sql);
        $hash = hash_init('sha256');
        $count = 0;
        while ($row = $statement->fetch(PDO::FETCH_ASSOC)) {
            $json = json_encode(
                $row,
                JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE | JSON_PRESERVE_ZERO_FRACTION
            );
            hash_update($hash, (string)$json . "\n");
            $count++;
        }
        return ['count' => $count, 'sha256' => hash_final($hash)];
    }

    private static function testSocioIds(PDO $db): array
    {
        return self::ids($db,
            "SELECT DISTINCT s.id_socio
             FROM socios s
             LEFT JOIN socios_personas p ON p.id_socio = s.id_socio
             LEFT JOIN socios_empresas e ON e.id_socio = s.id_socio
             WHERE p.apellido LIKE 'PW EE APELLIDO %'
                OR p.apellido LIKE 'PW E2E %'
                OR p.email LIKE '%@example.test'
                OR e.razon_social LIKE 'PW E2E %'
                OR e.razon_social LIKE 'PW EE %'
                OR e.email LIKE '%@example.test'"
        );
    }

    private static function e2eSocioExistsSql(string $idExpression): string
    {
        return "SELECT 1
                FROM socios s2
                LEFT JOIN socios_personas sp2 ON sp2.id_socio = s2.id_socio
                LEFT JOIN socios_empresas se2 ON se2.id_socio = s2.id_socio
                WHERE s2.id_socio = {$idExpression}
                  AND (
                       sp2.apellido LIKE 'PW EE APELLIDO %'
                       OR sp2.apellido LIKE 'PW E2E %'
                       OR sp2.email LIKE '%@example.test'
                       OR se2.razon_social LIKE 'PW E2E %'
                       OR se2.razon_social LIKE 'PW EE %'
                       OR se2.email LIKE '%@example.test'
                  )";
    }

    private static function tableExists(PDO $db, string $table): bool
    {
        $statement = $db->prepare(
            'SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?'
        );
        $statement->execute([$table]);
        return (int)$statement->fetchColumn() > 0;
    }

    private static function ids(PDO $db, string $sql, array $params = []): array
    {
        $statement = $db->prepare($sql);
        $statement->execute($params);
        $ids = [];
        while (($value = $statement->fetchColumn()) !== false) {
            $id = (int)$value;
            if ($id > 0) $ids[$id] = $id;
        }
        return array_values($ids);
    }

    private static function scalar(PDO $db, string $sql, array $params = []): int
    {
        $statement = $db->prepare($sql);
        $statement->execute($params);
        return (int)$statement->fetchColumn();
    }

    private static function placeholders(int $count): string
    {
        return implode(',', array_fill(0, max(1, $count), '?'));
    }

    private static function deleteByIds(PDO $db, string $table, string $column, array $ids): int
    {
        if ($ids === []) return 0;
        if (!preg_match('/^[a-zA-Z0-9_]+$/', $table) || !preg_match('/^[a-zA-Z0-9_]+$/', $column)) {
            throw new RuntimeException('Nombre de tabla o columna inválido en limpieza E2E.');
        }
        $statement = $db->prepare(
            "DELETE FROM `{$table}` WHERE `{$column}` IN (" . self::placeholders(count($ids)) . ')'
        );
        $statement->execute(array_values($ids));
        return $statement->rowCount();
    }

    private static function columnForIds(
        PDO $db,
        string $table,
        string $idColumn,
        string $valueColumn,
        array $ids
    ): array {
        if ($ids === []) return [];
        foreach ([$table, $idColumn, $valueColumn] as $identifier) {
            if (!preg_match('/^[a-zA-Z0-9_]+$/', $identifier)) {
                throw new RuntimeException('Identificador inválido en limpieza E2E.');
            }
        }
        $statement = $db->prepare(
            "SELECT `{$valueColumn}` FROM `{$table}` WHERE `{$idColumn}` IN ("
            . self::placeholders(count($ids)) . ')'
        );
        $statement->execute(array_values($ids));
        return array_values(array_filter(
            array_column($statement->fetchAll(), $valueColumn),
            static fn(mixed $value): bool => $value !== null && $value !== ''
        ));
    }

    private static function deleteContableFile(string $relativePath): bool
    {
        $path = trim($relativePath);
        if ($path === '' || !preg_match('#^egresos/[A-Za-z0-9._-]+$#', $path)) return false;

        $root = dirname(__DIR__, 2) . '/uploads/contable';
        $candidate = $root . '/' . ltrim($path, '/\\');
        $realRoot = realpath($root);
        $realFile = realpath($candidate);
        if (!$realRoot || !$realFile) return false;
        if (!str_starts_with($realFile, $realRoot . DIRECTORY_SEPARATOR) || !is_file($realFile)) return false;
        return @unlink($realFile);
    }
}
